﻿// Spanish learning app data
// ── Alphabet ──────────────────────────────────────────────────────────────────
const VW=["a","e","i","o","u"],VL=["A","E","I","O","U"];
const AL=["A","B","C","D","E","F","G","H","I","J","K","L","M","N","Ñ","O","P","Q","R","S","T","U","V","W","X","Y","Z"];
const CN=AL.filter(l=>!VL.includes(l));
const LI={A:{name:"a",phonetic:"ah",tts:"a"},B:{name:"be",phonetic:"beh",tts:"be"},C:{name:"ce",phonetic:"seh",tts:"ce"},D:{name:"de",phonetic:"deh",tts:"de"},E:{name:"e",phonetic:"eh",tts:"e"},F:{name:"efe",phonetic:"EH-feh",tts:"efe"},G:{name:"ge",phonetic:"heh",tts:"ge"},H:{name:"hache",phonetic:"AH-cheh",tts:"hache"},I:{name:"i",phonetic:"ee",tts:"i"},J:{name:"jota",phonetic:"HOH-tah",tts:"jota"},K:{name:"ka",phonetic:"kah",tts:"ka"},L:{name:"ele",phonetic:"EH-leh",tts:"ele"},M:{name:"eme",phonetic:"EH-meh",tts:"eme"},N:{name:"ene",phonetic:"EH-neh",tts:"ene"},Ñ:{name:"eñe",phonetic:"EH-nyeh",tts:"eñe"},O:{name:"o",phonetic:"oh",tts:"o"},P:{name:"pe",phonetic:"peh",tts:"pe"},Q:{name:"cu",phonetic:"koo",tts:"cu"},R:{name:"erre",phonetic:"EH-rreh",tts:"erre"},S:{name:"ese",phonetic:"EH-seh",tts:"ese"},T:{name:"te",phonetic:"teh",tts:"te"},U:{name:"u",phonetic:"oo",tts:"u"},V:{name:"uve",phonetic:"OO-beh (=B)",tts:"uve"},W:{name:"doble ve",phonetic:"DOH-bleh beh",tts:"doble ve"},X:{name:"equis",phonetic:"EH-kees",tts:"equis"},Y:{name:"ye",phonetic:"yeh",tts:"ye"},Z:{name:"zeta",phonetic:"SEH-tah",tts:"zeta"}};
const VS={a:"ah",e:"eh",i:"ee",o:"oh",u:"oo"};
/* Spanish orthography on purpose: these strings are read by a SPANISH voice,
   so "dó/quí/só" come out right, while English-style "doh/kee/soh" would not. */
const SYL_TTS_FIX={do:"dó",go:"gó",qi:"quí",to:"tó",ro:"ró",wu:"wú",zo:"só",ha:"a",he:"e",hi:"i",ho:"o",hu:"u"};
/* X almost never starts a syllable in real Spanish — it lives between vowels.
   So instead of fake X+vowel syllables, the Sílabas tab shows real example words. */
const X_EXAMPLES=[
  {word:"Taxi",ph:"TAK-see",tts:"taxi",en:"taxi"},
  {word:"Examen",ph:"ek-SAH-men",tts:"examen",en:"exam"},
  {word:"Éxito",ph:"EK-see-toh",tts:"éxito",en:"success"},
];
/* H is silent in Spanish. Keep HA/HE/HI/HO/HU visible for comparison, but
   send only the vowel to speechSynthesis so the learner hears the real sound. */
const RR_SOUND_EXAMPLES={
  a:{word:"arriba",ph:"ah-RREE-bah",tts:"arriba",en:"up / above"},
  e:{word:"arreglo",ph:"ah-RREH-gloh",tts:"arreglo",en:"repair / arrangement"},
  i:{word:"barriga",ph:"bah-RREE-gah",tts:"barriga",en:"stomach / belly"},
  o:{word:"arroyo",ph:"ah-RROH-yoh",tts:"arroyo",en:"stream"},
  u:{word:"arruga",ph:"ah-RROO-gah",tts:"arruga",en:"wrinkle"},
};
/* Special spelling patterns: these need their own lesson because a simple
   consonant + vowel grid cannot show the silent U or the dieresis clearly. */
const SPECIAL_SOUNDS=[
  {id:"ge-gi",label:"GE / GI",sound:"j",tip:"G + E/I has the same strong breathy sound as Spanish J.",examples:[
    {word:"gente",en:"people",ph:"HEN-teh",tts:"gente"},{word:"girar",en:"to turn",ph:"hee-RAR",tts:"girar"}]},
  {id:"ga-go-gu",label:"GA / GO / GU",sound:"g",tip:"G + A/O/U keeps the hard G sound. In GU, the U is part of the spelling but is not a separate vowel sound.",examples:[
    {word:"gato",en:"cat",ph:"GAH-toh",tts:"gato"},{word:"goma",en:"eraser",ph:"GOH-mah",tts:"goma"},{word:"gusano",en:"worm",ph:"goo-SAH-noh",tts:"gusano"}]},
  {id:"gua",label:"GUA",sound:"gwa",tip:"GUA sounds like ‘gwa’: hard G + a quick U glide + A.",examples:[
    {word:"agua",en:"water",ph:"AH-gwah",tts:"agua"},{word:"guante",en:"glove",ph:"GWAHN-teh",tts:"guante"},{word:"guardar",en:"to save / put away",ph:"gwar-DAR",tts:"guardar"}]},
  {id:"gue-gui",label:"GUE / GUI",sound:"ge / gi",tip:"The U is silent. GUE is hard ‘ge’; GUI is hard ‘gi’. Compare them with GE/GI.",examples:[
    {word:"guerra",en:"war",ph:"GEH-rrah",tts:"guerra"},{word:"guitarra",en:"guitar",ph:"gee-TAH-rrah",tts:"guitarra"},{word:"seguir",en:"to continue / follow",ph:"seh-GEER",tts:"seguir"}]},
  {id:"gue-gui-dieresis",label:"GÜE / GÜI",sound:"gwe / gwi",tip:"The two dots make the U audible. Without Ü, the U is silent in GUE/GUI.",examples:[
    {word:"pingüino",en:"penguin",ph:"peen-GWEE-noh",tts:"pingüino"},{word:"vergüenza",en:"shame / embarrassment",ph:"behr-GWEN-sah",tts:"vergüenza"},{word:"bilingüe",en:"bilingual",ph:"bee-leen-GWEH",tts:"bilingüe"}]},
  {id:"que-qui",label:"QUE / QUI",sound:"k",tip:"The U is silent: QUE sounds ‘keh’ and QUI sounds ‘kee’.",examples:[
    {word:"queso",en:"cheese",ph:"KEH-soh",tts:"queso"},{word:"quince",en:"fifteen",ph:"KEEN-seh",tts:"quince"},{word:"¿Qué?",en:"What?",ph:"keh",tts:"¿Qué?"}]}
];
SPECIAL_SOUNDS.push(
  {id:"ca-co-cu",label:"CA / CO / CU",sound:"k",tip:"C + A/O/U keeps the hard K sound.",examples:[{word:"casa",en:"house",ph:"KAH-sah",tts:"casa"},{word:"comer",en:"to eat",ph:"koh-MEHR",tts:"comer"},{word:"cuchara",en:"spoon",ph:"koo-CHAH-rah",tts:"cuchara"}]},
  {id:"ce-ci",label:"CE / CI",sound:"s",tip:"In Colombian Spanish, C + E/I sounds like S.",examples:[{word:"cena",en:"dinner",ph:"SEH-nah",tts:"cena"},{word:"cinco",en:"five",ph:"SEEN-koh",tts:"cinco"},{word:"cerca",en:"near",ph:"SEHR-kah",tts:"cerca"}]},
  {id:"r-rr",label:"R / RR",sound:"tap / trill",tip:"Single R is a quick tap between vowels; RR is a stronger trill.",examples:[{word:"pero",en:"but",ph:"PEH-roh",tts:"pero"},{word:"perro",en:"dog",ph:"PEH-rroh",tts:"perro"},{word:"carro",en:"car",ph:"KAH-rroh",tts:"carro"}]},
  {id:"ll-y",label:"LL / Y",sound:"y",tip:"In most Colombian speech, LL and Y share the same y-like sound.",examples:[{word:"llave",en:"key",ph:"YAH-beh",tts:"llave"},{word:"yo",en:"I",ph:"yoh",tts:"yo"},{word:"calle",en:"street",ph:"KAH-yeh",tts:"calle"}]},
  {id:"ene",label:"Ñ",sound:"ny",tip:"Ñ is one sound, like the ny in canyon.",examples:[{word:"niño",en:"boy / child",ph:"NEE-nyoh",tts:"niño"},{word:"mañana",en:"tomorrow",ph:"mah-NYAH-nah",tts:"mañana"},{word:"año",en:"year",ph:"AH-nyoh",tts:"año"}]},
  {id:"h-silent",label:"H muda",sound:"silent",tip:"H is silent at the start of Spanish words.",examples:[{word:"hola",en:"hello",ph:"OH-lah",tts:"hola"},{word:"hotel",en:"hotel",ph:"oh-TEL",tts:"hotel"},{word:"hacer",en:"to do / make",ph:"ah-SEHR",tts:"hacer"}]},
  {id:"v-b",label:"V / B",sound:"b",tip:"V and B are pronounced alike in Colombian Spanish; focus on the word, not an English V.",examples:[{word:"vaca",en:"cow",ph:"BAH-kah",tts:"vaca"},{word:"vivir",en:"to live",ph:"bee-BEER",tts:"vivir"},{word:"bebé",en:"baby",ph:"beh-BEH",tts:"bebé"}]}
);
const TONGUE_TWISTERS=[
  {id:"rr-1",target:"RR",title:"RR fuerte · nivel 1",text:"Rosa corre rápido alrededor del carro rojo.",en:"Rosa runs quickly around the red car.",tts:"Rosa corre rápido alrededor del carro rojo."},
  {id:"rr-2",target:"RR",title:"RR fuerte · nivel 2",text:"El perro de Roberto corre por el barrio.",en:"Roberto's dog runs through the neighborhood.",tts:"El perro de Roberto corre por el barrio."},
  {id:"rr-3",target:"RR",title:"RR fuerte · reto",text:"Raúl arregla la rueda rota del carro rojo.",en:"Raúl repairs the red car's broken wheel.",tts:"Raúl arregla la rueda rota del carro rojo."},
  {id:"rr-advanced",target:"RR",title:"RR fuerte · reto largo",text:"Parra tenía una perra.\nGuerra tenía una parra.\nLa perra de Parra subió a la parra de Guerra.\nGuerra pegó con la porra a la perra de Parra.\nY Parra le dijo a Guerra: ¿Por qué ha pegado Guerra con la porra a la perra de Parra?\nY Guerra le contestó: Si la perra de Parra no hubiera subido a la parra de Guerra, Guerra no hubiese pegado con la porra a la perra de Parra.",en:"A long RR drill about Parra's dog and Guerra's grapevine.",tts:"Parra tenía una perra. Guerra tenía una parra. La perra de Parra subió a la parra de Guerra. Guerra pegó con la porra a la perra de Parra. Y Parra le dijo a Guerra: ¿Por qué ha pegado Guerra con la porra a la perra de Parra? Y Guerra le contestó: Si la perra de Parra no hubiera subido a la parra de Guerra, Guerra no hubiese pegado con la porra a la perra de Parra."},
  {id:"ene-1",target:"Ñ",title:"Ñ · nivel 1",text:"La niña come piña en la mañana.",en:"The girl eats pineapple in the morning.",tts:"La niña come piña en la mañana."},
  {id:"ene-2",target:"Ñ",title:"Ñ · nivel 2",text:"Mañana, Toño sueña con una montaña pequeña.",en:"Tomorrow, Toño dreams about a small mountain.",tts:"Mañana, Toño sueña con una montaña pequeña."},
  {id:"ge-gi-1",target:"J / GE-GI",title:"J y GE/GI",text:"Jorge gira y recoge la guitarra.",en:"Jorge turns and picks up the guitar.",tts:"Jorge gira y recoge la guitarra."},
  {id:"b-v-1",target:"B / V",title:"B y V",text:"Vivi bebe vino, pero Beto bebe agua.",en:"Vivi drinks wine, but Beto drinks water.",tts:"Vivi bebe vino, pero Beto bebe agua."},
];
const PRONUNCIATION_TIPS=[
  {target:"RR",title:"RR: make the tongue vibrate",sound:"Not the English R",steps:["Keep the tip of your tongue relaxed just behind your upper teeth, where you would say Spanish D/T.","Let air flow over the relaxed tip. Do not curl the tongue back like an English R and do not force the vibration.","Build it slowly: t-ra → d-ra → rra, then rra/rre/rri/rro/rru → perro, carro, arriba."],avoid:"If it sounds like an English R, relax the tongue more and add steady air. A short tap is a useful step, but RR needs repeated vibration."},
  {target:"Ñ",title:"Ñ: one sound, one syllable",sound:"Like the ny in canyon",steps:["Lift the middle of your tongue toward the hard roof of your mouth, while the sides stay near the upper teeth.","Keep Ñ together as one consonant sound. Do not pronounce it as two separate sounds: ni-ño should flow as nee-nyoh.","Build it slowly: ña/ñe/ñi/ño/ñu → niño, mañana, año → a full sentence."],avoid:"Do not replace Ñ with an English N or add an extra vowel. Listen for the smooth ‘ny’ sound in the middle of the word."},
];
const PHONETIC_WARMUP=[
  {id:"vowels",label:"Pure vowels",detail:"A · E · I · O · U",tts:"a, e, i, o, u",target:"a e i o u",note:"Keep each vowel short and steady; do not turn it into an English diphthong."},
  {id:"rr",label:"RR vibration",detail:"RRA · RRE · RRI · RRO · RRU",tts:"arriba, arreglo, barriga, arroyo, arruga",target:"arriba, arreglo, barriga, arroyo, arruga",note:"Relax the tongue tip and let the air create the vibration."},
  {id:"ene",label:"Ñ connection",detail:"ÑA · ÑE · ÑI · ÑO · ÑU",tts:"mañana, pequeño, niño, sueño, ñu",target:"mañana, pequeño, niño, sueño, ñu",note:"Keep Ñ as one smooth consonant; do not separate it into N plus a new syllable."},
  {id:"pairs",label:"Hear the contrast",detail:"PERO ↔ PERRO",tts:"pero, perro, pero, perro",target:"pero, perro",note:"Single R is a quick tap; RR is a stronger vibration."},
];
const ENGLISH_INTERFERENCE=[
  {pattern:"A",spanish:"ah",english:"not ‘ay’",example:"casa",en:"house",tts:"casa"},
  {pattern:"E",spanish:"eh",english:"not ‘ee’",example:"mesa",en:"table",tts:"mesa"},
  {pattern:"I",spanish:"ee",english:"not English ‘eye’",example:"vino",en:"wine / came",tts:"vino"},
  {pattern:"O",spanish:"short oh",english:"do not add ‘oo’",example:"rojo",en:"red",tts:"rojo"},
  {pattern:"H",spanish:"silent",english:"never an English H",example:"hola",en:"hello",tts:"hola"},
  {pattern:"J / GE / GI",spanish:"strong breathy sound",english:"not English J",example:"gente",en:"people",tts:"gente"},
  {pattern:"B / V",spanish:"both use Spanish B",english:"not English V",example:"vivir",en:"to live",tts:"vivir"},
  {pattern:"R / RR",spanish:"tap / trill",english:"not English R",example:"pero / perro",en:"but / dog",tts:"pero, perro"},
];
const MINIMAL_PAIRS=[
  {a:"pero",aEn:"but",b:"perro",bEn:"dog",tip:"One quick tap vs. a trill",tts:"pero, perro"},
  {a:"caro",aEn:"expensive",b:"carro",bEn:"car",tip:"Keep the double R vibrating",tts:"caro, carro"},
  {a:"cero",aEn:"zero",b:"cerro",bEn:"hill",tip:"S stays the same; R changes",tts:"cero, cerro"},
  {a:"para",aEn:"for / in order to",b:"parra",bEn:"grapevine",tip:"A perfect bridge to the long drill",tts:"para, parra"},
  {a:"coro",aEn:"choir",b:"corro",bEn:"I run",tip:"Short R vs. RR in the middle",tts:"coro, corro"},
];
const SPANISH_THINKING_PROMPTS=[
  {intent:"Say that you need to practice today.",model:"Necesito practicar hoy.",tts:"Necesito practicar hoy."},
  {intent:"Say that you are going to call later.",model:"Voy a llamar más tarde.",tts:"Voy a llamar más tarde."},
  {intent:"Say that you did not understand.",model:"No entendí.",tts:"No entendí."},
  {intent:"Ask someone to repeat slowly.",model:"¿Puede repetir despacio?",tts:"¿Puede repetir despacio?"},
  {intent:"Say that the car is over there.",model:"El carro está allá.",tts:"El carro está allá."},
  {intent:"Say that you want to speak Spanish.",model:"Quiero hablar español.",tts:"Quiero hablar español."},
];
function sylTTS(label,fallback){return SYL_TTS_FIX[label.toLowerCase()]||fallback||label.toLowerCase();}
function speakSyl(label,fallback){
  speak(sylTTS(label,fallback),0.75);
}
function gc(l,v){
  const pv={C:{a:{p:"kah",t:"ca",n:null},e:{p:"seh",t:"ce",n:"suena 's'"},i:{p:"see",t:"ci",n:"suena 's'"},o:{p:"koh",t:"co",n:null},u:{p:"koo",t:"cu",n:null}},G:{a:{p:"gah",t:"ga",n:null},e:{p:"heh",t:"ge",n:"suena 'j'"},i:{p:"hee",t:"gi",n:"suena 'j'"},o:{p:"goh",t:"go",n:null},u:{p:"goo",t:"gu",n:null}},H:{a:{p:"ah",t:"ha",n:"H muda"},e:{p:"eh",t:"he",n:"H muda"},i:{p:"ee",t:"hi",n:"H muda"},o:{p:"oh",t:"ho",n:"H muda"},u:{p:"oo",t:"hu",n:"H muda"}},Q:{a:{p:"kah",t:"qa",n:"usa QU"},e:{p:"keh",t:"que",n:"QUE='keh'"},i:{p:"kee",t:"qui",n:"QUI='kee'"},o:{p:"koh",t:"qo",n:"usa QU"},u:{p:"koo",t:"qu",n:"con U"}},
    V:{a:{p:"bah",t:"ba",n:"V=B en Colombia"},e:{p:"beh",t:"be",n:"V=B en Colombia"},i:{p:"bee",t:"bi",n:"V=B en Colombia"},o:{p:"boh",t:"bo",n:"V=B en Colombia"},u:{p:"boo",t:"bu",n:"V=B en Colombia"}},
    L:{a:{p:"lah",t:"la",n:null},e:{p:"leh",t:"le",n:null},i:{p:"lee",t:"li",n:null},o:{p:"loh",t:"lo",n:null},u:{p:"loo",t:"lu",n:null}},
    N:{a:{p:"nah",t:"na",n:null},e:{p:"neh",t:"ne",n:null},i:{p:"nee",t:"ni",n:null},o:{p:"noh",t:"no",n:null},u:{p:"noo",t:"nu",n:null}},
    Y:{a:{p:"yah",t:"ya",n:null},e:{p:"yeh",t:"ye",n:null},i:{p:"yee",t:"yi",n:"sonido 'y'"},o:{p:"yoh",t:"yo",n:null},u:{p:"yoo",t:"yu",n:null}},
  };
  if(pv[l])return pv[l][v];
  const s={B:"b",D:"d",F:"f",J:"j",K:"k",M:"m",Ñ:"ny",P:"p",R:"r",S:"s",T:"t",W:"w",X:"ks",Z:"s"};
  const n={J:"suena 'j'",X:"'ks' o 'j'",Z:"suena 's'",Ñ:"sonido 'ny'"};
  return{p:(s[l]||l.toLowerCase())+VS[v],t:(l==="Ñ"?"ñ":l.toLowerCase())+v,n:n[l]||null};
}

// ── VERB CONJUGATION DATA ─────────────────────────────────────────────────────
const VERBS={
  hablar:{en:"to speak / talk",type:"AR — Regular",icon:"🗣️",color:"#4aa8a0",
    gerund:{f:"hablando",en:"speaking"},participle:{f:"hablado",en:"spoken"},
    imperative:{tu:{f:"¡Habla!",en:"Speak! (informal)"},usted:{f:"¡Hable!",en:"Speak! (formal)"}},
    present:[{p:"yo",v:"hablo",e:"I speak"},{p:"tú",v:"hablas",e:"you speak"},{p:"él/ella/ud.",v:"habla",e:"he/she speaks"},{p:"nosotros",v:"hablamos",e:"we speak"},{p:"ellos/uds.",v:"hablan",e:"they speak"}],
    past:[{p:"yo",v:"hablé",e:"I spoke"},{p:"tú",v:"hablaste",e:"you spoke"},{p:"él/ella/ud.",v:"habló",e:"he/she spoke"},{p:"nosotros",v:"hablamos",e:"we spoke"},{p:"ellos/uds.",v:"hablaron",e:"they spoke"}],
    imperfect:[{p:"yo",v:"hablaba",e:"I was speaking / used to speak"},{p:"tú",v:"hablabas",e:"you were speaking / used to speak"},{p:"él/ella/ud.",v:"hablaba",e:"he/she was speaking / used to speak"},{p:"nosotros",v:"hablábamos",e:"we were speaking / used to speak"},{p:"ellos/uds.",v:"hablaban",e:"they were speaking / used to speak"}],
    future:[{p:"yo",v:"hablaré",e:"I will speak"},{p:"tú",v:"hablarás",e:"you will speak"},{p:"él/ella/ud.",v:"hablará",e:"he/she will speak"},{p:"nosotros",v:"hablaremos",e:"we will speak"},{p:"ellos/uds.",v:"hablarán",e:"they will speak"}],
    family:[{f:"el habla",e:"speech / dialect",t:"sustantivo"},{f:"el/la hablante",e:"speaker",t:"sustantivo"},{f:"hablador/a",e:"talkative person",t:"adjetivo"},{f:"la hablada",e:"accent / way of talking",t:"sustantivo"}],
    example:{es:"Yo hablo un poco de español.",en:"I speak a little Spanish."}},
  comer:{en:"to eat",type:"ER — Regular",icon:"🍽️",color:"#f97316",
    gerund:{f:"comiendo",en:"eating"},participle:{f:"comido",en:"eaten"},
    imperative:{tu:{f:"¡Come!",en:"Eat! (informal)"},usted:{f:"¡Coma!",en:"Eat! (formal)"}},
    present:[{p:"yo",v:"como",e:"I eat"},{p:"tú",v:"comes",e:"you eat"},{p:"él/ella/ud.",v:"come",e:"he/she eats"},{p:"nosotros",v:"comemos",e:"we eat"},{p:"ellos/uds.",v:"comen",e:"they eat"}],
    past:[{p:"yo",v:"comí",e:"I ate"},{p:"tú",v:"comiste",e:"you ate"},{p:"él/ella/ud.",v:"comió",e:"he/she ate"},{p:"nosotros",v:"comimos",e:"we ate"},{p:"ellos/uds.",v:"comieron",e:"they ate"}],
    imperfect:[{p:"yo",v:"comía",e:"I was eating / used to eat"},{p:"tú",v:"comías",e:"you were eating / used to eat"},{p:"él/ella/ud.",v:"comía",e:"he/she was eating / used to eat"},{p:"nosotros",v:"comíamos",e:"we were eating / used to eat"},{p:"ellos/uds.",v:"comían",e:"they were eating / used to eat"}],
    future:[{p:"yo",v:"comeré",e:"I will eat"},{p:"tú",v:"comerás",e:"you will eat"},{p:"él/ella/ud.",v:"comerá",e:"he/she will eat"},{p:"nosotros",v:"comeremos",e:"we will eat"},{p:"ellos/uds.",v:"comerán",e:"they will eat"}],
    family:[{f:"la comida",e:"food / meal",t:"sustantivo"},{f:"el comedor",e:"dining room",t:"sustantivo"},{f:"el/la comensal",e:"diner / guest",t:"sustantivo"},{f:"comestible",e:"edible",t:"adjetivo"}],
    example:{es:"¿Qué vas a comer?",en:"What are you going to eat?"}},
  vivir:{en:"to live",type:"IR — Regular",icon:"🏠",color:"#34d399",
    gerund:{f:"viviendo",en:"living"},participle:{f:"vivido",en:"lived"},
    imperative:{tu:{f:"¡Vive!",en:"Live! (informal)"},usted:{f:"¡Viva!",en:"Live! (formal) / Cheers!"}},
    present:[{p:"yo",v:"vivo",e:"I live"},{p:"tú",v:"vives",e:"you live"},{p:"él/ella/ud.",v:"vive",e:"he/she lives"},{p:"nosotros",v:"vivimos",e:"we live"},{p:"ellos/uds.",v:"viven",e:"they live"}],
    past:[{p:"yo",v:"viví",e:"I lived"},{p:"tú",v:"viviste",e:"you lived"},{p:"él/ella/ud.",v:"vivió",e:"he/she lived"},{p:"nosotros",v:"vivimos",e:"we lived"},{p:"ellos/uds.",v:"vivieron",e:"they lived"}],
    imperfect:[{p:"yo",v:"vivía",e:"I was living / used to live"},{p:"tú",v:"vivías",e:"you were living / used to live"},{p:"él/ella/ud.",v:"vivía",e:"he/she was living / used to live"},{p:"nosotros",v:"vivíamos",e:"we were living / used to live"},{p:"ellos/uds.",v:"vivían",e:"they were living / used to live"}],
    future:[{p:"yo",v:"viviré",e:"I will live"},{p:"tú",v:"vivirás",e:"you will live"},{p:"él/ella/ud.",v:"vivirá",e:"he/she will live"},{p:"nosotros",v:"viviremos",e:"we will live"},{p:"ellos/uds.",v:"vivirán",e:"they will live"}],
    family:[{f:"la vida",e:"life",t:"sustantivo"},{f:"la vivienda",e:"housing / home",t:"sustantivo"},{f:"vivo/a",e:"alive / lively",t:"adjetivo"},{f:"el/la vecino/a",e:"neighbour",t:"sustantivo"}],
    example:{es:"Vivo en Colombia.",en:"I live in Colombia."}},
  beber:{en:"to drink",type:"ER — Regular",icon:"🥤",color:"#60a5fa",
    gerund:{f:"bebiendo",en:"drinking"},participle:{f:"bebido",en:"drunk (drunk something)"},
    imperative:{tu:{f:"¡Bebe!",en:"Drink! (informal)"},usted:{f:"¡Beba!",en:"Drink! (formal)"}},
    present:[{p:"yo",v:"bebo",e:"I drink"},{p:"tú",v:"bebes",e:"you drink"},{p:"él/ella/ud.",v:"bebe",e:"he/she drinks"},{p:"nosotros",v:"bebemos",e:"we drink"},{p:"ellos/uds.",v:"beben",e:"they drink"}],
    past:[{p:"yo",v:"bebí",e:"I drank"},{p:"tú",v:"bebiste",e:"you drank"},{p:"él/ella/ud.",v:"bebió",e:"he/she drank"},{p:"nosotros",v:"bebimos",e:"we drank"},{p:"ellos/uds.",v:"bebieron",e:"they drank"}],
    imperfect:[{p:"yo",v:"bebía",e:"I was drinking / used to drink"},{p:"tú",v:"bebías",e:"you were drinking / used to drink"},{p:"él/ella/ud.",v:"bebía",e:"he/she was drinking / used to drink"},{p:"nosotros",v:"bebíamos",e:"we were drinking / used to drink"},{p:"ellos/uds.",v:"bebían",e:"they were drinking / used to drink"}],
    future:[{p:"yo",v:"beberé",e:"I will drink"},{p:"tú",v:"beberás",e:"you will drink"},{p:"él/ella/ud.",v:"beberá",e:"he/she will drink"},{p:"nosotros",v:"beberemos",e:"we will drink"},{p:"ellos/uds.",v:"beberán",e:"they will drink"}],
    family:[{f:"la bebida",e:"drink / beverage",t:"sustantivo"},{f:"el bebedor",e:"drinker",t:"sustantivo"},{f:"bebible",e:"drinkable",t:"adjetivo"},{f:"la bebida alcohólica",e:"alcoholic drink",t:"sustantivo"}],
    example:{es:"¿Qué bebida quieres?",en:"What drink do you want?"}},
  trabajar:{en:"to work",type:"AR — Regular",icon:"💼",color:"#e8b44a",
    gerund:{f:"trabajando",en:"working"},participle:{f:"trabajado",en:"worked"},
    imperative:{tu:{f:"¡Trabaja!",en:"Work! (informal)"},usted:{f:"¡Trabaje!",en:"Work! (formal)"}},
    present:[{p:"yo",v:"trabajo",e:"I work"},{p:"tú",v:"trabajas",e:"you work"},{p:"él/ella/ud.",v:"trabaja",e:"he/she works"},{p:"nosotros",v:"trabajamos",e:"we work"},{p:"ellos/uds.",v:"trabajan",e:"they work"}],
    past:[{p:"yo",v:"trabajé",e:"I worked"},{p:"tú",v:"trabajaste",e:"you worked"},{p:"él/ella/ud.",v:"trabajó",e:"he/she worked"},{p:"nosotros",v:"trabajamos",e:"we worked"},{p:"ellos/uds.",v:"trabajaron",e:"they worked"}],
    imperfect:[{p:"yo",v:"trabajaba",e:"I was working / used to work"},{p:"tú",v:"trabajabas",e:"you were working / used to work"},{p:"él/ella/ud.",v:"trabajaba",e:"he/she was working / used to work"},{p:"nosotros",v:"trabajábamos",e:"we were working / used to work"},{p:"ellos/uds.",v:"trabajaban",e:"they were working / used to work"}],
    future:[{p:"yo",v:"trabajaré",e:"I will work"},{p:"tú",v:"trabajarás",e:"you will work"},{p:"él/ella/ud.",v:"trabajará",e:"he/she will work"},{p:"nosotros",v:"trabajaremos",e:"we will work"},{p:"ellos/uds.",v:"trabajarán",e:"they will work"}],
    family:[{f:"el trabajo",e:"work / job",t:"sustantivo"},{f:"el/la trabajador/a",e:"worker",t:"sustantivo"},{f:"trabajador/a",e:"hardworking",t:"adjetivo"},{f:"el taller",e:"workshop",t:"sustantivo"}],
    example:{es:"Trabajo en una empresa colombiana.",en:"I work at a Colombian company."}},
  comprar:{en:"to buy",type:"AR — Regular",icon:"🛍️",color:"#ec4899",
    gerund:{f:"comprando",en:"buying"},participle:{f:"comprado",en:"bought"},
    imperative:{tu:{f:"¡Compra!",en:"Buy! (informal)"},usted:{f:"¡Compre!",en:"Buy! (formal)"}},
    present:[{p:"yo",v:"compro",e:"I buy"},{p:"tú",v:"compras",e:"you buy"},{p:"él/ella/ud.",v:"compra",e:"he/she buys"},{p:"nosotros",v:"compramos",e:"we buy"},{p:"ellos/uds.",v:"compran",e:"they buy"}],
    past:[{p:"yo",v:"compré",e:"I bought"},{p:"tú",v:"compraste",e:"you bought"},{p:"él/ella/ud.",v:"compró",e:"he/she bought"},{p:"nosotros",v:"compramos",e:"we bought"},{p:"ellos/uds.",v:"compraron",e:"they bought"}],
    imperfect:[{p:"yo",v:"compraba",e:"I was buying / used to buy"},{p:"tú",v:"comprabas",e:"you were buying / used to buy"},{p:"él/ella/ud.",v:"compraba",e:"he/she was buying / used to buy"},{p:"nosotros",v:"comprábamos",e:"we were buying / used to buy"},{p:"ellos/uds.",v:"compraban",e:"they were buying / used to buy"}],
    future:[{p:"yo",v:"compraré",e:"I will buy"},{p:"tú",v:"comprarás",e:"you will buy"},{p:"él/ella/ud.",v:"comprará",e:"he/she will buy"},{p:"nosotros",v:"compraremos",e:"we will buy"},{p:"ellos/uds.",v:"comprarán",e:"they will buy"}],
    family:[{f:"la compra",e:"purchase / shopping",t:"sustantivo"},{f:"el/la comprador/a",e:"buyer / shopper",t:"sustantivo"},{f:"las compras",e:"shopping (groceries)",t:"sustantivo"},{f:"el supermercado",e:"supermarket",t:"sustantivo"}],
    example:{es:"Fui a comprar en el mercado.",en:"I went to shop at the market."}},
  ir:{en:"to go",type:"Irregular",icon:"🚶",color:"#a78bfa",
    gerund:{f:"yendo",en:"going"},participle:{f:"ido",en:"gone"},
    imperative:{tu:{f:"¡Ve!",en:"Go! (informal)"},usted:{f:"¡Vaya!",en:"Go! (formal)"}},
    present:[{p:"yo",v:"voy",e:"I go"},{p:"tú",v:"vas",e:"you go"},{p:"él/ella/ud.",v:"va",e:"he/she goes"},{p:"nosotros",v:"vamos",e:"we go"},{p:"ellos/uds.",v:"van",e:"they go"}],
    past:[{p:"yo",v:"fui",e:"I went"},{p:"tú",v:"fuiste",e:"you went"},{p:"él/ella/ud.",v:"fue",e:"he/she went"},{p:"nosotros",v:"fuimos",e:"we went"},{p:"ellos/uds.",v:"fueron",e:"they went"}],
    imperfect:[{p:"yo",v:"iba",e:"I was going / used to go"},{p:"tú",v:"ibas",e:"you were going / used to go"},{p:"él/ella/ud.",v:"iba",e:"he/she was going / used to go"},{p:"nosotros",v:"íbamos",e:"we were going / used to go"},{p:"ellos/uds.",v:"iban",e:"they were going / used to go"}],
    future:[{p:"yo",v:"iré",e:"I will go"},{p:"tú",v:"irás",e:"you will go"},{p:"él/ella/ud.",v:"irá",e:"he/she will go"},{p:"nosotros",v:"iremos",e:"we will go"},{p:"ellos/uds.",v:"irán",e:"they will go"}],
    family:[{f:"la ida",e:"going / outward journey",t:"sustantivo"},{f:"la vuelta",e:"return / coming back",t:"sustantivo"},{f:"el viaje",e:"trip / journey",t:"sustantivo"},{f:"vamos a...",e:"let's go to... / going to...",t:"expresión"}],
    example:{es:"¿A dónde vas mañana?",en:"Where are you going tomorrow?"}},
  ser:{en:"to be (permanent)",type:"Irregular",icon:"⭐",color:"#a78bfa",
    gerund:{f:"siendo",en:"being"},participle:{f:"sido",en:"been"},
    imperative:{tu:{f:"¡Sé!",en:"Be! (informal)"},usted:{f:"¡Sea!",en:"Be! (formal)"}},
    present:[{p:"yo",v:"soy",e:"I am"},{p:"tú",v:"eres",e:"you are"},{p:"él/ella/ud.",v:"es",e:"he/she is"},{p:"nosotros",v:"somos",e:"we are"},{p:"ellos/uds.",v:"son",e:"they are"}],
    past:[{p:"yo",v:"fui",e:"I was"},{p:"tú",v:"fuiste",e:"you were"},{p:"él/ella/ud.",v:"fue",e:"he/she was"},{p:"nosotros",v:"fuimos",e:"we were"},{p:"ellos/uds.",v:"fueron",e:"they were"}],
    imperfect:[{p:"yo",v:"era",e:"I was / used to be"},{p:"tú",v:"eras",e:"you were / used to be"},{p:"él/ella/ud.",v:"era",e:"he/she was / used to be"},{p:"nosotros",v:"éramos",e:"we were / used to be"},{p:"ellos/uds.",v:"eran",e:"they were / used to be"}],
    future:[{p:"yo",v:"seré",e:"I will be"},{p:"tú",v:"serás",e:"you will be"},{p:"él/ella/ud.",v:"será",e:"he/she will be"},{p:"nosotros",v:"seremos",e:"we will be"},{p:"ellos/uds.",v:"serán",e:"they will be"}],
    family:[{f:"el ser",e:"being / creature",t:"sustantivo"},{f:"la persona",e:"person",t:"sustantivo"},{f:"la identidad",e:"identity",t:"sustantivo"},{f:"propio/a",e:"own / one's own",t:"adjetivo"}],
    example:{es:"Soy colombiano. ¿Y tú?",en:"I'm Colombian. And you?"}},
  estar:{en:"to be (temporary/location)",type:"Irregular",icon:"📍",color:"#60a5fa",
    gerund:{f:"estando",en:"being"},participle:{f:"estado",en:"been"},
    imperative:{tu:{f:"¡Estate!",en:"Stay! (informal)"},usted:{f:"¡Esté!",en:"Be! (formal)"}},
    present:[{p:"yo",v:"estoy",e:"I am"},{p:"tú",v:"estás",e:"you are"},{p:"él/ella/ud.",v:"está",e:"he/she is"},{p:"nosotros",v:"estamos",e:"we are"},{p:"ellos/uds.",v:"están",e:"they are"}],
    past:[{p:"yo",v:"estuve",e:"I was"},{p:"tú",v:"estuviste",e:"you were"},{p:"él/ella/ud.",v:"estuvo",e:"he/she was"},{p:"nosotros",v:"estuvimos",e:"we were"},{p:"ellos/uds.",v:"estuvieron",e:"they were"}],
    imperfect:[{p:"yo",v:"estaba",e:"I was / used to be"},{p:"tú",v:"estabas",e:"you were / used to be"},{p:"él/ella/ud.",v:"estaba",e:"he/she was / used to be"},{p:"nosotros",v:"estábamos",e:"we were / used to be"},{p:"ellos/uds.",v:"estaban",e:"they were / used to be"}],
    future:[{p:"yo",v:"estaré",e:"I will be"},{p:"tú",v:"estarás",e:"you will be"},{p:"él/ella/ud.",v:"estará",e:"he/she will be"},{p:"nosotros",v:"estaremos",e:"we will be"},{p:"ellos/uds.",v:"estarán",e:"they will be"}],
    family:[{f:"el estado",e:"state / condition",t:"sustantivo"},{f:"la estancia",e:"stay / ranch",t:"sustantivo"},{f:"estable",e:"stable",t:"adjetivo"},{f:"bien/mal",e:"well/bad (used with estar)",t:"adjetivo"}],
    example:{es:"¿Cómo estás? Estoy bien.",en:"How are you? I'm fine."}},
  tener:{en:"to have",type:"Irregular",icon:"✋",color:"#f59e0b",
    gerund:{f:"teniendo",en:"having"},participle:{f:"tenido",en:"had"},
    imperative:{tu:{f:"¡Ten!",en:"Have/Take! (informal)"},usted:{f:"¡Tenga!",en:"Have/Take! (formal)"}},
    present:[{p:"yo",v:"tengo",e:"I have"},{p:"tú",v:"tienes",e:"you have"},{p:"él/ella/ud.",v:"tiene",e:"he/she has"},{p:"nosotros",v:"tenemos",e:"we have"},{p:"ellos/uds.",v:"tienen",e:"they have"}],
    past:[{p:"yo",v:"tuve",e:"I had"},{p:"tú",v:"tuviste",e:"you had"},{p:"él/ella/ud.",v:"tuvo",e:"he/she had"},{p:"nosotros",v:"tuvimos",e:"we had"},{p:"ellos/uds.",v:"tuvieron",e:"they had"}],
    imperfect:[{p:"yo",v:"tenía",e:"I had / used to have"},{p:"tú",v:"tenías",e:"you had / used to have"},{p:"él/ella/ud.",v:"tenía",e:"he/she had / used to have"},{p:"nosotros",v:"teníamos",e:"we had / used to have"},{p:"ellos/uds.",v:"tenían",e:"they had / used to have"}],
    future:[{p:"yo",v:"tendré",e:"I will have"},{p:"tú",v:"tendrás",e:"you will have"},{p:"él/ella/ud.",v:"tendrá",e:"he/she will have"},{p:"nosotros",v:"tendremos",e:"we will have"},{p:"ellos/uds.",v:"tendrán",e:"they will have"}],
    family:[{f:"el tenedor",e:"fork",t:"sustantivo"},{f:"la tenencia",e:"possession / holding",t:"sustantivo"},{f:"el/la dueño/a",e:"owner",t:"sustantivo"},{f:"tener que",e:"to have to (must)",t:"expresión"}],
    example:{es:"Tengo treinta años. ¿Cuántos años tienes tú?",en:"I'm thirty years old. How old are you?"}},
  hacer:{en:"to do / to make",type:"Irregular",icon:"🛠️",color:"#34d399",
    gerund:{f:"haciendo",en:"doing/making"},participle:{f:"hecho",en:"done/made"},
    imperative:{tu:{f:"¡Haz!",en:"Do/Make! (informal)"},usted:{f:"¡Haga!",en:"Do/Make! (formal)"}},
    present:[{p:"yo",v:"hago",e:"I do/make"},{p:"tú",v:"haces",e:"you do/make"},{p:"él/ella/ud.",v:"hace",e:"he/she does/makes"},{p:"nosotros",v:"hacemos",e:"we do/make"},{p:"ellos/uds.",v:"hacen",e:"they do/make"}],
    past:[{p:"yo",v:"hice",e:"I did/made"},{p:"tú",v:"hiciste",e:"you did/made"},{p:"él/ella/ud.",v:"hizo",e:"he/she did/made"},{p:"nosotros",v:"hicimos",e:"we did/made"},{p:"ellos/uds.",v:"hicieron",e:"they did/made"}],
    imperfect:[{p:"yo",v:"hacía",e:"I was doing / used to do"},{p:"tú",v:"hacías",e:"you were doing / used to do"},{p:"él/ella/ud.",v:"hacía",e:"he/she was doing / used to do"},{p:"nosotros",v:"hacíamos",e:"we were doing / used to do"},{p:"ellos/uds.",v:"hacían",e:"they were doing / used to do"}],
    future:[{p:"yo",v:"haré",e:"I will do/make"},{p:"tú",v:"harás",e:"you will do/make"},{p:"él/ella/ud.",v:"hará",e:"he/she will do/make"},{p:"nosotros",v:"haremos",e:"we will do/make"},{p:"ellos/uds.",v:"harán",e:"they will do/make"}],
    family:[{f:"el hecho",e:"fact / deed (done!)",t:"sustantivo"},{f:"la hazaña",e:"feat / achievement",t:"sustantivo"},{f:"hacedero/a",e:"doable / feasible",t:"adjetivo"},{f:"hacer una vuelta",e:"to run an errand (Colombian!)",t:"expresión"}],
    example:{es:"¿Qué haces hoy?",en:"What are you doing today?"}},
  poder:{en:"can / to be able to",type:"Irregular (stem-change)",icon:"💪",color:"#ef4444",
    gerund:{f:"pudiendo",en:"being able to"},participle:{f:"podido",en:"been able to"},
    imperative:{tu:{f:"¡Puede!",en:"You can! (rare as command)"},usted:{f:"—",en:"Rarely used as imperative"}},
    present:[{p:"yo",v:"puedo",e:"I can"},{p:"tú",v:"puedes",e:"you can"},{p:"él/ella/ud.",v:"puede",e:"he/she can"},{p:"nosotros",v:"podemos",e:"we can"},{p:"ellos/uds.",v:"pueden",e:"they can"}],
    past:[{p:"yo",v:"pude",e:"I could"},{p:"tú",v:"pudiste",e:"you could"},{p:"él/ella/ud.",v:"pudo",e:"he/she could"},{p:"nosotros",v:"pudimos",e:"we could"},{p:"ellos/uds.",v:"pudieron",e:"they could"}],
    imperfect:[{p:"yo",v:"podía",e:"I could / was able to"},{p:"tú",v:"podías",e:"you could / were able to"},{p:"él/ella/ud.",v:"podía",e:"he/she could / was able to"},{p:"nosotros",v:"podíamos",e:"we could / were able to"},{p:"ellos/uds.",v:"podían",e:"they could / were able to"}],
    future:[{p:"yo",v:"podré",e:"I will be able to"},{p:"tú",v:"podrás",e:"you will be able to"},{p:"él/ella/ud.",v:"podrá",e:"he/she will be able to"},{p:"nosotros",v:"podremos",e:"we will be able to"},{p:"ellos/uds.",v:"podrán",e:"they will be able to"}],
    family:[{f:"el poder",e:"power",t:"sustantivo"},{f:"poderoso/a",e:"powerful",t:"adjetivo"},{f:"posible",e:"possible",t:"adjetivo"},{f:"¿Puede ayudarme?",e:"Can you help me?",t:"expresión"}],
    example:{es:"¿Puede repetir, por favor?",en:"Can you repeat, please?"}},
  querer:{en:"to want / to love",type:"Irregular (stem-change)",icon:"❤️",color:"#e85d75",
    gerund:{f:"queriendo",en:"wanting/loving"},participle:{f:"querido",en:"wanted/loved"},
    imperative:{tu:{f:"¡Quiere!",en:"Want/Love! (informal)"},usted:{f:"¡Quiera!",en:"Please want (formal, rare)"}},
    present:[{p:"yo",v:"quiero",e:"I want/love"},{p:"tú",v:"quieres",e:"you want/love"},{p:"él/ella/ud.",v:"quiere",e:"he/she wants/loves"},{p:"nosotros",v:"queremos",e:"we want/love"},{p:"ellos/uds.",v:"quieren",e:"they want/love"}],
    past:[{p:"yo",v:"quise",e:"I wanted/loved"},{p:"tú",v:"quisiste",e:"you wanted"},{p:"él/ella/ud.",v:"quiso",e:"he/she wanted"},{p:"nosotros",v:"quisimos",e:"we wanted"},{p:"ellos/uds.",v:"quisieron",e:"they wanted"}],
    imperfect:[{p:"yo",v:"quería",e:"I wanted / used to want"},{p:"tú",v:"querías",e:"you wanted / used to want"},{p:"él/ella/ud.",v:"quería",e:"he/she wanted / used to want"},{p:"nosotros",v:"queríamos",e:"we wanted / used to want"},{p:"ellos/uds.",v:"querían",e:"they wanted / used to want"}],
    future:[{p:"yo",v:"querré",e:"I will want"},{p:"tú",v:"querrás",e:"you will want"},{p:"él/ella/ud.",v:"querrá",e:"he/she will want"},{p:"nosotros",v:"querremos",e:"we will want"},{p:"ellos/uds.",v:"querrán",e:"they will want"}],
    family:[{f:"el/la querido/a",e:"dear / darling",t:"sustantivo/adjetivo"},{f:"el querer",e:"love / affection",t:"sustantivo"},{f:"querido/a",e:"dear / beloved",t:"adjetivo"},{f:"querer decir",e:"to mean (to want to say)",t:"expresión"}],
    example:{es:"Te quiero mucho. ¿Qué quieres comer?",en:"I love you a lot. What do you want to eat?"}},
  dormir:{en:"to sleep",type:"IR — Irregular (stem-change)",icon:"😴",color:"#8b5cf6",
    gerund:{f:"durmiendo",en:"sleeping"},participle:{f:"dormido",en:"slept/asleep"},
    imperative:{tu:{f:"¡Duerme!",en:"Sleep! (informal)"},usted:{f:"¡Duerma!",en:"Sleep! (formal)"}},
    present:[{p:"yo",v:"duermo",e:"I sleep"},{p:"tú",v:"duermes",e:"you sleep"},{p:"él/ella/ud.",v:"duerme",e:"he/she sleeps"},{p:"nosotros",v:"dormimos",e:"we sleep"},{p:"ellos/uds.",v:"duermen",e:"they sleep"}],
    past:[{p:"yo",v:"dormí",e:"I slept"},{p:"tú",v:"dormiste",e:"you slept"},{p:"él/ella/ud.",v:"durmió",e:"he/she slept"},{p:"nosotros",v:"dormimos",e:"we slept"},{p:"ellos/uds.",v:"durmieron",e:"they slept"}],
    imperfect:[{p:"yo",v:"dormía",e:"I was sleeping / used to sleep"},{p:"tú",v:"dormías",e:"you were sleeping / used to sleep"},{p:"él/ella/ud.",v:"dormía",e:"he/she was sleeping / used to sleep"},{p:"nosotros",v:"dormíamos",e:"we were sleeping / used to sleep"},{p:"ellos/uds.",v:"dormían",e:"they were sleeping / used to sleep"}],
    future:[{p:"yo",v:"dormiré",e:"I will sleep"},{p:"tú",v:"dormirás",e:"you will sleep"},{p:"él/ella/ud.",v:"dormirá",e:"he/she will sleep"},{p:"nosotros",v:"dormiremos",e:"we will sleep"},{p:"ellos/uds.",v:"dormirán",e:"they will sleep"}],
    family:[{f:"el sueño",e:"sleep / dream",t:"sustantivo"},{f:"el dormitorio",e:"bedroom",t:"sustantivo"},{f:"dormido/a",e:"asleep",t:"adjetivo"},{f:"la siesta",e:"nap / siesta",t:"sustantivo"}],
    example:{es:"Dormí ocho horas anoche.",en:"I slept eight hours last night."}},
  escribir:{en:"to write",type:"IR — Regular",icon:"✍️",color:"#06b6d4",
    gerund:{f:"escribiendo",en:"writing"},participle:{f:"escrito",en:"written (irregular!)"},
    imperative:{tu:{f:"¡Escribe!",en:"Write! (informal)"},usted:{f:"¡Escriba!",en:"Write! (formal)"}},
    present:[{p:"yo",v:"escribo",e:"I write"},{p:"tú",v:"escribes",e:"you write"},{p:"él/ella/ud.",v:"escribe",e:"he/she writes"},{p:"nosotros",v:"escribimos",e:"we write"},{p:"ellos/uds.",v:"escriben",e:"they write"}],
    past:[{p:"yo",v:"escribí",e:"I wrote"},{p:"tú",v:"escribiste",e:"you wrote"},{p:"él/ella/ud.",v:"escribió",e:"he/she wrote"},{p:"nosotros",v:"escribimos",e:"we wrote"},{p:"ellos/uds.",v:"escribieron",e:"they wrote"}],
    imperfect:[{p:"yo",v:"escribía",e:"I was writing / used to write"},{p:"tú",v:"escribías",e:"you were writing / used to write"},{p:"él/ella/ud.",v:"escribía",e:"he/she was writing / used to write"},{p:"nosotros",v:"escribíamos",e:"we were writing / used to write"},{p:"ellos/uds.",v:"escribían",e:"they were writing / used to write"}],
    future:[{p:"yo",v:"escribiré",e:"I will write"},{p:"tú",v:"escribirás",e:"you will write"},{p:"él/ella/ud.",v:"escribirá",e:"he/she will write"},{p:"nosotros",v:"escribiremos",e:"we will write"},{p:"ellos/uds.",v:"escribirán",e:"they will write"}],
    family:[{f:"la escritura",e:"writing / handwriting",t:"sustantivo"},{f:"escrito/a",e:"written",t:"adjetivo"},{f:"el/la escritor/a",e:"writer / author",t:"sustantivo"},{f:"la carta",e:"letter (written)",t:"sustantivo"}],
    example:{es:"Escríbalo, por favor.",en:"Write it down, please."}},
};

// ── Numbers ───────────────────────────────────────────────────────────────────
const N130=[{n:1,w:"Uno",ph:"OO-noh"},{n:2,w:"Dos",ph:"dohs"},{n:3,w:"Tres",ph:"trehs"},{n:4,w:"Cuatro",ph:"KWAH-troh"},{n:5,w:"Cinco",ph:"SEEN-koh"},{n:6,w:"Seis",ph:"seh-ees"},{n:7,w:"Siete",ph:"SYEH-teh"},{n:8,w:"Ocho",ph:"OH-choh"},{n:9,w:"Nueve",ph:"NWEH-beh"},{n:10,w:"Diez",ph:"dyehs"},{n:11,w:"Once",ph:"ON-seh"},{n:12,w:"Doce",ph:"DOH-seh"},{n:13,w:"Trece",ph:"TREH-seh"},{n:14,w:"Catorce",ph:"kah-TOR-seh"},{n:15,w:"Quince",ph:"KEEN-seh"},{n:16,w:"Dieciséis",ph:"dyeh-see-SEYS"},{n:17,w:"Diecisiete",ph:"dyeh-see-SYEH-teh"},{n:18,w:"Dieciocho",ph:"dyeh-see-OH-choh"},{n:19,w:"Diecinueve",ph:"dyeh-see-NWEH-beh"},{n:20,w:"Veinte",ph:"BEYN-teh"},{n:21,w:"Veintiuno",ph:"beyn-tee-OO-noh"},{n:22,w:"Veintidós",ph:"beyn-tee-DOHS"},{n:23,w:"Veintitrés",ph:"beyn-tee-TREHS"},{n:24,w:"Veinticuatro",ph:"beyn-tee-KWAH-troh"},{n:25,w:"Veinticinco",ph:"beyn-tee-SEEN-koh"},{n:26,w:"Veintiséis",ph:"beyn-tee-SEYS"},{n:27,w:"Veintisiete",ph:"beyn-tee-SYEH-teh"},{n:28,w:"Veintiocho",ph:"beyn-tee-OH-choh"},{n:29,w:"Veintinueve",ph:"beyn-tee-NWEH-beh"},{n:30,w:"Treinta",ph:"TREYN-tah"}];
const NT=[{n:40,w:"Cuarenta",ph:"kwah-REN-tah"},{n:50,w:"Cincuenta",ph:"seen-KWEN-tah"},{n:60,w:"Sesenta",ph:"seh-SEN-tah"},{n:70,w:"Setenta",ph:"seh-TEN-tah"},{n:80,w:"Ochenta",ph:"oh-CHEN-tah"},{n:90,w:"Noventa",ph:"noh-BEN-tah"},{n:100,w:"Cien",ph:"syen"},{n:200,w:"Doscientos",ph:"dohs-SYEN-tohs"},{n:300,w:"Trescientos",ph:"trehs-SYEN-tohs"},{n:400,w:"Cuatrocientos",ph:"kwah-troh-SYEN-tohs"},{n:500,w:"Quinientos",ph:"kee-NYEN-tohs"}];

// ── All Vocab Categories ──────────────────────────────────────────────────────
const VC=[
  {id:"vocales",label:"🐝 Vocales",type:"vocales"},
  {id:"numeros",label:"🔢 Números",type:"numeros"},
  {id:"meses",label:"📆 Meses",type:"basic",items:[
    {word:"Enero",en:"January",ph:"eh-NEH-roh",tts:"enero",icon:"❄️",color:"#60a5fa"},
    {word:"Febrero",en:"February",ph:"feh-BREH-roh",tts:"febrero",icon:"💝",color:"#f43f5e"},
    {word:"Marzo",en:"March",ph:"MAR-soh",tts:"marzo",icon:"🌱",color:"#34d399"},
    {word:"Abril",en:"April",ph:"ah-BREEL",tts:"abril",icon:"🌸",color:"#f9a8d4"},
    {word:"Mayo",en:"May",ph:"MAH-yoh",tts:"mayo",icon:"🌻",color:"#fbbf24"},
    {word:"Junio",en:"June",ph:"HOO-nyoh",tts:"junio",icon:"☀️",color:"#fb923c"},
    {word:"Julio",en:"July",ph:"HOO-lyoh",tts:"julio",icon:"🏖️",color:"#f59e0b"},
    {word:"Agosto",en:"August",ph:"ah-GOHS-toh",tts:"agosto",icon:"🌞",color:"#ef4444"},
    {word:"Septiembre",en:"September",ph:"sep-TYEM-breh",tts:"septiembre",icon:"🍂",color:"#d97706"},
    {word:"Octubre",en:"October",ph:"ok-TOO-breh",tts:"octubre",icon:"🎃",color:"#f97316"},
    {word:"Noviembre",en:"November",ph:"noh-BYEM-breh",tts:"noviembre",icon:"🍁",color:"#92400e"},
    {word:"Diciembre",en:"December",ph:"dee-SYEM-breh",tts:"diciembre",icon:"🎄",color:"#4aa8a0"},
  ]},
  {id:"colores",label:"🎨 Colores",type:"basic",items:[{word:"Rojo",en:"Red",ph:"RROH-hoh",tts:"rojo",icon:"🔴",color:"#ef4444"},{word:"Azul",en:"Blue",ph:"ah-SOOL",tts:"azul",icon:"🔵",color:"#3b82f6"},{word:"Verde",en:"Green",ph:"BER-deh",tts:"verde",icon:"🟢",color:"#10b981"},{word:"Amarillo",en:"Yellow",ph:"ah-mah-REE-yoh",tts:"amarillo",icon:"🟡",color:"#f59e0b"},{word:"Naranja",en:"Orange",ph:"nah-RAN-hah",tts:"naranja",icon:"🟠",color:"#f97316"},{word:"Rosado",en:"Pink",ph:"roh-SAH-doh",tts:"rosado",icon:"🩷",color:"#ec4899"},{word:"Morado",en:"Purple",ph:"moh-RAH-doh",tts:"morado",icon:"🟣",color:"#8b5cf6"},{word:"Blanco",en:"White",ph:"BLAN-koh",tts:"blanco",icon:"⬜",color:"#94a3b8"},{word:"Negro",en:"Black",ph:"NEH-groh",tts:"negro",icon:"⬛",color:"#475569"},{word:"Café",en:"Brown",ph:"kah-FEH",tts:"café",icon:"🟫",color:"#92400e"},{word:"Gris",en:"Gray",ph:"grees",tts:"gris",icon:"🩶",color:"#64748b"}]},
  {id:"dias",label:"📅 Los Días",type:"basic",items:[{word:"Lunes",en:"Monday",ph:"LOO-nehs",tts:"lunes",icon:"1️⃣",color:"#4aa8a0"},{word:"Martes",en:"Tuesday",ph:"MAR-tehs",tts:"martes",icon:"2️⃣",color:"#4aa8a0"},{word:"Miércoles",en:"Wednesday",ph:"MYER-koh-lehs",tts:"miércoles",icon:"3️⃣",color:"#4aa8a0"},{word:"Jueves",en:"Thursday",ph:"HWEH-behs",tts:"jueves",icon:"4️⃣",color:"#4aa8a0"},{word:"Viernes",en:"Friday",ph:"BYER-nehs",tts:"viernes",icon:"5️⃣",color:"#4aa8a0"},{word:"Sábado",en:"Saturday",ph:"SAH-bah-doh",tts:"sábado",icon:"6️⃣",color:"#e8b44a"},{word:"Domingo",en:"Sunday",ph:"doh-MEEN-goh",tts:"domingo",icon:"7️⃣",color:"#e8b44a"}]},
  {id:"familia",label:"👨‍👩‍👧 Familia",type:"basic",items:[{word:"Mamá",en:"Mom",ph:"mah-MAH",tts:"mamá",icon:"👩",color:"#ec4899"},{word:"Papá",en:"Dad",ph:"pah-PAH",tts:"papá",icon:"👨",color:"#3b82f6"},{word:"Hermano",en:"Brother",ph:"er-MAH-noh",tts:"hermano",icon:"👦",color:"#10b981"},{word:"Hermana",en:"Sister",ph:"er-MAH-nah",tts:"hermana",icon:"👧",color:"#f59e0b"},{word:"Abuelo",en:"Grandfather",ph:"ah-BWEH-loh",tts:"abuelo",icon:"👴",color:"#8b5cf6"},{word:"Abuela",en:"Grandmother",ph:"ah-BWEH-lah",tts:"abuela",icon:"👵",color:"#e85d75"},{word:"Tío",en:"Uncle",ph:"TEE-oh",tts:"tío",icon:"🧑",color:"#4aa8a0"},{word:"Tía",en:"Aunt",ph:"TEE-ah",tts:"tía",icon:"👩",color:"#a78bfa"},{word:"Hijo",en:"Son",ph:"EE-hoh",tts:"hijo",icon:"👦",color:"#34d399"},{word:"Hija",en:"Daughter",ph:"EE-hah",tts:"hija",icon:"👧",color:"#fb923c"}]},
  {id:"verbos",label:"🏃 Verbos",type:"verbos"},
  {id:"cuerpo",label:"🫀 Cuerpo",type:"basic",items:[{word:"Cabeza",en:"Head",ph:"kah-BEH-sah",tts:"cabeza",icon:"🧠",color:"#e85d75"},{word:"Ojo",en:"Eye",ph:"OH-hoh",tts:"ojo",icon:"👁️",color:"#60a5fa"},{word:"Oreja",en:"Ear",ph:"oh-REH-hah",tts:"oreja",icon:"👂",color:"#f59e0b"},{word:"Nariz",en:"Nose",ph:"nah-REES",tts:"nariz",icon:"👃",color:"#f97316"},{word:"Boca",en:"Mouth",ph:"BOH-kah",tts:"boca",icon:"👄",color:"#e85d75"},{word:"Cuello",en:"Neck",ph:"KWEH-yoh",tts:"cuello",icon:"🔵",color:"#4aa8a0"},{word:"Hombro",en:"Shoulder",ph:"OHM-broh",tts:"hombro",icon:"💪",color:"#a78bfa"},{word:"Brazo",en:"Arm",ph:"BRAH-soh",tts:"brazo",icon:"💪",color:"#3b82f6"},{word:"Mano",en:"Hand",ph:"MAH-noh",tts:"mano",icon:"✋",color:"#f59e0b"},{word:"Dedo",en:"Finger",ph:"DEH-doh",tts:"dedo",icon:"☝️",color:"#fb923c"},{word:"Pierna",en:"Leg",ph:"PYER-nah",tts:"pierna",icon:"🦵",color:"#34d399"},{word:"Pie",en:"Foot",ph:"pyeh",tts:"pie",icon:"🦶",color:"#e85d75"},{word:"Corazón",en:"Heart",ph:"koh-rah-SOHN",tts:"corazón",icon:"❤️",color:"#ef4444"},{word:"Estómago",en:"Stomach",ph:"ehs-TOH-mah-goh",tts:"estómago",icon:"🫄",color:"#f97316"},{word:"Espalda",en:"Back",ph:"ehs-PAL-dah",tts:"espalda",icon:"🔵",color:"#8b5cf6"}]},
  {id:"comida",label:"🍽️ Comida",type:"basic",items:[{word:"Agua",en:"Water",ph:"AH-gwah",tts:"agua",icon:"💧",color:"#60a5fa"},{word:"Café",en:"Coffee",ph:"kah-FEH",tts:"café",icon:"☕",color:"#92400e"},{word:"Tinto",en:"Black coffee (Colombian!)",ph:"TEEN-toh",tts:"tinto",icon:"☕",color:"#7c2d12"},{word:"Jugo",en:"Juice",ph:"HOO-goh",tts:"jugo",icon:"🧃",color:"#f59e0b"},{word:"Cerveza",en:"Beer",ph:"ser-BEH-sah",tts:"cerveza",icon:"🍺",color:"#d97706"},{word:"Leche",en:"Milk",ph:"LEH-cheh",tts:"leche",icon:"🥛",color:"#94a3b8"},{word:"Pan",en:"Bread",ph:"pan",tts:"pan",icon:"🍞",color:"#d97706"},{word:"Arroz",en:"Rice",ph:"ah-RROHS",tts:"arroz",icon:"🍚",color:"#94a3b8"},{word:"Pollo",en:"Chicken",ph:"POH-yoh",tts:"pollo",icon:"🍗",color:"#f59e0b"},{word:"Carne",en:"Meat / Beef",ph:"KAR-neh",tts:"carne",icon:"🥩",color:"#ef4444"},{word:"Arepa",en:"Arepa (Colombian!)",ph:"ah-REH-pah",tts:"arepa",icon:"🫓",color:"#f59e0b"},{word:"Aguacate",en:"Avocado",ph:"ah-gwah-KAH-teh",tts:"aguacate",icon:"🥑",color:"#34d399"},{word:"Fruta",en:"Fruit",ph:"FROO-tah",tts:"fruta",icon:"🍎",color:"#e85d75"},{word:"Huevo",en:"Egg",ph:"WEH-boh",tts:"huevo",icon:"🥚",color:"#fbbf24"},{word:"Bandeja paisa",en:"Traditional Colombian meal",ph:"ban-DEH-hah PAY-sah",tts:"bandeja paisa",icon:"🍛",color:"#f97316"}]},
  {id:"lugares",label:"📍 Lugares",type:"basic",items:[{word:"Casa",en:"House / Home",ph:"KAH-sah",tts:"casa",icon:"🏠",color:"#4aa8a0"},{word:"Tienda",en:"Shop / Store",ph:"TYEN-dah",tts:"tienda",icon:"🏪",color:"#f59e0b"},{word:"Mercado",en:"Market",ph:"mer-KAH-doh",tts:"mercado",icon:"🛒",color:"#34d399"},{word:"Banco",en:"Bank",ph:"BAN-koh",tts:"banco",icon:"🏦",color:"#60a5fa"},{word:"Hospital",en:"Hospital",ph:"ohs-pee-TAL",tts:"hospital",icon:"🏥",color:"#ef4444"},{word:"Farmacia",en:"Pharmacy",ph:"far-MAH-syah",tts:"farmacia",icon:"💊",color:"#34d399"},{word:"Restaurante",en:"Restaurant",ph:"rrehs-tah-oo-RAN-teh",tts:"restaurante",icon:"🍽️",color:"#f97316"},{word:"Hotel",en:"Hotel",ph:"oh-TEL",tts:"hotel",icon:"🏨",color:"#a78bfa"},{word:"Aeropuerto",en:"Airport",ph:"ah-eh-roh-PWER-toh",tts:"aeropuerto",icon:"✈️",color:"#60a5fa"},{word:"Calle",en:"Street",ph:"KAH-yeh",tts:"calle",icon:"🛣️",color:"#94a3b8"},{word:"Parque",en:"Park",ph:"PAR-keh",tts:"parque",icon:"🌳",color:"#34d399"},{word:"Baño",en:"Bathroom",ph:"BAH-nyoh",tts:"baño",icon:"🚽",color:"#60a5fa"}]},
  {id:"tiempo",label:"⏰ Tiempo",type:"basic",items:[{word:"Hoy",en:"Today",ph:"oy",tts:"hoy",icon:"📅",color:"#4aa8a0"},{word:"Mañana",en:"Tomorrow",ph:"mah-NYAH-nah",tts:"mañana",icon:"🌅",color:"#f59e0b"},{word:"Ayer",en:"Yesterday",ph:"ah-YER",tts:"ayer",icon:"⏮️",color:"#a78bfa"},{word:"Ahora",en:"Now",ph:"ah-OH-rah",tts:"ahora",icon:"⚡",color:"#34d399"},{word:"Tarde",en:"Late / Afternoon",ph:"TAR-deh",tts:"tarde",icon:"🌆",color:"#fb923c"},{word:"Temprano",en:"Early",ph:"tem-PRAH-noh",tts:"temprano",icon:"🌅",color:"#60a5fa"},{word:"Siempre",en:"Always",ph:"SYEM-preh",tts:"siempre",icon:"♾️",color:"#4aa8a0"},{word:"Nunca",en:"Never",ph:"NOON-kah",tts:"nunca",icon:"🚫",color:"#ef4444"},{word:"A veces",en:"Sometimes",ph:"ah BEH-sehs",tts:"a veces",icon:"🔄",color:"#e8b44a"},{word:"Después",en:"After / Later",ph:"dehs-PWES",tts:"después",icon:"⏩",color:"#f97316"},{word:"Antes",en:"Before",ph:"AN-tehs",tts:"antes",icon:"⏪",color:"#8b5cf6"}]},
  {id:"adjetivos",label:"✨ Adjetivos",type:"basic",items:[{word:"Grande",en:"Big / Large",ph:"GRAN-deh",tts:"grande",icon:"🔼",color:"#4aa8a0"},{word:"Pequeño",en:"Small / Little",ph:"peh-KEH-nyoh",tts:"pequeño",icon:"🔽",color:"#60a5fa"},{word:"Bonito",en:"Pretty / Nice",ph:"boh-NEE-toh",tts:"bonito",icon:"😍",color:"#ec4899"},{word:"Feo",en:"Ugly",ph:"FEH-oh",tts:"feo",icon:"😬",color:"#94a3b8"},{word:"Caro",en:"Expensive",ph:"KAH-roh",tts:"caro",icon:"💸",color:"#ef4444"},{word:"Barato",en:"Cheap",ph:"bah-RAH-toh",tts:"barato",icon:"🏷️",color:"#34d399"},{word:"Rápido",en:"Fast",ph:"RRAH-pee-doh",tts:"rápido",icon:"⚡",color:"#f59e0b"},{word:"Lento",en:"Slow",ph:"LEN-toh",tts:"lento",icon:"🐢",color:"#94a3b8"},{word:"Fácil",en:"Easy",ph:"FAH-seel",tts:"fácil",icon:"😊",color:"#34d399"},{word:"Difícil",en:"Difficult",ph:"dee-FEE-seel",tts:"difícil",icon:"😰",color:"#ef4444"},{word:"Bueno",en:"Good",ph:"BWEH-noh",tts:"bueno",icon:"👍",color:"#34d399"},{word:"Malo",en:"Bad",ph:"MAH-loh",tts:"malo",icon:"👎",color:"#ef4444"},{word:"Nuevo",en:"New",ph:"NWEH-boh",tts:"nuevo",icon:"✨",color:"#a78bfa"},{word:"Viejo",en:"Old",ph:"BYEH-hoh",tts:"viejo",icon:"📜",color:"#92400e"},{word:"Limpio",en:"Clean",ph:"LEEM-pyoh",tts:"limpio",icon:"✅",color:"#34d399"},{word:"Sucio",en:"Dirty",ph:"SOO-syoh",tts:"sucio",icon:"🤢",color:"#92400e"}]},
  {id:"colombianismos",label:"🇨🇴 Colombia",type:"colombianismos"},
  {id:"preguntas",label:"❓ Preguntas",type:"preguntas"},
  {id:"profesiones",label:"👔 Profesiones",type:"basic",items:[
    {word:"estudiante",en:"student",ph:"ehs-too-DYAN-teh",tts:"estudiante",icon:"🎓",color:"#60a5fa"},
    {word:"profesor/a",en:"teacher",ph:"proh-feh-SOR / soh-RAH",tts:"profesor o profesora",icon:"🧑‍🏫",color:"#a78bfa"},
    {word:"ingeniero/a",en:"engineer",ph:"een-heh-NYEH-roh / rah",tts:"ingeniero o ingeniera",icon:"🛠️",color:"#4aa8a0"},
    {word:"médico/a",en:"doctor",ph:"MEH-dee-koh / kah",tts:"médico o médica",icon:"🩺",color:"#ef4444"},
    {word:"enfermero/a",en:"nurse",ph:"en-fer-MEH-roh / rah",tts:"enfermero o enfermera",icon:"🩹",color:"#34d399"},
    {word:"dentista",en:"dentist",ph:"den-TEES-tah",tts:"dentista",icon:"🦷",color:"#60a5fa"},
    {word:"abogado/a",en:"lawyer",ph:"ah-boh-GAH-doh / dah",tts:"abogado o abogada",icon:"⚖️",color:"#e8b44a"},
    {word:"contador/a",en:"accountant",ph:"kon-tah-DOR / doh-rah",tts:"contador o contadora",icon:"🧮",color:"#34d399"},
    {word:"arquitecto/a",en:"architect",ph:"ar-kee-TEHK-toh / tah",tts:"arquitecto o arquitecta",icon:"📐",color:"#f97316"},
    {word:"diseñador/a",en:"designer",ph:"dee-seh-nya-DOR / doh-rah",tts:"diseñador o diseñadora",icon:"🎨",color:"#ec4899"},
    {word:"conductor/a",en:"driver",ph:"kon-dook-TOR / toh-rah",tts:"conductor o conductora",icon:"🚗",color:"#60a5fa"},
    {word:"chef / cocinero/a",en:"chef / cook",ph:"shef / koh-see-NEH-roh",tts:"chef, cocinero o cocinera",icon:"👨‍🍳",color:"#f59e0b"},
    {word:"empresario/a",en:"business owner",ph:"em-preh-SAH-ryoh / ryah",tts:"empresario o empresaria",icon:"💼",color:"#a78bfa"},
    {word:"empleado/a",en:"employee",ph:"em-pleh-AH-doh / dah",tts:"empleado o empleada",icon:"🧑‍💼",color:"#4aa8a0"}
  ]},
  {id:"casa",label:"🏠 Casa",type:"basic",items:[
    {word:"ducha",en:"shower",ph:"DOO-chah",tts:"ducha",icon:"🚿",color:"#60a5fa"},
    {word:"inodoro",en:"toilet",ph:"ee-noh-DOH-roh",tts:"inodoro",icon:"🚽",color:"#94a3b8"},
    {word:"lavamanos",en:"sink",ph:"lah-vah-MAH-nohs",tts:"lavamanos",icon:"🧼",color:"#60a5fa"},
    {word:"jabón",en:"soap",ph:"hah-BON",tts:"jabón",icon:"🧴",color:"#34d399"},
    {word:"toalla",en:"towel",ph:"toh-AH-yah",tts:"toalla",icon:"🧖",color:"#a78bfa"},
    {word:"cepillo de dientes",en:"toothbrush",ph:"seh-PEE-yoh deh DYEN-tehs",tts:"cepillo de dientes",icon:"🪥",color:"#60a5fa"},
    {word:"cama",en:"bed",ph:"KAH-mah",tts:"cama",icon:"🛏️",color:"#a78bfa"},
    {word:"almohada",en:"pillow",ph:"al-moh-AH-dah",tts:"almohada",icon:"🛌",color:"#ec4899"},
    {word:"cobija",en:"blanket",ph:"koh-BEE-hah",tts:"cobija",icon:"🧣",color:"#e85d75"},
    {word:"sábana",en:"sheet",ph:"SAH-bah-nah",tts:"sábana",icon:"🛏️",color:"#60a5fa"},
    {word:"clóset",en:"closet",ph:"KLOH-set",tts:"clóset",icon:"🚪",color:"#a78bfa"},
    {word:"ventana",en:"window",ph:"ben-TAH-nah",tts:"ventana",icon:"🪟",color:"#60a5fa"},
    {word:"puerta",en:"door",ph:"PWER-tah",tts:"puerta",icon:"🚪",color:"#f59e0b"},
    {word:"luz",en:"light",ph:"loos",tts:"luz",icon:"💡",color:"#e8b44a"},
    {word:"habitación",en:"bedroom / room",ph:"ah-bee-tah-SYON",tts:"habitación",icon:"🛋️",color:"#4aa8a0"}
  ]},
  {id:"direcciones",label:"🧭 Direcciones",type:"basic",items:[
    {word:"carro",en:"car",ph:"KAH-rroh",tts:"carro",icon:"🚗",color:"#60a5fa"},
    {word:"moto",en:"motorcycle",ph:"MOH-toh",tts:"moto",icon:"🏍️",color:"#e85d75"},
    {word:"pasajero/a",en:"passenger",ph:"pah-sah-HEH-roh / rah",tts:"pasajero o pasajera",icon:"🧍",color:"#a78bfa"},
    {word:"dirección",en:"address",ph:"dee-rehk-SYON",tts:"dirección",icon:"📍",color:"#f97316"},
    {word:"derecha",en:"right",ph:"deh-REH-chah",tts:"derecha",icon:"➡️",color:"#34d399"},
    {word:"izquierda",en:"left",ph:"ees-KYER-dah",tts:"izquierda",icon:"⬅️",color:"#34d399"},
    {word:"siga derecho",en:"go straight",ph:"SEE-gah deh-REH-choh",tts:"siga derecho",icon:"⬆️",color:"#4aa8a0"},
    {word:"gire",en:"turn",ph:"HEE-reh",tts:"gire",icon:"↪️",color:"#f59e0b"},
    {word:"semáforo",en:"traffic light",ph:"seh-MAH-foh-roh",tts:"semáforo",icon:"🚦",color:"#ef4444"},
    {word:"esquina",en:"corner",ph:"ehs-KEE-nah",tts:"esquina",icon:"📐",color:"#a78bfa"},
    {word:"parqueadero",en:"parking lot",ph:"par-keh-ah-DEH-roh",tts:"parqueadero",icon:"🅿️",color:"#60a5fa"},
    {word:"gasolina",en:"gas",ph:"gah-soh-LEE-nah",tts:"gasolina",icon:"⛽",color:"#f97316"},
    {word:"trancón",en:"traffic jam",ph:"trahn-KON",tts:"trancón",icon:"🚗",color:"#e85d75"},
    {word:"queda cerca",en:"it is nearby",ph:"KEH-dah SEHR-kah",tts:"queda cerca",icon:"📍",color:"#34d399"},
    {word:"queda lejos",en:"it is far",ph:"KEH-dah LEH-hohs",tts:"queda lejos",icon:"🗺️",color:"#a78bfa"}
  ]},
  {id:"cocina",label:"🍳 Cocina",type:"basic",items:[
    {word:"cocinar",en:"to cook",ph:"koh-see-NAR",tts:"cocinar",icon:"👩‍🍳",color:"#f59e0b"},
    {word:"cortar",en:"to cut",ph:"kor-TAR",tts:"cortar",icon:"🔪",color:"#e85d75"},
    {word:"mezclar",en:"to mix",ph:"mes-KLAR",tts:"mezclar",icon:"🥣",color:"#a78bfa"},
    {word:"probar",en:"to taste / try",ph:"proh-BAR",tts:"probar",icon:"😋",color:"#34d399"},
    {word:"lavar",en:"to wash",ph:"lah-BAR",tts:"lavar",icon:"🧼",color:"#60a5fa"},
    {word:"hervir",en:"to boil",ph:"er-BEER",tts:"hervir",icon:"♨️",color:"#ef4444"},
    {word:"freír",en:"to fry",ph:"freh-EER",tts:"freír",icon:"🍳",color:"#f97316"},
    {word:"olla",en:"pot",ph:"OH-yah",tts:"olla",icon:"🍲",color:"#94a3b8"},
    {word:"sartén",en:"pan",ph:"sar-TEN",tts:"sartén",icon:"🍳",color:"#94a3b8"},
    {word:"cuchillo",en:"knife",ph:"koo-CHEE-yoh",tts:"cuchillo",icon:"🔪",color:"#60a5fa"},
    {word:"cuchara",en:"spoon",ph:"koo-CHAR-ah",tts:"cuchara",icon:"🥄",color:"#a78bfa"},
    {word:"plato",en:"plate / dish",ph:"PLAH-toh",tts:"plato",icon:"🍽️",color:"#4aa8a0"},
    {word:"sal",en:"salt",ph:"sahl",tts:"sal",icon:"🧂",color:"#94a3b8"},
    {word:"azúcar",en:"sugar",ph:"ah-SOO-kar",tts:"azúcar",icon:"🍬",color:"#ec4899"}
  ]},
  {id:"gustos",label:"❤️ Gustos",type:"basic",items:[
    {word:"Me gusta la música.",en:"I like music.",ph:"",tts:"Me gusta la música.",icon:"🎵",color:"#ec4899"},
    {word:"Me gusta el deporte.",en:"I like sports.",ph:"",tts:"Me gusta el deporte.",icon:"⚽",color:"#34d399"},
    {word:"Me gusta leer.",en:"I like to read.",ph:"",tts:"Me gusta leer.",icon:"📚",color:"#a78bfa"},
    {word:"Me gusta viajar.",en:"I like to travel.",ph:"",tts:"Me gusta viajar.",icon:"✈️",color:"#60a5fa"},
    {word:"Me gusta cocinar.",en:"I like to cook.",ph:"",tts:"Me gusta cocinar.",icon:"🍳",color:"#f59e0b"},
    {word:"Me gusta ver películas.",en:"I like watching movies.",ph:"",tts:"Me gusta ver películas.",icon:"🎬",color:"#e85d75"},
    {word:"Me gusta pasar tiempo con mi familia.",en:"I like spending time with my family.",ph:"",tts:"Me gusta pasar tiempo con mi familia.",icon:"👨‍👩‍👧",color:"#4aa8a0"},
    {word:"Me gustan los animales.",en:"I like animals.",ph:"",tts:"Me gustan los animales.",icon:"🐶",color:"#f97316"},
    {word:"Me gustan los videojuegos.",en:"I like video games.",ph:"",tts:"Me gustan los videojuegos.",icon:"🎮",color:"#a78bfa"},
    {word:"Me gustan las redes sociales.",en:"I like social media.",ph:"",tts:"Me gustan las redes sociales.",icon:"📱",color:"#60a5fa"},
    {word:"Es divertido.",en:"It is fun.",ph:"",tts:"Es divertido.",icon:"😄",color:"#34d399"},
    {word:"Es interesante.",en:"It is interesting.",ph:"",tts:"Es interesante.",icon:"💡",color:"#e8b44a"},
    {word:"Es aburrido.",en:"It is boring.",ph:"",tts:"Es aburrido.",icon:"🥱",color:"#94a3b8"},
    {word:"Es fácil.",en:"It is easy.",ph:"",tts:"Es fácil.",icon:"😊",color:"#34d399"},
    {word:"Es difícil.",en:"It is difficult.",ph:"",tts:"Es difícil.",icon:"😰",color:"#ef4444"},
    {word:"Es delicioso.",en:"It is delicious.",ph:"",tts:"Es delicioso.",icon:"😋",color:"#f59e0b"},
    {word:"Es horrible.",en:"It is horrible.",ph:"",tts:"Es horrible.",icon:"😖",color:"#e85d75"}
  ]},
  /* ── NEW v13: TV · Descanso (restored) ── */
  {id:"tv",label:"📺 TV · Descanso",type:"basic",items:[
    {word:"Televisión",en:"Television",ph:"teh-leh-bee-SYOHN",tts:"televisión",icon:"📺",color:"#60a5fa"},
    {word:"Película",en:"Movie",ph:"peh-LEE-koo-lah",tts:"película",icon:"🎬",color:"#e85d75"},
    {word:"Serie",en:"Series",ph:"SEH-ryeh",tts:"serie",icon:"🎞️",color:"#a78bfa"},
    {word:"Noticias",en:"News",ph:"noh-TEE-syahs",tts:"noticias",icon:"📰",color:"#94a3b8"},
    {word:"Programa",en:"Show",ph:"proh-GRAH-mah",tts:"programa",icon:"📡",color:"#4aa8a0"},
    {word:"Control remoto",en:"Remote control",ph:"kon-TROL rreh-MOH-toh",tts:"control remoto",icon:"🎛️",color:"#f59e0b"},
    {word:"Sofá",en:"Sofa",ph:"soh-FAH",tts:"sofá",icon:"🛋️",color:"#92400e"},
    {word:"Descansar",en:"To rest",ph:"dehs-kan-SAR",tts:"descansar",icon:"😌",color:"#34d399"},
    {word:"Relajarse",en:"To relax",ph:"rreh-lah-HAR-seh",tts:"relajarse",icon:"🧘",color:"#a78bfa"},
    {word:"Ver televisión",en:"To watch TV",ph:"ber teh-leh-bee-SYOHN",tts:"ver televisión",icon:"👀",color:"#60a5fa"},
  ]},
  /* ── NEW v13: Ropa ── */
  {id:"ropa",label:"👕 Ropa",type:"basic",items:[
    {word:"Camisa",en:"Shirt",ph:"kah-MEE-sah",tts:"camisa",icon:"👔",color:"#60a5fa"},
    {word:"Camiseta",en:"T-shirt",ph:"kah-mee-SEH-tah",tts:"camiseta",icon:"👕",color:"#4aa8a0"},
    {word:"Pantalón",en:"Pants",ph:"pan-tah-LOHN",tts:"pantalón",icon:"👖",color:"#3b82f6"},
    {word:"Zapatos",en:"Shoes",ph:"sah-PAH-tohs",tts:"zapatos",icon:"👟",color:"#92400e"},
    {word:"Medias",en:"Socks (Colombian!)",ph:"MEH-dyahs",tts:"medias",icon:"🧦",color:"#e85d75"},
    {word:"Chaqueta",en:"Jacket",ph:"chah-KEH-tah",tts:"chaqueta",icon:"🧥",color:"#a78bfa"},
    {word:"Saco",en:"Sweater (Colombian!)",ph:"SAH-koh",tts:"saco",icon:"🧶",color:"#e8b44a"},
    {word:"Vestido",en:"Dress",ph:"behs-TEE-doh",tts:"vestido",icon:"👗",color:"#ec4899"},
    {word:"Falda",en:"Skirt",ph:"FAL-dah",tts:"falda",icon:"👚",color:"#f9a8d4"},
    {word:"Sombrero",en:"Hat",ph:"som-BREH-roh",tts:"sombrero",icon:"👒",color:"#f59e0b"},
    {word:"Gafas",en:"Glasses",ph:"GAH-fahs",tts:"gafas",icon:"👓",color:"#94a3b8"},
    {word:"Reloj",en:"Watch / Clock",ph:"rreh-LOH",tts:"reloj",icon:"⌚",color:"#64748b"},
  ]},
  /* ── NEW v13: Animales ── */
  {id:"animales",label:"🐾 Animales",type:"basic",items:[
    {word:"Perro",en:"Dog",ph:"PEH-rroh",tts:"perro",icon:"🐕",color:"#e8b44a"},
    {word:"Gato",en:"Cat",ph:"GAH-toh",tts:"gato",icon:"🐈",color:"#94a3b8"},
    {word:"Pájaro",en:"Bird",ph:"PAH-hah-roh",tts:"pájaro",icon:"🐦",color:"#60a5fa"},
    {word:"Pez",en:"Fish",ph:"pehs",tts:"pez",icon:"🐟",color:"#3b82f6"},
    {word:"Caballo",en:"Horse",ph:"kah-BAH-yoh",tts:"caballo",icon:"🐴",color:"#92400e"},
    {word:"Vaca",en:"Cow",ph:"BAH-kah",tts:"vaca",icon:"🐄",color:"#94a3b8"},
    {word:"Gallina",en:"Hen / Chicken",ph:"gah-YEE-nah",tts:"gallina",icon:"🐔",color:"#f59e0b"},
    {word:"Cerdo",en:"Pig",ph:"SER-doh",tts:"cerdo",icon:"🐷",color:"#ec4899"},
    {word:"Mono",en:"Monkey",ph:"MOH-noh",tts:"mono",icon:"🐒",color:"#e8b44a"},
    {word:"Mariposa",en:"Butterfly",ph:"mah-ree-POH-sah",tts:"mariposa",icon:"🦋",color:"#a78bfa"},
    {word:"Mosca",en:"Fly",ph:"MOHS-kah",tts:"mosca",icon:"🪰",color:"#64748b"},
    {word:"Culebra",en:"Snake (Colombian!)",ph:"koo-LEH-brah",tts:"culebra",icon:"🐍",color:"#34d399"},
  ]},
  /* ── NEW v13: Clima ── */
  {id:"clima",label:"🌤️ Clima",type:"basic",items:[
    {word:"Clima",en:"Weather",ph:"KLEE-mah",tts:"clima",icon:"🌡️",color:"#4aa8a0"},
    {word:"Sol",en:"Sun",ph:"sohl",tts:"sol",icon:"☀️",color:"#f59e0b"},
    {word:"Lluvia",en:"Rain",ph:"YOO-byah",tts:"lluvia",icon:"🌧️",color:"#60a5fa"},
    {word:"Nube",en:"Cloud",ph:"NOO-beh",tts:"nube",icon:"☁️",color:"#94a3b8"},
    {word:"Viento",en:"Wind",ph:"BYEN-toh",tts:"viento",icon:"💨",color:"#4aa8a0"},
    {word:"Tormenta",en:"Storm",ph:"tor-MEN-tah",tts:"tormenta",icon:"⛈️",color:"#8b5cf6"},
    {word:"Aguacero",en:"Downpour (Colombian!)",ph:"ah-gwah-SEH-roh",tts:"aguacero",icon:"🌧️",color:"#3b82f6"},
    {word:"Hace calor",en:"It's hot",ph:"AH-seh kah-LOR",tts:"hace calor",icon:"🥵",color:"#ef4444"},
    {word:"Hace frío",en:"It's cold",ph:"AH-seh FREE-oh",tts:"hace frío",icon:"🥶",color:"#60a5fa"},
    {word:"Hace sol",en:"It's sunny",ph:"AH-seh sohl",tts:"hace sol",icon:"😎",color:"#f59e0b"},
    {word:"Está lloviendo",en:"It's raining",ph:"ehs-TAH yoh-BYEN-doh",tts:"está lloviendo",icon:"☔",color:"#3b82f6"},
  ]},
  /* ── NEW v13: Tecnología ── */
  {id:"tecnologia",label:"📱 Tecnología",type:"basic",items:[
    {word:"Celular",en:"Cell phone (Colombian!)",ph:"seh-loo-LAR",tts:"celular",icon:"📱",color:"#4aa8a0"},
    {word:"Cargador",en:"Charger",ph:"kar-gah-DOR",tts:"cargador",icon:"🔌",color:"#f59e0b"},
    {word:"Computador",en:"Computer (Colombian!)",ph:"kom-poo-tah-DOR",tts:"computador",icon:"💻",color:"#60a5fa"},
    {word:"Wifi",en:"Wifi",ph:"WEE-fee",tts:"wifi",icon:"📶",color:"#34d399"},
    {word:"Aplicación",en:"App",ph:"ah-plee-kah-SYOHN",tts:"aplicación",icon:"📲",color:"#a78bfa"},
    {word:"Mensaje",en:"Message",ph:"men-SAH-heh",tts:"mensaje",icon:"💬",color:"#4aa8a0"},
    {word:"Llamada",en:"Call",ph:"yah-MAH-dah",tts:"llamada",icon:"📞",color:"#e85d75"},
    {word:"Foto",en:"Photo",ph:"FOH-toh",tts:"foto",icon:"📷",color:"#ec4899"},
    {word:"Audífonos",en:"Headphones",ph:"ah-oo-DEE-foh-nohs",tts:"audífonos",icon:"🎧",color:"#8b5cf6"},
    {word:"Pantalla",en:"Screen",ph:"pan-TAH-yah",tts:"pantalla",icon:"🖥️",color:"#94a3b8"},
    {word:"Contraseña",en:"Password",ph:"kon-trah-SEH-nyah",tts:"contraseña",icon:"🔑",color:"#e8b44a"},
    {word:"Batería",en:"Battery",ph:"bah-teh-REE-ah",tts:"batería",icon:"🔋",color:"#34d399"},
  ]},
  /* ── NEW v13: Emociones ── */
  {id:"emociones",label:"😊 Emociones",type:"basic",items:[
    {word:"Feliz",en:"Happy",ph:"feh-LEES",tts:"feliz",icon:"😄",color:"#f59e0b"},
    {word:"Triste",en:"Sad",ph:"TREES-teh",tts:"triste",icon:"😢",color:"#60a5fa"},
    {word:"Cansado/a",en:"Tired",ph:"kan-SAH-doh",tts:"cansado",icon:"😴",color:"#8b5cf6"},
    {word:"Preocupado/a",en:"Worried",ph:"preh-oh-koo-PAH-doh",tts:"preocupado",icon:"😟",color:"#94a3b8"},
    {word:"Emocionado/a",en:"Excited",ph:"eh-moh-syoh-NAH-doh",tts:"emocionado",icon:"🤩",color:"#ec4899"},
    {word:"Bravo/a",en:"Angry (Colombian!)",ph:"BRAH-boh",tts:"bravo",icon:"😠",color:"#ef4444"},
    {word:"Nervioso/a",en:"Nervous",ph:"ner-BYOH-soh",tts:"nervioso",icon:"😬",color:"#e8b44a"},
    {word:"Tranquilo/a",en:"Calm",ph:"tran-KEE-loh",tts:"tranquilo",icon:"😌",color:"#34d399"},
    {word:"Aburrido/a",en:"Bored",ph:"ah-boo-RREE-doh",tts:"aburrido",icon:"🥱",color:"#64748b"},
    {word:"Sorprendido/a",en:"Surprised",ph:"sor-pren-DEE-doh",tts:"sorprendido",icon:"😲",color:"#a78bfa"},
    {word:"Enamorado/a",en:"In love",ph:"eh-nah-moh-RAH-doh",tts:"enamorado",icon:"😍",color:"#e85d75"},
    {word:"Asustado/a",en:"Scared",ph:"ah-soos-TAH-doh",tts:"asustado",icon:"😨",color:"#8b5cf6"},
  ]},
  {id:"acciones",label:"🏃 Acciones diarias",type:"basic",items:[
    {word:"Poner",en:"To put / place",ph:"poh-NEHR",tts:"poner",icon:"📍",color:"#4aa8a0"},
    {word:"Quitar",en:"To remove / take off",ph:"kee-TAR",tts:"quitar",icon:"🧥",color:"#e85d75"},
    {word:"Llevar",en:"To take / carry / wear",ph:"yeh-BAR",tts:"llevar",icon:"👜",color:"#60a5fa"},
    {word:"Traer",en:"To bring",ph:"trah-ER",tts:"traer",icon:"📦",color:"#f59e0b"},
    {word:"Dejar",en:"To leave / let",ph:"deh-HAR",tts:"dejar",icon:"🫳",color:"#a78bfa"},
    {word:"Sacar",en:"To take out",ph:"sah-KAR",tts:"sacar",icon:"🗑️",color:"#34d399"},
    {word:"Meter",en:"To put in",ph:"meh-TEHR",tts:"meter",icon:"📥",color:"#8b5cf6"},
    {word:"Buscar",en:"To look for",ph:"boos-KAR",tts:"buscar",icon:"🔎",color:"#e8b44a"},
    {word:"Encontrar",en:"To find",ph:"en-kon-TRAR",tts:"encontrar",icon:"✅",color:"#34d399"},
    {word:"Esperar",en:"To wait / hope",ph:"ehs-peh-RAR",tts:"esperar",icon:"⏳",color:"#60a5fa"},
    {word:"Ayudar",en:"To help",ph:"ah-yoo-DAR",tts:"ayudar",icon:"🤝",color:"#4aa8a0"},
    {word:"Necesitar",en:"To need",ph:"neh-seh-see-TAR",tts:"necesitar",icon:"❗",color:"#e85d75"},
    {word:"Quedar",en:"To be located / remain",ph:"keh-DAR",tts:"quedar",icon:"📌",color:"#a78bfa"},
    {word:"Volver",en:"To return",ph:"bol-BEHR",tts:"volver",icon:"↩️",color:"#f59e0b"},
    {word:"Seguir",en:"To continue / follow",ph:"seh-GEER",tts:"seguir",icon:"➡️",color:"#60a5fa"},
    {word:"Usar",en:"To use",ph:"oo-SAR",tts:"usar",icon:"🛠️",color:"#34d399"}
  ]},
  {id:"habitacion",label:"🛏️ Habitación",type:"basic",items:[
    {word:"cama",en:"bed",ph:"KAH-mah",tts:"cama",icon:"🛏️",color:"#a78bfa"},{word:"almohada",en:"pillow",ph:"al-moh-AH-dah",tts:"almohada",icon:"🛌",color:"#ec4899"},{word:"cobija",en:"blanket",ph:"koh-BEE-hah",tts:"cobija",icon:"🧣",color:"#e85d75"},{word:"sábana",en:"sheet",ph:"SAH-bah-nah",tts:"sábana",icon:"🛏️",color:"#60a5fa"},{word:"clóset",en:"closet",ph:"KLOH-set",tts:"clóset",icon:"🚪",color:"#a78bfa"},{word:"mesita de noche",en:"nightstand",ph:"meh-SEE-tah deh NOH-cheh",tts:"mesita de noche",icon:"🛋️",color:"#e8b44a"},{word:"lámpara",en:"lamp",ph:"LAM-pah-rah",tts:"lámpara",icon:"💡",color:"#f59e0b"},{word:"espejo",en:"mirror",ph:"ehs-PEH-hoh",tts:"espejo",icon:"🪞",color:"#60a5fa"},{word:"cortina",en:"curtain",ph:"kor-TEE-nah",tts:"cortina",icon:"🪟",color:"#4aa8a0"},{word:"armario",en:"wardrobe",ph:"ar-MAH-ryoh",tts:"armario",icon:"🗄️",color:"#92400e"}
  ]},
  {id:"bano",label:"🚿 Baño",type:"basic",items:[
    {word:"baño",en:"bathroom",ph:"BAH-nyoh",tts:"baño",icon:"🚿",color:"#60a5fa"},{word:"ducha",en:"shower",ph:"DOO-chah",tts:"ducha",icon:"🚿",color:"#60a5fa"},{word:"inodoro",en:"toilet",ph:"ee-noh-DOH-roh",tts:"inodoro",icon:"🚽",color:"#94a3b8"},{word:"lavamanos",en:"sink",ph:"lah-vah-MAH-nohs",tts:"lavamanos",icon:"🧼",color:"#60a5fa"},{word:"jabón",en:"soap",ph:"hah-BON",tts:"jabón",icon:"🧴",color:"#34d399"},{word:"toalla",en:"towel",ph:"toh-AH-yah",tts:"toalla",icon:"🧖",color:"#a78bfa"},{word:"cepillo de dientes",en:"toothbrush",ph:"seh-PEE-yoh deh DYEN-tehs",tts:"cepillo de dientes",icon:"🪥",color:"#60a5fa"},{word:"pasta dental",en:"toothpaste",ph:"PAHS-tah den-TAHL",tts:"pasta dental",icon:"🦷",color:"#34d399"},{word:"papel higiénico",en:"toilet paper",ph:"pah-PEL ee-HYEH-nee-koh",tts:"papel higiénico",icon:"🧻",color:"#fff"},{word:"champú",en:"shampoo",ph:"cham-POO",tts:"champú",icon:"🧴",color:"#ec4899"}
  ]},
  {id:"trabajo",label:"💼 Trabajo",type:"basic",items:[
    {word:"empresa",en:"company",ph:"em-PREH-sah",tts:"empresa",icon:"🏢",color:"#a78bfa"},{word:"jefe/a",en:"boss",ph:"HEH-feh / fah",tts:"jefe o jefa",icon:"👔",color:"#e8b44a"},{word:"cliente",en:"client / customer",ph:"klee-EN-teh",tts:"cliente",icon:"🤝",color:"#4aa8a0"},{word:"compañero/a",en:"coworker",ph:"kom-pah-NYEH-roh / rah",tts:"compañero o compañera",icon:"🧑‍💼",color:"#60a5fa"},{word:"reunión",en:"meeting",ph:"reh-oo-NYON",tts:"reunión",icon:"🗣️",color:"#ec4899"},{word:"proyecto",en:"project",ph:"proh-YEHK-toh",tts:"proyecto",icon:"📋",color:"#f59e0b"},{word:"horario",en:"schedule",ph:"oh-RAH-ryoh",tts:"horario",icon:"🕘",color:"#34d399"},{word:"sueldo",en:"salary",ph:"SWEHL-doh",tts:"sueldo",icon:"💰",color:"#e8b44a"},{word:"entrevista",en:"interview",ph:"en-treh-BEES-tah",tts:"entrevista",icon:"📝",color:"#a78bfa"},{word:"negocio",en:"business",ph:"neh-GOH-syoh",tts:"negocio",icon:"🏪",color:"#e85d75"}
  ]},
  {id:"oficina",label:"🖥️ Oficina",type:"basic",items:[
    {word:"computador",en:"computer (Colombian)",ph:"kom-poo-tah-DOR",tts:"computador",icon:"💻",color:"#60a5fa"},{word:"escritorio",en:"desk",ph:"ehs-kree-TOH-ryoh",tts:"escritorio",icon:"🪑",color:"#92400e"},{word:"teclado",en:"keyboard",ph:"teh-KLAH-doh",tts:"teclado",icon:"⌨️",color:"#94a3b8"},{word:"pantalla",en:"screen",ph:"pan-TAH-yah",tts:"pantalla",icon:"🖥️",color:"#60a5fa"},{word:"impresora",en:"printer",ph:"eem-preh-SOH-rah",tts:"impresora",icon:"🖨️",color:"#a78bfa"},{word:"documento",en:"document",ph:"doh-koo-MEN-toh",tts:"documento",icon:"📄",color:"#fff"},{word:"correo electrónico",en:"email",ph:"koh-RREH-oh eh-lehk-TROH-nee-koh",tts:"correo electrónico",icon:"📧",color:"#4aa8a0"},{word:"archivo",en:"file",ph:"ar-CHEE-boh",tts:"archivo",icon:"🗂️",color:"#f59e0b"},{word:"silla",en:"chair",ph:"SEE-yah",tts:"silla",icon:"🪑",color:"#34d399"}
  ]},
  {id:"carropartes",label:"🚗 Partes del carro",type:"basic",items:[
    {word:"motor",en:"engine",ph:"moh-TOR",tts:"motor",icon:"⚙️",color:"#94a3b8"},{word:"llanta",en:"tire (Colombian)",ph:"YAN-tah",tts:"llanta",icon:"🛞",color:"#e85d75"},{word:"volante",en:"steering wheel",ph:"boh-LAN-teh",tts:"volante",icon:"⭕",color:"#60a5fa"},{word:"freno",en:"brake",ph:"FREH-noh",tts:"freno",icon:"🛑",color:"#e85d75"},{word:"batería",en:"battery",ph:"bah-teh-REE-ah",tts:"batería",icon:"🔋",color:"#34d399"},{word:"parabrisas",en:"windshield",ph:"pah-rah-BREE-sahs",tts:"parabrisas",icon:"🚘",color:"#60a5fa"},{word:"espejo retrovisor",en:"rearview mirror",ph:"ehs-PEH-hoh rreh-troh-bee-SOR",tts:"espejo retrovisor",icon:"🪞",color:"#a78bfa"},{word:"placa",en:"license plate",ph:"PLAH-kah",tts:"placa",icon:"🔖",color:"#e8b44a"},{word:"baúl",en:"trunk",ph:"bah-OOL",tts:"baúl",icon:"🧳",color:"#92400e"},{word:"capó",en:"hood",ph:"kah-POH",tts:"capó",icon:"🚗",color:"#f59e0b"},{word:"puerta",en:"door",ph:"PWER-tah",tts:"puerta",icon:"🚪",color:"#4aa8a0"}
  ]},
];

/* ── Vocabulary examples ─────────────────────────────────────────────────────
   One example per basic vocabulary item, in the same order as its category. */
const VOCAB_EXAMPLES={
  meses:[
    ["En enero hace frío en Bogotá.","In January it is cold in Bogotá."],["En febrero practico español.","In February I practice Spanish."],["En marzo tengo una reunión.","In March I have a meeting."],["En abril viajo a Medellín.","In April I travel to Medellín."],["En mayo visito a mi mamá.","In May I visit my mom."],["En junio celebro mi cumpleaños.","In June I celebrate my birthday."],["En julio quiero descansar.","In July I want to rest."],["En agosto voy a trabajar.","In August I am going to work."],["En septiembre empieza mi curso.","My course starts in September."],["En octubre llueve mucho.","It rains a lot in October."],["En noviembre compro regalos.","In November I buy gifts."],["En diciembre paso tiempo con mi familia.","In December I spend time with my family."]
  ],
  colores:[
    ["La bandera tiene una franja roja.","The flag has a red stripe."],["El cielo está azul esta mañana.","The sky is blue this morning."],["La camisa verde combina con mis zapatos.","The green shirt matches my shoes."],["El taxi amarillo está esperando.","The yellow taxi is waiting."],["Compré una naranja grande.","I bought a large orange."],["El vestido rosado es bonito.","The pink dress is pretty."],["Mi mochila morada está aquí.","My purple backpack is here."],["La camisa blanca está limpia.","The white shirt is clean."],["El gato negro duerme.","The black cat is sleeping."],["La mesa café está en la cocina.","The brown table is in the kitchen."],["El cielo está gris hoy.","The sky is gray today."]
  ],
  dias:[
    ["El lunes trabajo en la oficina.","On Monday I work in the office."],["El martes estudio español.","On Tuesday I study Spanish."],["El miércoles tengo una cita.","On Wednesday I have an appointment."],["El jueves cocino en casa.","On Thursday I cook at home."],["El viernes salgo temprano.","On Friday I leave early."],["El sábado descanso.","On Saturday I rest."],["El domingo visito a mi familia.","On Sunday I visit my family."]
  ],
  familia:[
    ["Mi mamá vive en Colombia.","My mom lives in Colombia."],["Mi papá trabaja en una empresa.","My dad works at a company."],["Mi hermano estudia español.","My brother studies Spanish."],["Mi hermana vive cerca.","My sister lives nearby."],["Mi abuelo cuenta historias.","My grandfather tells stories."],["Mi abuela cocina muy bien.","My grandmother cooks very well."],["Mi tío maneja un carro azul.","My uncle drives a blue car."],["Mi tía trabaja en un hospital.","My aunt works at a hospital."],["Mi hijo juega en el parque.","My son plays in the park."],["Mi hija lee una historia.","My daughter reads a story."]
  ],
  cuerpo:[
    ["Tengo dolor de cabeza después de trabajar.","I have a headache after working."],["Mi ojo derecho está rojo.","My right eye is red."],["Me limpié la oreja con cuidado.","I cleaned my ear carefully."],["Tengo la nariz tapada.","My nose is blocked."],["Me lavo la boca después de comer.","I wash my mouth after eating."],["Giro el cuello lentamente.","I turn my neck slowly."],["Llevo la mochila en el hombro.","I carry the backpack on my shoulder."],["Me golpeé el brazo con la puerta.","I hit my arm on the door."],["Dame la mano, por favor.","Give me your hand, please."],["Me corté el dedo al cocinar.","I cut my finger while cooking."],["La pierna derecha me duele.","My right leg hurts."],["Me duele el pie después de caminar.","My foot hurts after walking."],["El corazón late rápido cuando corro.","My heart beats fast when I run."],["Tengo el estómago lleno.","My stomach is full."],["Me duele la espalda por estar sentado.","My back hurts from sitting."]
  ],
  comida:[
    ["Quiero agua, por favor.","I want water, please."],["Tomo café en la mañana.","I drink coffee in the morning."],["¿Me regala un tinto?","Can I have a black coffee?"],["El jugo está delicioso.","The juice is delicious."],["¿Quieres una cerveza?","Do you want a beer?"],["La leche está en la nevera.","The milk is in the refrigerator."],["Como pan con huevo.","I eat bread with egg."],["Me gusta el arroz.","I like rice."],["El pollo está listo.","The chicken is ready."],["No como mucha carne.","I do not eat much meat."],["Me gusta la arepa.","I like arepa."],["El aguacate está maduro.","The avocado is ripe."],["Como fruta todos los días.","I eat fruit every day."],["Quiero un huevo para el desayuno.","I want an egg for breakfast."],["La bandeja paisa es muy completa.","Bandeja paisa is very filling."]
  ],
  lugares:[
    ["Mi casa está cerca.","My house is nearby."],["Voy a la tienda.","I am going to the store."],["Compro fruta en el mercado.","I buy fruit at the market."],["Tengo que ir al banco.","I have to go to the bank."],["El hospital queda lejos.","The hospital is far away."],["Voy a la farmacia.","I am going to the pharmacy."],["Nos vemos en el restaurante.","See you at the restaurant."],["El hotel está aquí.","The hotel is here."],["El aeropuerto queda cerca.","The airport is nearby."],["Cruzo la calle.","I cross the street."],["El parque queda cerca.","The park is nearby."],["¿Dónde está el baño?","Where is the bathroom?"]
  ],
  tiempo:[
    ["Hoy practico español.","Today I practice Spanish."],["Mañana voy a trabajar.","Tomorrow I am going to work."],["Ayer cené en casa.","Yesterday I had dinner at home."],["Ahora estoy ocupado.","I am busy now."],["Llego tarde.","I am arriving late."],["Me levanto temprano.","I get up early."],["Siempre tomo café.","I always drink coffee."],["Nunca tomo cerveza.","I never drink beer."],["A veces cocino.","Sometimes I cook."],["Te llamo después.","I will call you later."],["Antes trabajaba en un banco.","I used to work at a bank."]
  ],
  adjetivos:[
    ["El carro es grande.","The car is big."],["El apartamento es pequeño.","The apartment is small."],["El parque es bonito.","The park is pretty."],["El tráfico es feo hoy.","The traffic is ugly today."],["El hotel es caro.","The hotel is expensive."],["Este restaurante es barato.","This restaurant is cheap."],["El carro es rápido.","The car is fast."],["El servicio es lento.","The service is slow."],["El ejercicio es fácil.","The exercise is easy."],["La pregunta es difícil.","The question is difficult."],["El café está bueno.","The coffee is good."],["El tiempo está malo hoy.","The weather is bad today."],["Mi celular es nuevo.","My cell phone is new."],["Mi carro es viejo.","My car is old."],["El baño está limpio.","The bathroom is clean."],["El plato está sucio.","The plate is dirty."]
  ],
  profesiones:[
    ["Soy estudiante.","I am a student."],["Mi hermana es profesora.","My sister is a teacher."],["Mi hermano es ingeniero.","My brother is an engineer."],["Necesito un médico.","I need a doctor."],["La enfermera trabaja aquí.","The nurse works here."],["El dentista revisa mis dientes.","The dentist checks my teeth."],["Mi abogado me ayuda.","My lawyer helps me."],["El contador revisa las cuentas.","The accountant checks the accounts."],["El arquitecto diseña la casa.","The architect designs the house."],["La diseñadora trabaja en una oficina.","The designer works in an office."],["El conductor maneja el carro.","The driver drives the car."],["El chef prepara la comida.","The chef prepares the food."],["El empresario tiene un negocio.","The business owner has a business."],["El empleado llega temprano.","The employee arrives early."]
  ],
  casa:[
    ["Me ducho por la mañana.","I shower in the morning."],["El inodoro está limpio.","The toilet is clean."],["Lavo mis manos en el lavamanos.","I wash my hands in the sink."],["El jabón está en la ducha.","The soap is in the shower."],["La toalla está aquí.","The towel is here."],["Uso el cepillo de dientes todos los días.","I use the toothbrush every day."],["La cama está en la habitación.","The bed is in the bedroom."],["La almohada es cómoda.","The pillow is comfortable."],["La cobija está sobre la cama.","The blanket is on the bed."],["La sábana está limpia.","The sheet is clean."],["La ropa está en el clóset.","The clothes are in the closet."],["Abro la ventana.","I open the window."],["Cierro la puerta.","I close the door."],["Enciendo la luz.","I turn on the light."],["Mi habitación es pequeña.","My bedroom is small."]
  ],
  direcciones:[
    ["El carro está aquí.","The car is here."],["Voy en moto.","I am going by motorcycle."],["El pasajero espera afuera.","The passenger waits outside."],["Escriba la dirección.","Write down the address."],["Gire a la derecha.","Turn right."],["Gire a la izquierda.","Turn left."],["Siga derecho, por favor.","Go straight, please."],["Gire en la esquina.","Turn at the corner."],["El semáforo está en rojo.","The traffic light is red."],["Nos vemos en la esquina.","See you at the corner."],["El parqueadero está cerca.","The parking lot is nearby."],["Necesito gasolina.","I need gas."],["Hay un trancón.","There is a traffic jam."],["El hotel queda cerca.","The hotel is nearby."],["El hospital queda lejos.","The hospital is far away."]
  ],
  cocina:[
    ["Me gusta cocinar.","I like to cook."],["Voy a cortar las verduras.","I am going to cut the vegetables."],["Voy a mezclar la salsa.","I am going to mix the sauce."],["Quiero probar la sopa.","I want to taste the soup."],["Voy a lavar los platos.","I am going to wash the dishes."],["Voy a hervir el agua.","I am going to boil the water."],["Voy a freír un huevo.","I am going to fry an egg."],["La olla está en la cocina.","The pot is in the kitchen."],["La sartén está caliente.","The pan is hot."],["El cuchillo está en el cajón.","The knife is in the drawer."],["La cuchara está en la mesa.","The spoon is on the table."],["El plato está limpio.","The plate is clean."],["No le pongas mucha sal.","Do not add too much salt."],["Necesito azúcar para el café.","I need sugar for the coffee."]
  ],
  gustos:[
    ["A mí también me gusta la música.","I like music too."],["A mí también me gusta el deporte.","I like sports too."],["Me gusta leer por la noche.","I like to read at night."],["Me gusta viajar a Colombia.","I like to travel to Colombia."],["Me gusta cocinar con mi familia.","I like to cook with my family."],["Me gusta ver películas los viernes.","I like watching movies on Fridays."],["Los domingos me gusta pasar tiempo con mi familia en la finca.","On Sundays I like spending time with my family at the farm."],["A mis hijos les gustan los animales.","My children like animals."],["A mi hermano le gustan los videojuegos.","My brother likes video games."],["A mis amigos les gustan las redes sociales.","My friends like social media."],["Aprender español es divertido.","Learning Spanish is fun."],["Es interesante conocer Colombia.","It is interesting to learn about Colombia."],["El trabajo no es aburrido.","The work is not boring."],["Este ejercicio es fácil.","This exercise is easy."],["La pronunciación es difícil al principio.","Pronunciation is difficult at first."],["El desayuno está delicioso.","Breakfast is delicious."],["Ese programa es horrible.","That show is horrible."]
  ],
  tv:[
    ["Veo televisión por la noche.","I watch television at night."],["La película empieza a las ocho.","The movie starts at eight."],["Esta serie es muy buena.","This series is very good."],["Escucho las noticias.","I listen to the news."],["¿Qué programa quieres ver?","What show do you want to watch?"],["¿Dónde está el control remoto?","Where is the remote control?"],["Estoy sentado en el sofá.","I am sitting on the sofa."],["Necesito descansar.","I need to rest."],["Quiero relajarme.","I want to relax."],["Voy a ver televisión.","I am going to watch television."]
  ],
  ropa:[
    ["Mi camisa es azul.","My shirt is blue."],["Llevo una camiseta blanca.","I am wearing a white T-shirt."],["El pantalón es negro.","The pants are black."],["Mis zapatos están limpios.","My shoes are clean."],["Necesito comprar medias.","I need to buy socks."],["La chaqueta es nueva.","The jacket is new."],["Mi saco es cómodo.","My sweater is comfortable."],["El vestido es bonito.","The dress is pretty."],["La falda es roja.","The skirt is red."],["El sombrero es grande.","The hat is big."],["Necesito mis gafas.","I need my glasses."],["Mi reloj está en la mesa.","My watch is on the table."]
  ],
  animales:[
    ["Tengo un perro.","I have a dog."],["Mi gato duerme.","My cat sleeps."],["El pájaro canta.","The bird sings."],["Vi un pez.","I saw a fish."],["El caballo corre.","The horse runs."],["La vaca come.","The cow eats."],["La gallina puso un huevo.","The hen laid an egg."],["El cerdo está en la granja.","The pig is on the farm."],["El mono come una banana.","The monkey eats a banana."],["La mariposa es bonita.","The butterfly is pretty."],["Hay una mosca en la cocina.","There is a fly in the kitchen."],["Vi una culebra.","I saw a snake."]
  ],
  clima:[
    ["El clima está bueno hoy.","The weather is good today."],["Hace mucho sol.","It is very sunny."],["La lluvia empieza ahora.","The rain starts now."],["Hay una nube grande.","There is a big cloud."],["El viento está fuerte.","The wind is strong."],["La tormenta llega esta tarde.","The storm arrives this afternoon."],["Cayó un aguacero.","A downpour fell."],["Hoy hace calor.","It is hot today."],["Hoy hace frío.","It is cold today."],["Hace sol en Medellín.","It is sunny in Medellín."],["Está lloviendo.","It is raining."]
  ],
  tecnologia:[
    ["Mi celular está en la mesa.","My cell phone is on the table."],["Necesito el cargador.","I need the charger."],["El computador está encendido.","The computer is on."],["El wifi no funciona.","The Wi-Fi does not work."],["Descargué una aplicación.","I downloaded an app."],["Te mando un mensaje.","I am sending you a message."],["Tengo una llamada.","I have a call."],["Tomé una foto.","I took a photo."],["Mis audífonos están aquí.","My headphones are here."],["La pantalla está rota.","The screen is broken."],["No recuerdo la contraseña.","I do not remember the password."],["La batería está baja.","The battery is low."]
  ],
  emociones:[
    ["Estoy feliz hoy.","I am happy today."],["Estoy triste.","I am sad."],["Estoy cansado.","I am tired."],["Estoy preocupado.","I am worried."],["Estoy emocionado.","I am excited."],["Estoy bravo.","I am angry."],["Estoy nervioso.","I am nervous."],["Estoy tranquilo.","I am calm."],["Estoy aburrido.","I am bored."],["Estoy sorprendido.","I am surprised."],["Estoy enamorado.","I am in love."],["Estoy asustado.","I am scared."]
  ],
  habitacion:[
    ["La cama está en la habitación.","The bed is in the bedroom."],["La almohada es cómoda.","The pillow is comfortable."],["La cobija está sobre la cama.","The blanket is on the bed."],["La sábana está limpia.","The sheet is clean."],["La ropa está en el clóset.","The clothes are in the closet."],["La mesita de noche está junto a la cama.","The nightstand is next to the bed."],["La lámpara está encendida.","The lamp is on."],["Me miro en el espejo.","I look at myself in the mirror."],["Abro la cortina.","I open the curtain."],["El armario está lleno.","The wardrobe is full."]
  ],
  bano:[
    ["El baño está al fondo.","The bathroom is at the back."],["Me ducho por la mañana.","I shower in the morning."],["El inodoro está limpio.","The toilet is clean."],["El lavamanos está aquí.","The sink is here."],["El jabón está junto a la ducha.","The soap is next to the shower."],["La toalla está seca.","The towel is dry."],["Uso el cepillo de dientes.","I use the toothbrush."],["Necesito pasta dental.","I need toothpaste."],["El papel higiénico está en el baño.","The toilet paper is in the bathroom."],["El champú está en la ducha.","The shampoo is in the shower."]
  ],
  trabajo:[
    ["Trabajo en una empresa.","I work at a company."],["Mi jefe está en una reunión.","My boss is in a meeting."],["El cliente llega a las diez.","The client arrives at ten."],["Mi compañero me ayuda.","My coworker helps me."],["Tengo una reunión.","I have a meeting."],["El proyecto empieza hoy.","The project starts today."],["Mi horario cambia mañana.","My schedule changes tomorrow."],["Recibo mi sueldo el viernes.","I receive my salary on Friday."],["Tengo una entrevista.","I have an interview."],["Mi negocio está en el centro.","My business is downtown."]
  ],
  oficina:[
    ["El computador está en el escritorio.","The computer is on the desk."],["Mi escritorio está junto a la ventana.","My desk is next to the window."],["El teclado está limpio.","The keyboard is clean."],["La pantalla está encendida.","The screen is on."],["La impresora no funciona.","The printer does not work."],["Necesito el documento.","I need the document."],["Te mando un correo electrónico.","I am sending you an email."],["Guarda el archivo.","Save the file."],["La silla es cómoda.","The chair is comfortable."]
  ],
  carropartes:[
    ["El motor funciona bien.","The engine works well."],["La llanta está baja.","The tire is low."],["El volante está duro.","The steering wheel is stiff."],["El freno suena.","The brake makes a noise."],["La batería está baja.","The battery is low."],["El parabrisas está limpio.","The windshield is clean."],["Miro el espejo retrovisor.","I look at the rearview mirror."],["La placa está sucia.","The license plate is dirty."],["El equipaje está en el baúl.","The luggage is in the trunk."],["Abro el capó.","I open the hood."],["Cierro la puerta.","I close the door."]
  ],
  acciones:[
    ["Voy a poner la mesa.","I am going to set the table."],["Quítate la chaqueta; hace calor.","Take off your jacket; it is hot."],["Llevo las llaves en el bolsillo.","I carry the keys in my pocket."],["¿Me traes un tinto, por favor?","Will you bring me a black coffee, please?"],["Puedes dejar la mochila aquí.","You can leave the backpack here."],["Voy a sacar la basura.","I am going to take out the trash."],["Mete la ropa en el clóset.","Put the clothes in the closet."],["Estoy buscando mi celular.","I am looking for my cell phone."],["Por fin encontré mis llaves.","I finally found my keys."],["Te espero en la esquina.","I will wait for you on the corner."],["¿Me ayudas con esta caja?","Can you help me with this box?"],["Necesito comprar mercado.","I need to buy groceries."],["El banco queda cerca.","The bank is nearby."],["Voy a volver después del trabajo.","I am going to return after work."],["Sigue derecho hasta la esquina.","Continue straight to the corner."],["Uso el celular para estudiar.","I use my cell phone to study."]
  ]
};

const COLOMBIANISMOS=[
  {word:"¿Qué más?",en:"What's up? / How's it going?",usage:"The most common Colombian greeting. Used instead of ¿Cómo estás? with friends.",example:"¡Hola! ¿Qué más, parce?",tts:"¿Qué más?"},
  {word:"¡Venga!",en:"Come on! / OK! / Come here!",usage:"One word, many meanings. ¡Venga! = OK/agreed. Venga acá = Come here. ¡Venga, hagámoslo! = Come on, let's do it!",example:"¿Vamos al mercado? — ¡Venga!",tts:"¡Venga!"},
  {word:"Listo",en:"OK / Ready / Got it / Done",usage:"Said constantly. Means you understand or agree. Like saying 'alright' or 'got it' in English.",example:"¿Entendiste? — Sí, listo.",tts:"listo"},
  {word:"Bacano/a",en:"Cool / Great / Awesome",usage:"Very Colombian. 'Qué bacano' = How cool! Used for things, places, people.",example:"¡Qué bacano ese restaurante!",tts:"bacano"},
  {word:"Chévere",en:"Great / Cool / Awesome",usage:"Used across Latin America but very common in Colombia. Similar to 'bacano'.",example:"¡Chévere! Vamos entonces.",tts:"chévere"},
  {word:"Parcero / Parce",en:"Buddy / Friend / Mate",usage:"Like 'mate' or 'buddy'. Very Colombian. Used between friends. Parce is the short form.",example:"¡Parce, qué más!",tts:"parcero"},
  {word:"Tinto",en:"Black coffee (Colombian!)",usage:"In Colombia, tinto = black coffee. In Spain, tinto = red wine. Don't get confused! '¿Un tinto?' means a coffee.",example:"¿Le traigo un tinto?",tts:"tinto"},
  {word:"Plata",en:"Money (not silver!)",usage:"In Colombia plata = money, not silver. 'No tengo plata' = I have no money. Very common everyday word.",example:"No tengo plata para el taxi.",tts:"plata"},
  {word:"Vaina",en:"Thing / Stuff / What's-it",usage:"A catch-all word for anything. Like 'thing' or 'stuff' in English. '¿Qué es esa vaina?' = What is that thing?",example:"Esa vaina no funciona.",tts:"vaina"},
  {word:"¡Uy!",en:"Wow! / Oh! / Oops!",usage:"Expression of surprise, shock, or mild pain. Like 'ooh' or 'wow' in English.",example:"¡Uy, qué calor hace!",tts:"uy"},
  {word:"Dale",en:"Go ahead / OK / Sure",usage:"Used to agree or encourage. '¡Dale!' = Go for it! / OK! / Let's go!",example:"¿Empezamos? — ¡Dale!",tts:"dale"},
  {word:"Chimba",en:"Awesome / Amazing (informal!)",usage:"Very informal slang. Only use with close friends. Qué chimba = How awesome!",example:"¡Qué chimba de concierto!",tts:"chimba"},
  {word:"Hacer una vuelta",en:"To run an errand",usage:"'Una vuelta' literally means a turn/loop but in Colombia it means running an errand. Very common expression.",example:"Tengo que hacer una vuelta en el banco.",tts:"hacer una vuelta"},
  {word:"¿Me regala...?",en:"Can I have...? / Please give me...",usage:"Literally 'gift me' but used like 'can I have' when ordering or asking for something. Very polite.",example:"¿Me regala un tinto, por favor?",tts:"¿Me regala un tinto, por favor?"},
  {word:"Chino/a",en:"Kid / Boy / Girl",usage:"In Colombia chino = kid/child, NOT Chinese person. '¿Ese chino quién es?' = Who is that kid?",example:"Los chinos están jugando.",tts:"chino"},
  {word:"Berraco/a",en:"Tough / Impressive / Badass",usage:"Can mean hardworking, tough, or impressive. '¡Qué berracos!' = What tough/impressive people!",example:"Ese man es muy berraco.",tts:"berraco"},
  {word:"Juepucha / hijuepucha",en:"Darn! / What the heck!",usage:"A softer euphemism for hijueputa. Still informal; useful to recognize and safer than the stronger form.",example:"¡Juepucha, se me hizo tarde!",tts:"¡Juepucha, se me hizo tarde!"},
  {word:"Hijueputa",en:"Very strong insult / exclamation",usage:"Colombian contraction of hijo de puta. Very strong; understand first and do not use casually.",example:"¡Hijueputa, qué susto!",tts:"¡Hijueputa, qué susto!"},
  {word:"Gonorrea",en:"Very strong insult / intensifier",usage:"Can insult a person or describe something awful. Extremely context-dependent and vulgar; understand first.",example:"¡Qué gonorrea de tráfico!",tts:"¡Qué gonorrea de tráfico!"},
  {word:"Pirobo",en:"Jerk / scumbag",usage:"Strong Colombian insult. Hear it often in arguments, but do not use it casually.",example:"No sea pirobo.",tts:"No sea pirobo."},
  {word:"Malparido/a",en:"Bastard / son of a bitch",usage:"Very strong insult. Understand it, but avoid saying it.",example:"Ese malparido me estafó.",tts:"Ese malparido me estafó."},
  {word:"Carechimba",en:"Asshole / dickhead",usage:"Extremely vulgar Colombian insult. Understand-only.",example:"¡Carechimba!",tts:"¡Carechimba!"},
  {word:"Marica",en:"Dude / idiot (highly context-sensitive)",usage:"Among close friends it can mean dude, but it can also be an offensive slur. Do not use it unless a trusted Colombian friend teaches you the context.",example:"¡Ay, marica, qué susto!",tts:"¡Ay, marica, qué susto!"},
  {word:"Güevón / huevón",en:"Dude / idiot (vulgar)",usage:"Meaning changes with tone and relationship. Hear it often, but understand first; avoid using it with strangers.",example:"No sea güevón.",tts:"No sea güevón."},
  {word:"Puta",en:"Fuck! / Whore (very strong)",usage:"A strong vulgarity whose meaning depends on context. Understand-only for now.",example:"¡Puta, se dañó el carro!",tts:"¡Puta, se dañó el carro!"},
  {word:"No joda / No jodas",en:"No way! / Come on! / Don't mess around!",usage:"Common informal exclamation. Less harsh than the strongest insults, but still not for formal situations.",example:"¡No joda! ¿En serio?",tts:"¡No joda! ¿En serio?"},
  {word:"Qué jartera",en:"What a drag! / What a pain!",usage:"A common Colombian complaint. Mild compared with the strong insults above.",example:"¡Qué jartera tener tanta tarea!",tts:"¡Qué jartera tener tanta tarea!"},
  {word:"Me importa un culo",en:"I don't give a fuck",usage:"Very vulgar way to say you do not care. Understand-only.",example:"Me importa un culo lo que digan.",tts:"Me importa un culo lo que digan."},
];

/* Structured usage labels: the wording remains in the card, while the group
   gives the UI a consistent, scannable signal for when a word is safe to use. */
const REGISTER_PROFILES={
  everyday:{label:"Colombian · everyday",note:"Common in casual Colombian conversation."},
  informal:{label:"Colombian · informal",note:"Natural with friends; avoid in formal situations."},
  danger:{label:"Strong · understand first",note:"Recognize it, but avoid using it until a trusted Colombian explains the context."}
};
const REGISTER_GROUPS={
  informal:["Parcero / Parce","Chimba","Berraco/a","Juepucha / hijuepucha","No joda / No jodas","Qué jartera"],
  danger:["Hijueputa","Gonorrea","Pirobo","Malparido/a","Carechimba","Marica","Güevón / huevón","Puta","Me importa un culo"]
};
COLOMBIANISMOS.forEach(item=>{
  const group=REGISTER_GROUPS.danger.includes(item.word)?"danger":REGISTER_GROUPS.informal.includes(item.word)?"informal":"everyday";
  const profile=REGISTER_PROFILES[group];
  item.registerGroup=item.registerGroup||group;
  item.register=item.register||profile.label;
  item.registerNote=item.registerNote||profile.note;
});

const VOCALES_DATA=[
  {letter:"A",color:"#e85d75",bg:"rgba(232,93,117,0.15)",sound:"ah",examples:[{word:"Abeja",en:"Bee",ph:"ah-BEH-hah",tts:"abeja"},{word:"Árbol",en:"Tree",ph:"AR-bol",tts:"árbol"},{word:"Amor",en:"Love",ph:"ah-MOR",tts:"amor"}]},
  {letter:"E",color:"#a78bfa",bg:"rgba(167,139,250,0.15)",sound:"eh",examples:[{word:"Elefante",en:"Elephant",ph:"eh-leh-FAN-teh",tts:"elefante"},{word:"Estrella",en:"Star",ph:"ehs-TREH-yah",tts:"estrella"},{word:"Escuela",en:"School",ph:"ehs-KWEH-lah",tts:"escuela"}]},
  {letter:"I",color:"#60a5fa",bg:"rgba(96,165,250,0.15)",sound:"ee",examples:[{word:"Iguana",en:"Iguana",ph:"ee-GWAH-nah",tts:"iguana"},{word:"Isla",en:"Island",ph:"EES-lah",tts:"isla"},{word:"Iglesia",en:"Church",ph:"ee-GLEH-syah",tts:"iglesia"}]},
  {letter:"O",color:"#34d399",bg:"rgba(52,211,153,0.15)",sound:"oh",examples:[{word:"Oveja",en:"Sheep",ph:"oh-BEH-hah",tts:"oveja"},{word:"Oso",en:"Bear",ph:"OH-soh",tts:"oso"},{word:"Ojo",en:"Eye",ph:"OH-hoh",tts:"ojo"}]},
  {letter:"U",color:"#f59e0b",bg:"rgba(245,158,11,0.15)",sound:"oo",examples:[{word:"Urraca",en:"Magpie",ph:"oo-RRAH-kah",tts:"urraca"},{word:"Uva",en:"Grape",ph:"OO-bah",tts:"uva"},{word:"Uno",en:"One",ph:"OO-noh",tts:"uno"}]},
];
const PQ=[{word:"¿Quién?",en:"Who?",ph:"kyen",tts:"¿Quién?",example:"¿Quién es? — Who is it?"},{word:"¿Qué?",en:"What?",ph:"keh",tts:"¿Qué?",example:"¿Qué es esto? — What is this?"},{word:"¿Cuándo?",en:"When?",ph:"KWAN-doh",tts:"¿Cuándo?",example:"¿Cuándo es? — When is it?"},{word:"¿Dónde?",en:"Where?",ph:"DON-deh",tts:"¿Dónde?",example:"¿Dónde está? — Where is it?"},{word:"¿Cómo?",en:"How?",ph:"KOH-moh",tts:"¿Cómo?",example:"¿Cómo se dice? — How do you say?"},{word:"¿Por qué?",en:"Why?",ph:"por KEH",tts:"¿Por qué?",example:"¿Por qué? — Why?"},{word:"¿Cuánto?",en:"How much?",ph:"KWAN-toh",tts:"¿Cuánto?",example:"¿Cuánto cuesta? — How much?"},{word:"¿Cuántos?",en:"How many?",ph:"KWAN-tohs",tts:"¿Cuántos?",example:"¿Cuántos son? — How many?"},{word:"¿Cuál?",en:"Which?",ph:"kwal",tts:"¿Cuál?",example:"¿Cuál quiere? — Which one?"},{word:"¿A qué hora?",en:"What time?",ph:"ah keh OH-rah",tts:"¿A qué hora?",example:"¿A qué hora es? — What time?"}];

const FRASES=[
  {section:"💬 Saludos — Informal",cls:"color:var(--teal);background:rgba(74,168,160,0.1);border:1px solid rgba(74,168,160,0.2)",items:[{es:"Hola, ¿cómo estás?",en:"Hi, how are you?"},{es:"¿Cómo te va?",en:"How are you doing?"},{es:"¿Qué más?",en:"What's up? (very Colombian)"},{es:"¿Qué tal?",en:"How are things?"},{es:"Estoy bien, gracias.",en:"I'm fine, thank you."},{es:"Muy bien, ¿y tú?",en:"Very well, and you?"},{es:"Más o menos.",en:"More or less."},{es:"Chao.",en:"Bye! (very Colombian)"}]},
  {section:"🤝 Saludos — Formal",cls:"color:var(--gold);background:rgba(232,180,74,0.1);border:1px solid rgba(232,180,74,0.2)",items:[{es:"Buenos días.",en:"Good morning."},{es:"Buenas tardes.",en:"Good afternoon."},{es:"Buenas noches.",en:"Good evening."},{es:"¿Cómo le va a usted?",en:"How are you? (formal)"},{es:"¡Gusto en conocerle!",en:"Nice to meet you! (formal)"},{es:"¡El gusto es mío!",en:"The pleasure is mine!"},{es:"Igualmente.",en:"Likewise."}]},
  {section:"🛍️ De Compras",cls:"color:var(--pink);background:rgba(232,93,117,0.1);border:1px solid rgba(232,93,117,0.2)",items:[{es:"¿Cuánto cuesta?",en:"How much does it cost?"},{es:"¿Me regala...?",en:"Can I have...? (Colombian!)"},{es:"Es muy caro.",en:"It's very expensive."},{es:"¿Tiene algo más barato?",en:"Do you have something cheaper?"},{es:"¿Puede hacer un descuento?",en:"Can you give me a discount?"},{es:"Solo estoy mirando.",en:"I'm just looking."},{es:"Me llevo este.",en:"I'll take this one."},{es:"¿Aceptan tarjeta?",en:"Do you accept card?"}]},
  {section:"🍽️ En el Restaurante",cls:"color:var(--green);background:rgba(52,211,153,0.1);border:1px solid rgba(52,211,153,0.2)",items:[{es:"Una mesa para dos, por favor.",en:"A table for two, please."},{es:"¿Qué recomienda?",en:"What do you recommend?"},{es:"Quisiera pedir...",en:"I would like to order..."},{es:"La cuenta, por favor.",en:"The bill, please."},{es:"Está delicioso.",en:"It's delicious."},{es:"¿Tiene menú del día?",en:"Do you have a daily menu?"},{es:"Sin picante, por favor.",en:"Without spice, please."},{es:"¿Me regala un tinto?",en:"Can I have a black coffee? (Colombian!)"}]},
  {section:"🆘 Pidiendo Ayuda",cls:"color:var(--purple);background:rgba(167,139,250,0.1);border:1px solid rgba(167,139,250,0.2)",items:[{es:"No entiendo.",en:"I don't understand."},{es:"¿Puede repetir más despacio?",en:"Can you repeat more slowly?"},{es:"¿Habla inglés?",en:"Do you speak English?"},{es:"No hablo bien español.",en:"I don't speak Spanish well."},{es:"¿Cómo se dice... en español?",en:"How do you say... in Spanish?"},{es:"¿Me puede ayudar?",en:"Can you help me?"},{es:"Estoy perdido/a.",en:"I'm lost."},{es:"¿Dónde está...?",en:"Where is...?"},{es:"No sé.",en:"I don't know."}]},
  {section:"🚨 Emergencias",cls:"color:var(--pink);background:rgba(232,93,117,0.12);border:1px solid rgba(232,93,117,0.3)",items:[{es:"¡Ayuda!",en:"Help!"},{es:"Llame a la policía.",en:"Call the police."},{es:"Necesito un médico.",en:"I need a doctor."},{es:"Llame a una ambulancia.",en:"Call an ambulance."},{es:"Me robaron.",en:"I was robbed."},{es:"¿Dónde está el hospital?",en:"Where is the hospital?"},{es:"Me siento mal.",en:"I feel sick."}]},
  {section:"🚕 Transporte",cls:"color:var(--blue);background:rgba(96,165,250,0.1);border:1px solid rgba(96,165,250,0.2)",items:[{es:"¿Dónde está la parada de bus?",en:"Where is the bus stop?"},{es:"¿Cuánto cuesta el taxi hasta...?",en:"How much is a taxi to...?"},{es:"Lléveme a esta dirección.",en:"Take me to this address."},{es:"Para aquí, por favor.",en:"Stop here, please."},{es:"¿Cuánto tarda hasta...?",en:"How long does it take to...?"},{es:"¿Tiene cambio?",en:"Do you have change?"}]},
  {section:"☀️ Conversación Diaria",cls:"color:var(--teal);background:rgba(74,168,160,0.08);border:1px solid rgba(74,168,160,0.18)",items:[{es:"¿Cuántos años tiene usted?",en:"How old are you? (formal)"},{es:"Tengo ___ años.",en:"I am ___ years old."},{es:"¿De dónde es usted?",en:"Where are you from?"},{es:"Soy de...",en:"I'm from..."},{es:"¿Qué hora es?",en:"What time is it?"},{es:"Son las tres.",en:"It's three o'clock."},{es:"Por favor.",en:"Please."},{es:"Gracias.",en:"Thank you."},{es:"De nada.",en:"You're welcome."},{es:"Con permiso.",en:"Excuse me (passing)."},{es:"¿Puede escribirlo?",en:"Can you write it down?"},{es:"Entiendo un poco.",en:"I understand a little."}]},
  {section:"❤️ Gustos y conversación",cls:"color:var(--pink);background:rgba(232,93,117,0.1);border:1px solid rgba(232,93,117,0.2)",items:[{es:"Soy...",en:"I am..."},{es:"Trabajo como...",en:"I work as..."},{es:"Trabajo en...",en:"I work at / in..."},{es:"Estudio...",en:"I study..."},{es:"Me gusta mi trabajo.",en:"I like my job."},{es:"No me gusta mi trabajo.",en:"I don't like my job."},{es:"¿Qué haces?",en:"What do you do?"},{es:"¿En qué trabajas?",en:"What do you do for work?"},{es:"¿Cómo te llamas?",en:"What's your name?"},{es:"Me llamo...",en:"My name is..."},{es:"¿De dónde eres?",en:"Where are you from?"},{es:"¿Dónde vives?",en:"Where do you live?"},{es:"Vivo en...",en:"I live in..."},{es:"Mi ciudad es grande / pequeña.",en:"My city is big / small."},{es:"Me gusta vivir aquí.",en:"I like living here."},{es:"No me gusta vivir aquí.",en:"I don't like living here."},{es:"Tengo ... años.",en:"I am ... years old."},{es:"Mi cumpleaños es...",en:"My birthday is..."},{es:"¿Cuántos años tienes?",en:"How old are you?"},{es:"¿Tienes hermanos?",en:"Do you have siblings?"},{es:"¿Tienes mascotas?",en:"Do you have pets?"},{es:"Mi familia es pequeña / grande.",en:"My family is small / big."},{es:"Los quiero mucho.",en:"I love them very much."},{es:"Me gusta...",en:"I like..."},{es:"No me gusta...",en:"I don't like..."},{es:"Me encanta...",en:"I love..."},{es:"Odio...",en:"I hate..."},{es:"Prefiero...",en:"I prefer..."},{es:"Mi favorito/a es...",en:"My favorite is..."},{es:"Es divertido.",en:"It's fun."},{es:"Es interesante.",en:"It's interesting."},{es:"Es aburrido.",en:"It's boring."},{es:"Es fácil.",en:"It's easy."},{es:"Es difícil.",en:"It's difficult."},{es:"Es delicioso.",en:"It's delicious."},{es:"Es horrible.",en:"It's horrible."}]},
  {section:"🧱 Frases para contar historias",cls:"color:var(--gold);background:rgba(232,180,74,0.1);border:1px solid rgba(232,180,74,0.2)",items:[{es:"Fui a...",en:"I went to..."},{es:"Fui al...",en:"I went to the..."},{es:"Estuve en...",en:"I was / stayed in..."},{es:"Estaba en...",en:"I was in / at... (ongoing)"},{es:"Era...",en:"I was... (identity / description)"},{es:"Iba a...",en:"I was going to..."},{es:"Tenía que...",en:"I had to..."},{es:"Tuve que...",en:"I had to... (specific event)"},{es:"Quería...",en:"I wanted..."},{es:"Necesitaba...",en:"I needed..."},{es:"Podía...",en:"I could / was able to..."},{es:"No podía...",en:"I couldn't..."},{es:"Después...",en:"Afterward..."},{es:"Luego...",en:"Then / afterward..."},{es:"Pero...",en:"But..."},{es:"Porque...",en:"Because..."},{es:"Entonces...",en:"So / then..."}]},
  {section:"🧩 Conectores para sonar natural",cls:"color:var(--teal);background:rgba(74,168,160,0.08);border:1px solid rgba(74,168,160,0.18)",items:[{es:"También...",en:"Also..."},{es:"Ya...",en:"Already / now..."},{es:"Todavía...",en:"Still / yet..."},{es:"La verdad...",en:"The truth is..."},{es:"Pues...",en:"Well / so..."},{es:"O sea...",en:"I mean..."},{es:"De pronto...",en:"Maybe... (Colombian)"},{es:"Por eso...",en:"That's why..."},{es:"Al final...",en:"In the end..."},{es:"En cambio...",en:"On the other hand..."}]},
  {section:"🧱 Patrones para hablar cada día",cls:"color:var(--purple);background:rgba(167,139,250,0.1);border:1px solid rgba(167,139,250,0.2)",items:[{es:"Tengo que...",en:"I have to..."},{es:"Voy a...",en:"I am going to..."},{es:"Estoy en...",en:"I am in / at..."},{es:"Acabo de...",en:"I just..."},{es:"Me toca...",en:"I have to... / It's my turn..."},{es:"Se me olvidó...",en:"I forgot..."},{es:"Lo necesito.",en:"I need it. (masculine)"},{es:"La necesito.",en:"I need it. (feminine)"},{es:"Lo tengo.",en:"I have it. (masculine)"},{es:"La tengo.",en:"I have it. (feminine)"},{es:"Le dije...",en:"I told him / her..."},{es:"Se lo mando.",en:"I will send it to him / her."},{es:"No lo sé.",en:"I don't know it / that."},{es:"Ya lo hice.",en:"I already did it."},{es:"Todavía no.",en:"Not yet."},{es:"A ver...",en:"Let's see..."},{es:"Es que...",en:"It's just that..."}]},
  {section:"⚠️ Groserías colombianas — entender primero",cls:"color:var(--pink);background:rgba(232,93,117,0.12);border:1px solid rgba(232,93,117,0.3)",items:[{es:"¡Juepucha, se me hizo tarde!",en:"Darn, I'm late! (milder euphemism)",register:"Mild · informal"},{es:"¡No joda!",en:"No way! / Come on! (informal)",register:"Strong · informal"},{es:"¡Qué gonorrea de tráfico!",en:"What horrible traffic! (very strong)",register:"Very strong · understand first"},{es:"Ese man es un pirobo.",en:"That guy is a jerk. (strong)",register:"Strong insult"},{es:"No sea güevón.",en:"Don't be an idiot. (vulgar)",register:"Vulgar · strong"},{es:"¡Puta, se dañó el carro!",en:"Fuck, the car broke down. (very strong)",register:"Very strong · understand first"},{es:"Me importa un culo.",en:"I don't give a fuck. (very vulgar)",register:"Very vulgar · understand first"},{es:"¡Qué chimba!",en:"That's awesome! (vulgar/informal)",register:"Vulgar · close friends"},{es:"¡Ay, marica, qué susto!",en:"Dude, what a scare! (context-sensitive)",register:"Context-sensitive"},{es:"¡Qué jartera!",en:"What a drag! (milder)",register:"Mild · informal"},{es:"¡Hijueputa, qué susto!",en:"Holy shit, what a scare! (very strong)",register:"Very strong · understand first"}]},
  /* ── NEW v13: Haciendo Planes ── */
  {section:"📆 Haciendo Planes",cls:"color:var(--blue);background:rgba(96,165,250,0.1);border:1px solid rgba(96,165,250,0.2)",items:[{es:"¿Qué vas a hacer mañana?",en:"What are you going to do tomorrow?"},{es:"¿Nos vemos mañana?",en:"Shall we meet tomorrow?"},{es:"¿A qué hora nos vemos?",en:"What time shall we meet?"},{es:"¿Quieres salir?",en:"Do you want to go out?"},{es:"¡Claro que sí!",en:"Of course!"},{es:"No puedo, tengo planes.",en:"I can't, I have plans."},{es:"¿Qué tal el sábado?",en:"How about Saturday?"},{es:"De pronto voy.",en:"Maybe I'll go. (Colombian: de pronto = maybe)"},{es:"Nos vemos a las siete.",en:"See you at seven."},{es:"¡De una!",en:"I'm in! / Right away! (Colombian!)"},{es:"Te aviso.",en:"I'll let you know."},{es:"¿Dónde nos encontramos?",en:"Where shall we meet?"}]},
  /* ── NEW v13: Por Teléfono / Mensajes ── */
  {section:"📱 Por Teléfono / Mensajes",cls:"color:var(--teal);background:rgba(74,168,160,0.1);border:1px solid rgba(74,168,160,0.2)",items:[{es:"¿Aló?",en:"Hello? (answering the phone — Colombian!)"},{es:"¿Con quién hablo?",en:"Who am I speaking with?"},{es:"¿Me escuchas?",en:"Can you hear me?"},{es:"Te llamo más tarde.",en:"I'll call you later."},{es:"Se cortó la llamada.",en:"The call dropped."},{es:"Te escribo.",en:"I'll text you."},{es:"Mándame la ubicación.",en:"Send me the location."},{es:"¿Me pasas tu número?",en:"Can you give me your number?"},{es:"Estoy sin señal.",en:"I have no signal."},{es:"No tengo minutos.",en:"I don't have phone minutes. (very Colombian)"},{es:"Voy a llamar.",en:"I'm going to call."},{es:"Deja el mensaje.",en:"Leave the message."}]},
  /* ── NEW v13: ¿Cómo Te Sientes? ── */
  {section:"🩺 ¿Cómo Te Sientes?",cls:"color:var(--green);background:rgba(52,211,153,0.1);border:1px solid rgba(52,211,153,0.2)",items:[{es:"¿Cómo te sientes?",en:"How do you feel?"},{es:"Me siento bien.",en:"I feel good."},{es:"Me siento mal.",en:"I feel bad."},{es:"Tengo hambre.",en:"I'm hungry."},{es:"Tengo sed.",en:"I'm thirsty."},{es:"Tengo sueño.",en:"I'm sleepy."},{es:"Tengo frío.",en:"I'm cold."},{es:"Tengo calor.",en:"I'm hot."},{es:"Me duele la cabeza.",en:"My head hurts."},{es:"Me duele el estómago.",en:"My stomach hurts."},{es:"Estoy cansado/a.",en:"I'm tired."},{es:"Estoy enfermo/a.",en:"I'm sick."},{es:"Necesito descansar.",en:"I need to rest."},{es:"¡Que te mejores!",en:"Get well soon!"}]},
  /* ── NEW v13: Plata y Pagos ── */
  {section:"💰 Plata y Pagos",cls:"color:var(--gold);background:rgba(232,180,74,0.1);border:1px solid rgba(232,180,74,0.2)",items:[{es:"¿Cuánto le debo?",en:"How much do I owe you?"},{es:"¿Tiene cambio de cincuenta mil?",en:"Do you have change for fifty thousand?"},{es:"¿Puedo pagar con tarjeta?",en:"Can I pay by card?"},{es:"Pago en efectivo.",en:"I'll pay in cash."},{es:"¿Me hace la transferencia?",en:"Can you send me the transfer? (Nequi-style)"},{es:"Quedamos a mano.",en:"We're even."},{es:"¿Me rebaja algo?",en:"Can you lower the price a bit?"},{es:"Necesito sacar plata.",en:"I need to withdraw money. (Colombian!)"},{es:"¿Dónde hay un cajero?",en:"Where is there an ATM?"},{es:"A la orden.",en:"At your service / You're welcome. (Colombian!)"}]},
  {section:"👤 Pronombres en acción",cls:"color:var(--purple);background:rgba(167,139,250,0.1);border:1px solid rgba(167,139,250,0.2)",items:[{es:"¿Me lo puede repetir, por favor?",en:"Can you repeat it for me, please?"},{es:"Sí, se lo repito despacio.",en:"Yes, I'll repeat it slowly."},{es:"¿La dirección la tiene?",en:"Do you have the address?"},{es:"Sí, la tengo aquí.",en:"Yes, I have it here."},{es:"¿Le puedo ayudar?",en:"Can I help you?"},{es:"Sí, necesito ayuda.",en:"Yes, I need help."},{es:"¿Me la puede mandar?",en:"Can you send it to me?"},{es:"Se la mando en un momento.",en:"I'll send it to you in a moment."}]},
];
/* v36: high-value language for keeping a real conversation moving.  The
   quizCat field lets the quiz keep these practical topics separate while the
   existing Frases menu still treats them like normal phrase collections. */
FRASES.push(
  {section:"🧰 Comunicación para aclarar",quizCat:"reparar",cls:"color:var(--teal);background:rgba(74,168,160,0.1);border:1px solid rgba(74,168,160,0.2)",items:[
    {es:"No entendí.",en:"I didn't understand."},{es:"¿Puede repetir?",en:"Can you repeat?"},{es:"Más despacio, por favor.",en:"More slowly, please."},{es:"¿Qué quiere decir?",en:"What does that mean?"},{es:"¿Cómo se dice ___?",en:"How do you say ___?"},{es:"¿Me puede mostrar?",en:"Can you show me?"},{es:"Un momento.",en:"One moment."},{es:"Déjeme pensar.",en:"Let me think."},{es:"Hablo poquito español.",en:"I speak a little Spanish."},{es:"No estoy seguro/a.",en:"I'm not sure."},{es:"¿Así está bien?",en:"Is it okay like this?"},{es:"¿Me entiende?",en:"Do you understand me?"},{es:"Perdón, estoy aprendiendo español.",en:"Sorry, I'm learning Spanish."}
  ]},
  {section:"🧱 Marcos para construir frases",quizCat:"frases",cls:"color:var(--purple);background:rgba(167,139,250,0.1);border:1px solid rgba(167,139,250,0.2)",items:[
    {es:"Quiero...",en:"I want..."},{es:"Necesito...",en:"I need..."},{es:"Puedo...",en:"I can..."},{es:"No puedo...",en:"I can't..."},{es:"Me gustaría...",en:"I would like..."},{es:"Hay que...",en:"We have to / One must..."},{es:"No sé cómo...",en:"I don't know how to..."},{es:"Estoy tratando de...",en:"I'm trying to..."},{es:"Depende.",en:"It depends."},{es:"No importa.",en:"It doesn't matter."},{es:"No pasa nada.",en:"It's okay / No problem."},{es:"Me hace falta...",en:"I am missing / I need..."}
  ]},
  {section:"🔗 Conectores y palabras de unión",quizCat:"conectores",cls:"color:var(--teal);background:rgba(74,168,160,0.08);border:1px solid rgba(74,168,160,0.18)",items:[
    {es:"Si...",en:"If..."},{es:"Sí.",en:"Yes."},{es:"Pero...",en:"But..."},{es:"Porque...",en:"Because..."},{es:"¿Por qué?",en:"Why?"},{es:"Entonces...",en:"So / then..."},{es:"Así que...",en:"So / therefore..."},{es:"Aunque...",en:"Although..."},{es:"Todavía no.",en:"Not yet."},{es:"Primero...",en:"First..."},{es:"Cuando...",en:"When..."},{es:"Mientras...",en:"While..."},{es:"Tampoco.",en:"Neither / not either."},{es:"Como...",en:"Since / as..."},{es:"¿Cómo?",en:"How?"},{es:"Que...",en:"That / which..."},{es:"¿Qué?",en:"What?"},{es:"Luego...",en:"Then / afterward..."},{es:"También.",en:"Also."},{es:"Al final.",en:"In the end."}
  ]},
  {section:"🧭 Direcciones y ubicación",quizCat:"direcciones",cls:"color:var(--blue);background:rgba(96,165,250,0.1);border:1px solid rgba(96,165,250,0.2)",items:[
    {es:"Siga derecho hasta el fondo.",en:"Go straight to the back / end."},{es:"Sigue derecho hasta la esquina.",en:"Go straight to the corner."},{es:"Gire a la derecha.",en:"Turn right."},{es:"Gire a la izquierda.",en:"Turn left."},{es:"Está al frente.",en:"It is in front / across from you."},{es:"Está al lado de...",en:"It is next to..."},{es:"Queda detrás de...",en:"It is behind..."},{es:"Está en la esquina.",en:"It is on the corner."},{es:"La entrada está por allá.",en:"The entrance is over there."},{es:"Es el edificio de allá.",en:"It's that building over there."},{es:"El edificio está al frente.",en:"The building is across the way."},{es:"Más adelante.",en:"Farther ahead."},{es:"Devuélvase un poquito.",en:"Go back a little."},{es:"Suba al segundo piso.",en:"Go up to the second floor."},{es:"Baje las escaleras.",en:"Go down the stairs."},{es:"¿Me puede indicar?",en:"Can you point it out / give me directions?"}
  ]},
  {section:"🚕 Uber y transporte real",quizCat:"uber",cls:"color:var(--blue);background:rgba(96,165,250,0.1);border:1px solid rgba(96,165,250,0.2)",items:[
    {es:"Buenas, ¿usted es mi conductor?",en:"Hi, are you my driver?"},{es:"Sí, soy yo.",en:"Yes, that's me."},{es:"Voy para este hotel.",en:"I'm going to this hotel."},{es:"No conozco mucho la ciudad.",en:"I don't know the city very well."},{es:"¿Esta dirección está bien?",en:"Is this address correct?"},{es:"¿Me puede dejar aquí?",en:"Can you drop me off here?"},{es:"¿Cuánto falta?",en:"How much longer?"},{es:"¿Hay mucho trancón?",en:"Is there a lot of traffic?"},{es:"Ya llegamos.",en:"We've arrived."},{es:"Muchas gracias, muy amable.",en:"Thank you very much, that's very kind."}
  ]},
  {section:"🇨🇴 Expresiones sociales colombianas",quizCat:"expresiones",cls:"color:var(--pink);background:rgba(232,93,117,0.1);border:1px solid rgba(232,93,117,0.2)",items:[
    {es:"¿Cómo te ha ido?",en:"How have things been?",register:"Everyday"},{es:"Todo bien.",en:"All good.",register:"Everyday"},{es:"Hágale.",en:"Go ahead / Let's do it.",register:"Colombian · informal"},{es:"Con mucho gusto.",en:"With pleasure / You're welcome.",register:"Everyday"},{es:"No se preocupe.",en:"Don't worry.",register:"Polite"},{es:"Tranquilo/a.",en:"Take it easy / Don't worry.",register:"Everyday"},{es:"¡Qué pena!",en:"Sorry! / What a shame!",register:"Colombian · everyday"},{es:"¡Qué nota!",en:"How cool!",register:"Colombian · informal"},{es:"¡Bacano!",en:"Awesome / cool!",register:"Colombian · informal"},{es:"¡Chévere!",en:"Cool / great!",register:"Everyday"},{es:"Parce.",en:"Buddy / friend.",register:"Colombian · informal"},{es:"Fresco/a.",en:"Relax / no worries.",register:"Colombian · informal"},{es:"De una vez.",en:"Right away / while we're at it.",register:"Everyday"}
  ]}
);
/* v37: more Colombian informal language.  These are deliberately labeled so
   a learner can recognize them without treating every word as safe to say. */
COLOMBIANISMOS.push(
  {word:"Joder",en:"To bother / mess with; damn",usage:"Informal and vulgar. In ¡Deje de joder! it means 'stop bothering me.' Stronger than a neutral complaint; understand the tone first.",example:"¡Deje de joder, estoy trabajando!",tts:"¡Deje de joder, estoy trabajando!",register:"Strong · understand first"},
  {word:"Mierda",en:"Shit",usage:"Common vulgar exclamation or noun. Recognize it, but avoid it in polite or professional situations.",example:"¡Mierda, olvidé las llaves!",tts:"¡Mierda, olvidé las llaves!",register:"Strong · understand first"},
  {word:"Carajo",en:"Damn it / hell",usage:"A strong exclamation. It is milder than the strongest personal insults, but still informal and rude.",example:"¡Carajo, se nos hizo tarde!",tts:"¡Carajo, se nos hizo tarde!",register:"Strong · informal"},
  {word:"Lambón / lambona",en:"Suck-up / brown-noser",usage:"A Colombian insult for someone who flatters people to get an advantage. Informal and insulting.",example:"Ese man es muy lambón con el jefe.",tts:"Ese man es muy lambón con el jefe.",register:"Insult · informal"},
  {word:"Sapo / sapa",en:"Snitch / busybody",usage:"In Colombia, calling someone sapo can mean they meddle or tell on others. Insulting; do not use casually.",example:"No seas sapo, eso es privado.",tts:"No seas sapo, eso es privado.",register:"Insult · informal"},
  {word:"Mamado/a",en:"Fed up / sick and tired",usage:"Very common Colombian informal expression. It describes being fed up, not literal tiredness only. Context matters.",example:"Estoy mamado de esperar.",tts:"Estoy mamado de esperar.",register:"Colombian · informal"},
  {word:"Emberracado/a",en:"Pissed off / furious",usage:"Colombian informal adjective for being very angry. Strong conversational language; understand first.",example:"Estoy emberracado con ese problema.",tts:"Estoy emberracado con ese problema.",register:"Colombian · strong"},
  {word:"Cansón / cansona",en:"Annoying / tiresome",usage:"A milder everyday way to say someone or something is annoying. Still direct, so use with care.",example:"No seas tan cansón.",tts:"No seas tan cansón.",register:"Informal"}
);
FRASES.push(
  {section:"⚠️ Groserías colombianas — más para entender",quizCat:"groserias",cls:"color:var(--pink);background:rgba(232,93,117,0.12);border:1px solid rgba(232,93,117,0.3)",items:[
    {es:"¡Deje de joder!",en:"Stop bothering me! / Stop messing around!",register:"Strong · understand first"},
    {es:"¡No me joda!",en:"Don't mess with me! / No way!",register:"Strong · informal"},
    {es:"¿Qué carajos?",en:"What the hell?",register:"Strong · understand first"},
    {es:"¿Qué putas?",en:"What the hell? / What the fuck?",register:"Very strong · understand first"},
    {es:"¡Mierda, olvidé las llaves!",en:"Shit, I forgot the keys!",register:"Strong · understand first"},
    {es:"¡Carajo, se nos hizo tarde!",en:"Damn it, we're late!",register:"Strong · informal"},
    {es:"Ese man es un lambón.",en:"That guy is a suck-up.",register:"Insult · informal"},
    {es:"No seas sapo.",en:"Don't be a snitch / busybody.",register:"Insult · informal"},
    {es:"Estoy mamado de esperar.",en:"I'm fed up with waiting.",register:"Colombian · informal"},
    {es:"Estoy emberracado con ese problema.",en:"I'm pissed off about that problem.",register:"Colombian · strong"},
    {es:"No seas tan cansón.",en:"Don't be so annoying.",register:"Informal · milder"},
    {es:"¡Qué mierda de día!",en:"What a shitty day!",register:"Strong · understand first"},
    {es:"¡Qué hijueputa susto!",en:"What a fucking scare!",register:"Very strong · understand first"},
    {es:"¡No sea tan güevón!",en:"Don't be such an idiot!",register:"Vulgar · strong"},
    {es:"¡Qué putas está pasando!",en:"What the hell is going on!",register:"Very strong · understand first"}
  ]}
);
/* v38: high-frequency conversation glue. These are the small words and
   sentence frames that help a learner connect ideas instead of speaking in
   isolated textbook fragments. */
FRASES.push({section:"🗣️ Palabras para conversar — everyday glue",quizCat:"conectores",cls:"color:var(--teal);background:rgba(74,168,160,0.1);border:1px solid rgba(74,168,160,0.2)",items:[
  {es:"De hecho...",en:"In fact...",register:"Everyday"},
  {es:"En realidad...",en:"Actually...",register:"Everyday"},
  {es:"Lo que pasa es que...",en:"The thing is...",register:"Everyday"},
  {es:"El problema es que...",en:"The problem is that...",register:"Everyday"},
  {es:"Ya casi.",en:"Almost / Almost there.",register:"Everyday"},
  {es:"Por ahora.",en:"For now.",register:"Everyday"},
  {es:"Al rato.",en:"Later / In a little while.",register:"Everyday · Colombia"},
  {es:"En cuanto pueda...",en:"As soon as I can...",register:"Everyday"},
  {es:"Aunque sea...",en:"Even if / At least...",register:"Everyday"},
  {es:"Más bien...",en:"Rather / Instead...",register:"Everyday"},
  {es:"Si no...",en:"If not...",register:"Everyday"}
]});
/* v39: high-frequency action chunks. These are more useful for speaking than
   isolated nouns because they give the learner a ready-made sentence frame. */
FRASES.push({section:"⚡ Acciones para hablar cada día",quizCat:"acciones",cls:"color:var(--gold);background:rgba(232,180,74,0.1);border:1px solid rgba(232,180,74,0.2)",items:[
  {es:"Quiero...",en:"I want to...",register:"Everyday"},
  {es:"Necesito...",en:"I need to...",register:"Everyday"},
  {es:"Puedo...",en:"I can...",register:"Everyday"},
  {es:"No puedo...",en:"I can't...",register:"Everyday"},
  {es:"Tengo que...",en:"I have to...",register:"Everyday"},
  {es:"Me toca...",en:"I have to... / It's my turn...",register:"Everyday · Colombia"},
  {es:"Voy a...",en:"I'm going to...",register:"Everyday"},
  {es:"Acabo de...",en:"I just...",register:"Everyday"},
  {es:"Estoy tratando de...",en:"I'm trying to...",register:"Everyday"},
  {es:"Estoy buscando...",en:"I'm looking for...",register:"Everyday"},
  {es:"Estoy esperando...",en:"I'm waiting for...",register:"Everyday"},
  {es:"Ya llegué.",en:"I already arrived.",register:"Everyday"},
  {es:"Voy llegando.",en:"I'm on my way / almost there.",register:"Everyday · Colombia"},
  {es:"Se me olvidó...",en:"I forgot...",register:"Everyday"},
  {es:"Me hace falta...",en:"I need... / I'm missing...",register:"Everyday"},
  {es:"Me queda...",en:"I have left... / It is left for me...",register:"Everyday"},
  {es:"Voy para...",en:"I'm headed to...",register:"Everyday · Colombia"},
  {es:"Vengo de...",en:"I come from... / I'm coming from...",register:"Everyday"},
  {es:"Llevo...",en:"I bring / carry / have been...",register:"Everyday"},
  {es:"Traigo...",en:"I bring...",register:"Everyday"},
  {es:"Dejo...",en:"I leave / drop off...",register:"Everyday"},
  {es:"Paso por...",en:"I stop by / pass through...",register:"Everyday"},
  {es:"Me quedo...",en:"I stay...",register:"Everyday"},
  {es:"Resulta que...",en:"It turns out that...",register:"Everyday"},
  {es:"Depende de...",en:"It depends on...",register:"Everyday"}
]});
const DIALOGUE=[{who:"A",es:"Hola, ¿cómo está?",en:"Hi, how are you? (formal)",tts:"Hola, ¿cómo está?"},{who:"B",es:"Hola, estoy bien, gracias.",en:"Hi, I'm fine, thank you.",tts:"Hola, estoy bien, gracias."},{who:"A",es:"Soy David. ¡Gusto en conocerle!",en:"I'm David. Nice to meet you!",tts:"Soy David. ¡Gusto en conocerle!"},{who:"B",es:"Soy Roberto. ¡El gusto es mío!",en:"I'm Roberto. The pleasure is mine!",tts:"Soy Roberto. ¡El gusto es mío!"},{who:"A",es:"Mucho gusto, señor Roberto.",en:"Nice to meet you, Mr. Roberto.",tts:"Mucho gusto, señor Roberto."},{who:"B",es:"Igualmente, señor David.",en:"Likewise, Mr. David.",tts:"Igualmente, señor David."}];
const CONVERSATIONS=[
  {title:"Presentación personal",tense:"Ahora",lines:[{who:"A",es:"Hola, ¿cómo te llamas?",en:"Hi, what's your name?",tts:"Hola, ¿cómo te llamas?"},{who:"B",es:"Me llamo Laura. Mucho gusto.",en:"My name is Laura. Nice to meet you.",tts:"Me llamo Laura. Mucho gusto."}]},
  {title:"Presentación personal",tense:"Planes",lines:[{who:"A",es:"Mañana voy a presentarme a mis nuevos vecinos.",en:"Tomorrow I'm going to introduce myself to my new neighbors.",tts:"Mañana voy a presentarme a mis nuevos vecinos."},{who:"B",es:"¡Qué bien! Vas a hablar con mucha confianza.",en:"Great! You are going to speak confidently.",tts:"¡Qué bien! Vas a hablar con mucha confianza."}]},
  {title:"Presentación personal",tense:"Ayer",lines:[{who:"A",es:"Ayer conocí a una persona nueva.",en:"Yesterday I met a new person.",tts:"Ayer conocí a una persona nueva."},{who:"B",es:"Le dije mi nombre y nos saludamos.",en:"I told them my name and we greeted each other.",tts:"Le dije mi nombre y nos saludamos."}]},
  {title:"Profesión",tense:"Ahora",lines:[{who:"A",es:"¿En qué trabajas?",en:"What do you do for work?",tts:"¿En qué trabajas?"},{who:"B",es:"Trabajo como ingeniero.",en:"I work as an engineer.",tts:"Trabajo como ingeniero."}]},
  {title:"Profesión",tense:"Planes",lines:[{who:"A",es:"¿Qué vas a estudiar?",en:"What are you going to study?",tts:"¿Qué vas a estudiar?"},{who:"B",es:"Voy a estudiar para ser médico.",en:"I'm going to study to become a doctor.",tts:"Voy a estudiar para ser médico."}]},
  {title:"Profesión",tense:"Ayer",lines:[{who:"A",es:"¿Qué hiciste ayer?",en:"What did you do yesterday?",tts:"¿Qué hiciste ayer?"},{who:"B",es:"Ayer trabajé en la oficina.",en:"Yesterday I worked at the office.",tts:"Ayer trabajé en la oficina."}]},
  {title:"¿Dónde vives?",tense:"Ahora",lines:[{who:"A",es:"¿Dónde vives?",en:"Where do you live?",tts:"¿Dónde vives?"},{who:"B",es:"Vivo en Medellín, cerca del parque.",en:"I live in Medellín, near the park.",tts:"Vivo en Medellín, cerca del parque."}]},
  {title:"¿Dónde vives?",tense:"Planes",lines:[{who:"A",es:"¿Dónde vas a vivir?",en:"Where are you going to live?",tts:"¿Dónde vas a vivir?"},{who:"B",es:"Voy a vivir en Bogotá el próximo año.",en:"I'm going to live in Bogotá next year.",tts:"Voy a vivir en Bogotá el próximo año."}]},
  {title:"¿Dónde vives?",tense:"Ayer",lines:[{who:"A",es:"¿Dónde viviste antes?",en:"Where did you live before?",tts:"¿Dónde viviste antes?"},{who:"B",es:"Viví en Cali con mi familia.",en:"I lived in Cali with my family.",tts:"Viví en Cali con mi familia."}]},
  {title:"Gustos y familia",tense:"Ahora",lines:[{who:"A",es:"¿Tienes hermanos?",en:"Do you have siblings?",tts:"¿Tienes hermanos?"},{who:"B",es:"Sí, tengo una hermana y un hermano.",en:"Yes, I have a sister and a brother.",tts:"Sí, tengo una hermana y un hermano."}]},
  {title:"Gustos y familia",tense:"Planes",lines:[{who:"A",es:"¿Qué vas a hacer con tu familia?",en:"What are you going to do with your family?",tts:"¿Qué vas a hacer con tu familia?"},{who:"B",es:"Voy a pasar tiempo con ellos.",en:"I'm going to spend time with them.",tts:"Voy a pasar tiempo con ellos."}]},
  {title:"Gustos y familia",tense:"Ayer",lines:[{who:"A",es:"¿Qué hiciste con tu familia?",en:"What did you do with your family?",tts:"¿Qué hiciste con tu familia?"},{who:"B",es:"Ayer cené con mis padres.",en:"Yesterday I had dinner with my parents.",tts:"Ayer cené con mis padres."}]},
  {title:"Pedir direcciones",tense:"Ahora",lines:[{who:"A",es:"Disculpe, ¿me regala la dirección?",en:"Excuse me, could you give me the address?",tts:"Disculpe, ¿me regala la dirección?"},{who:"B",es:"Siga derecho y gire a la izquierda.",en:"Go straight and turn left.",tts:"Siga derecho y gire a la izquierda."}]},
  {title:"Pedir direcciones",tense:"Planes",lines:[{who:"A",es:"¿Cómo voy a llegar al parqueadero?",en:"How am I going to get to the parking lot?",tts:"¿Cómo voy a llegar al parqueadero?"},{who:"B",es:"Va a girar en la próxima esquina.",en:"You are going to turn at the next corner.",tts:"Va a girar en la próxima esquina."}]},
  {title:"Pedir direcciones",tense:"Ayer",lines:[{who:"A",es:"¿Cómo llegaste al hospital?",en:"How did you get to the hospital?",tts:"¿Cómo llegaste al hospital?"},{who:"B",es:"Seguí derecho y pregunté en la esquina.",en:"I went straight and asked at the corner.",tts:"Seguí derecho y pregunté en la esquina."}]},
  {title:"Carro y taxi",tense:"Ahora",lines:[{who:"A",es:"¿Me lleva a esta dirección, por favor?",en:"Can you take me to this address, please?",tts:"¿Me lleva a esta dirección, por favor?"},{who:"B",es:"Claro, con mucho gusto.",en:"Of course, with pleasure.",tts:"Claro, con mucho gusto."}]},
  {title:"Carro y taxi",tense:"Planes",lines:[{who:"A",es:"¿Vamos a pedir un carro?",en:"Are we going to request a car?",tts:"¿Vamos a pedir un carro?"},{who:"B",es:"Sí, voy a pedir un taxi.",en:"Yes, I'm going to request a taxi.",tts:"Sí, voy a pedir un taxi."}]},
  {title:"Carro y taxi",tense:"Ayer",lines:[{who:"A",es:"¿Tomaste taxi ayer?",en:"Did you take a taxi yesterday?",tts:"¿Tomaste taxi ayer?"},{who:"B",es:"Sí, el conductor fue muy amable.",en:"Yes, the driver was very kind.",tts:"Sí, el conductor fue muy amable."}]},
  {title:"Cocinar juntos",tense:"Ahora",lines:[{who:"A",es:"¿Cocinamos juntos?",en:"Shall we cook together?",tts:"¿Cocinamos juntos?"},{who:"B",es:"Dale, yo corto las verduras.",en:"Sure, I'll cut the vegetables.",tts:"Dale, yo corto las verduras."}]},
  {title:"Cocinar juntos",tense:"Planes",lines:[{who:"A",es:"¿Qué vamos a cocinar?",en:"What are we going to cook?",tts:"¿Qué vamos a cocinar?"},{who:"B",es:"Vamos a preparar una sopa.",en:"We are going to make a soup.",tts:"Vamos a preparar una sopa."}]},
  {title:"Cocinar juntos",tense:"Ayer",lines:[{who:"A",es:"¿Qué cocinaron ayer?",en:"What did you cook yesterday?",tts:"¿Qué cocinaron ayer?"},{who:"B",es:"Ayer hervimos la comida y probamos la salsa.",en:"Yesterday we boiled the food and tasted the sauce.",tts:"Ayer hervimos la comida y probamos la salsa."}]},
  {title:"Contar lo que pasó",tense:"Ahora",lines:[{who:"A",es:"¿Dónde estás?",en:"Where are you?",tts:"¿Dónde estás?"},{who:"B",es:"Estoy en casa y tengo que terminar un proyecto.",en:"I'm at home and I have to finish a project.",tts:"Estoy en casa y tengo que terminar un proyecto."}]},
  {title:"Contar lo que pasó",tense:"Planes",lines:[{who:"A",es:"¿Qué ibas a hacer?",en:"What were you going to do?",tts:"¿Qué ibas a hacer?"},{who:"B",es:"Iba a cocinar, pero tuve que trabajar.",en:"I was going to cook, but I had to work.",tts:"Iba a cocinar, pero tuve que trabajar."}]},
   {title:"Contar lo que pasó",tense:"Ayer",lines:[{who:"A",es:"¿Qué hiciste ayer?",en:"What did you do yesterday?",tts:"¿Qué hiciste ayer?"},{who:"B",es:"Fui al mercado porque necesitaba comida.",en:"I went to the market because I needed food.",tts:"Fui al mercado porque necesitaba comida."},{who:"A",es:"¿Y dónde estabas después?",en:"And where were you afterward?",tts:"¿Y dónde estabas después?"},{who:"B",es:"Estaba en casa; quería descansar.",en:"I was at home; I wanted to rest.",tts:"Estaba en casa; quería descansar."}]},
   {title:"Groserías colombianas",tense:"Ahora",lines:[{who:"A",es:"¿Qué significa «juepucha»?",en:"What does «juepucha» mean?",tts:"¿Qué significa juepucha?"},{who:"B",es:"Es una forma más suave de decir «hijueputa». Úsala con cuidado.",en:"It is a milder way to say «hijueputa». Use it carefully.",tts:"Es una forma más suave de decir hijueputa. Úsala con cuidado."}]},
   {title:"Groserías colombianas",tense:"Planes",lines:[{who:"A",es:"¿Puedo decir «marica» con cualquier persona?",en:"Can I say «marica» with anyone?",tts:"¿Puedo decir marica con cualquier persona?"},{who:"B",es:"No. Depende mucho de la confianza, el tono y la región; mejor entiéndela primero.",en:"No. It depends a lot on trust, tone, and region; understand it first.",tts:"No. Depende mucho de la confianza, el tono y la región; mejor entiéndela primero."}]},
   {title:"Groserías colombianas",tense:"Ayer",lines:[{who:"A",es:"¿Qué escuchaste en la calle?",en:"What did you hear in the street?",tts:"¿Qué escuchaste en la calle?"},{who:"B",es:"Escuché «qué jartera», una queja informal y menos fuerte.",en:"I heard «qué jartera», an informal and milder complaint.",tts:"Escuché qué jartera, una queja informal y menos fuerte."}]},
   {title:"Ver televisión",tense:"Ahora",lines:[{who:"A",es:"¿Qué quieres ver?",en:"What do you want to watch?",tts:"¿Qué quieres ver?"},{who:"B",es:"Una serie. ¿Dónde está el control remoto?",en:"A series. Where is the remote control?",tts:"Una serie. ¿Dónde está el control remoto?"},{who:"A",es:"Está en el sofá.",en:"It's on the sofa.",tts:"Está en el sofá."}]},
  {title:"Ver televisión",tense:"Planes",lines:[{who:"A",es:"¿Qué vas a hacer esta noche?",en:"What are you going to do tonight?",tts:"¿Qué vas a hacer esta noche?"},{who:"B",es:"Voy a ver una película y relajarme.",en:"I'm going to watch a movie and relax.",tts:"Voy a ver una película y relajarme."}]},
  {title:"Ver televisión",tense:"Ayer",lines:[{who:"A",es:"¿Qué viste anoche?",en:"What did you watch last night?",tts:"¿Qué viste anoche?"},{who:"B",es:"Vi las noticias y descansé en el sofá.",en:"I watched the news and rested on the sofa.",tts:"Vi las noticias y descansé en el sofá."}]},
  {title:"En casa",tense:"Ahora",lines:[{who:"A",es:"¿Dónde está el baño?",en:"Where is the bathroom?",tts:"¿Dónde está el baño?"},{who:"B",es:"Está al lado de la habitación.",en:"It is next to the bedroom.",tts:"Está al lado de la habitación."}]},
  {title:"En casa",tense:"Planes",lines:[{who:"A",es:"¿Vas a arreglar la habitación?",en:"Are you going to tidy the bedroom?",tts:"¿Vas a arreglar la habitación?"},{who:"B",es:"Sí, voy a cambiar la sábana y la cobija.",en:"Yes, I'm going to change the sheet and the blanket.",tts:"Sí, voy a cambiar la sábana y la cobija."}]},
  {title:"En casa",tense:"Ayer",lines:[{who:"A",es:"¿Dónde estaba la toalla?",en:"Where was the towel?",tts:"¿Dónde estaba la toalla?"},{who:"B",es:"Ayer la dejé junto al lavamanos.",en:"Yesterday I left it next to the sink.",tts:"Ayer la dejé junto al lavamanos."}]}
  ,{title:"La habitación",tense:"Ahora",lines:[{who:"A",es:"¿Dónde está la sábana?",en:"Where is the sheet?",tts:"¿Dónde está la sábana?"},{who:"B",es:"Está en el clóset, al lado de la cobija.",en:"It is in the closet, next to the blanket.",tts:"Está en el clóset, al lado de la cobija."},{who:"A",es:"También necesito una almohada.",en:"I also need a pillow.",tts:"También necesito una almohada."},{who:"B",es:"Hay una sobre la cama.",en:"There is one on the bed.",tts:"Hay una sobre la cama."}]},
  {title:"La habitación",tense:"Planes",lines:[
    {who:"A",es:"Voy a organizar la habitación mañana.",en:"I'm going to organize the bedroom tomorrow.",tts:"Voy a organizar la habitación mañana."},
    {who:"B",es:"¿Vas a cambiar las sábanas?",en:"Are you going to change the sheets?",tts:"¿Vas a cambiar las sábanas?"},
    {who:"A",es:"Sí, y voy a comprar una almohada nueva.",en:"Yes, and I'm going to buy a new pillow.",tts:"Sí, y voy a comprar una almohada nueva."}]},
  {title:"La habitación",tense:"Ayer",lines:[
    {who:"A",es:"Ayer arreglé la habitación.",en:"Yesterday I tidied up the bedroom.",tts:"Ayer arreglé la habitación."},
    {who:"B",es:"¿Lavaste las cobijas?",en:"Did you wash the blankets?",tts:"¿Lavaste las cobijas?"},
    {who:"A",es:"Sí, y guardé la ropa en el clóset.",en:"Yes, and I put the clothes away in the closet.",tts:"Sí, y guardé la ropa en el clóset."}]},
  {title:"El baño",tense:"Ahora",lines:[{who:"A",es:"Disculpe, ¿dónde está el baño?",en:"Excuse me, where is the bathroom?",tts:"Disculpe, ¿dónde está el baño?"},{who:"B",es:"Está al fondo, a la derecha.",en:"It is at the back, on the right.",tts:"Está al fondo, a la derecha."},{who:"A",es:"¿Hay una toalla limpia?",en:"Is there a clean towel?",tts:"¿Hay una toalla limpia?"},{who:"B",es:"Sí, está junto al lavamanos.",en:"Yes, it is next to the sink.",tts:"Sí, está junto al lavamanos."}]},
  {title:"El baño",tense:"Planes",lines:[
    {who:"A",es:"Voy a tomar una ducha.",en:"I'm going to take a shower.",tts:"Voy a tomar una ducha."},
    {who:"B",es:"Listo, voy a buscar una toalla limpia.",en:"OK, I'm going to get a clean towel.",tts:"Listo, voy a buscar una toalla limpia."},
    {who:"A",es:"¿Vas a comprar champú mañana?",en:"Are you going to buy shampoo tomorrow?",tts:"¿Vas a comprar champú mañana?"},
    {who:"B",es:"Sí, y también jabón.",en:"Yes, and soap too.",tts:"Sí, y también jabón."}]},
  {title:"El baño",tense:"Ayer",lines:[
    {who:"A",es:"Ayer limpié el baño.",en:"Yesterday I cleaned the bathroom.",tts:"Ayer limpié el baño."},
    {who:"B",es:"¡Gracias! ¿Cambiaste la cortina de baño?",en:"Thanks! Did you change the shower curtain?",tts:"¡Gracias! ¿Cambiaste la cortina de baño?"},
    {who:"A",es:"Sí, y lavé el lavamanos.",en:"Yes, and I washed the sink.",tts:"Sí, y lavé el lavamanos."}]},
  {title:"Trabajo y oficina",tense:"Ahora",lines:[{who:"A",es:"¿Tienes una reunión hoy?",en:"Do you have a meeting today?",tts:"¿Tienes una reunión hoy?"},{who:"B",es:"Sí, con un cliente nuevo.",en:"Yes, with a new client.",tts:"Sí, con un cliente nuevo."},{who:"A",es:"¿Vas a enviar el correo?",en:"Are you going to send the email?",tts:"¿Vas a enviar el correo?"},{who:"B",es:"Sí, después de imprimir el documento.",en:"Yes, after printing the document.",tts:"Sí, después de imprimir el documento."}]},
  {title:"Trabajo y oficina",tense:"Planes",lines:[
    {who:"A",es:"Mañana voy a firmar el contrato.",en:"Tomorrow I'm going to sign the contract.",tts:"Mañana voy a firmar el contrato."},
    {who:"B",es:"¡Qué bueno! ¿Vas a hablar con el jefe?",en:"Great! Are you going to talk to the boss?",tts:"¡Qué bueno! ¿Vas a hablar con el jefe?"},
    {who:"A",es:"Sí, vamos a revisar el proyecto en la sala de juntas.",en:"Yes, we're going to review the project in the meeting room.",tts:"Sí, vamos a revisar el proyecto en la sala de juntas."}]},
  {title:"Trabajo y oficina",tense:"Ayer",lines:[
    {who:"A",es:"¿Cómo te fue en la reunión ayer?",en:"How did the meeting go yesterday?",tts:"¿Cómo te fue en la reunión ayer?"},
    {who:"B",es:"Muy bien. El cliente firmó el contrato.",en:"Very well. The client signed the contract.",tts:"Muy bien. El cliente firmó el contrato."},
    {who:"A",es:"¡Felicitaciones! Fue una buena venta.",en:"Congratulations! It was a good sale.",tts:"¡Felicitaciones! Fue una buena venta."}]},
  {title:"Partes del carro",tense:"Ahora",lines:[{who:"A",es:"¿Qué le pasa al carro?",en:"What is wrong with the car?",tts:"¿Qué le pasa al carro?"},{who:"B",es:"La llanta está baja y el freno suena.",en:"The tire is low and the brake makes a noise.",tts:"La llanta está baja y el freno suena."},{who:"A",es:"¿Hay gasolina?",en:"Is there gas?",tts:"¿Hay gasolina?"},{who:"B",es:"Sí, pero hay que revisar la batería.",en:"Yes, but we need to check the battery.",tts:"Sí, pero hay que revisar la batería."}]},
  {title:"Partes del carro",tense:"Planes",lines:[
    {who:"A",es:"Mañana voy a llevar el carro al taller.",en:"Tomorrow I'm going to take the car to the shop.",tts:"Mañana voy a llevar el carro al taller."},
    {who:"B",es:"¿Qué le van a cambiar?",en:"What are they going to change on it?",tts:"¿Qué le van a cambiar?"},
    {who:"A",es:"Van a cambiar la llanta y revisar los frenos.",en:"They're going to change the tire and check the brakes.",tts:"Van a cambiar la llanta y revisar los frenos."}]},
  {title:"Partes del carro",tense:"Ayer",lines:[
    {who:"A",es:"Ayer llevé el carro al taller.",en:"Yesterday I took the car to the shop.",tts:"Ayer llevé el carro al taller."},
    {who:"B",es:"¿Qué le hicieron?",en:"What did they do to it?",tts:"¿Qué le hicieron?"},
    {who:"A",es:"Cambiaron la batería y arreglaron el pito.",en:"They changed the battery and fixed the horn.",tts:"Cambiaron la batería y arreglaron el pito."},
    {who:"B",es:"¡Uy, qué caro!",en:"Wow, so expensive!",tts:"¡Uy, qué caro!"}]},
  {title:"Preparar la cocina",tense:"Ahora",lines:[{who:"A",es:"¿Dónde está el cuchillo?",en:"Where is the knife?",tts:"¿Dónde está el cuchillo?"},{who:"B",es:"Está en el cajón, junto a la cuchara.",en:"It is in the drawer, next to the spoon.",tts:"Está en el cajón, junto a la cuchara."},{who:"A",es:"Voy a cortar las verduras.",en:"I am going to cut the vegetables.",tts:"Voy a cortar las verduras."},{who:"B",es:"Listo, yo caliento la olla.",en:"All right, I will heat the pot.",tts:"Listo, yo caliento la olla."}]},
  {title:"Preparar la cocina",tense:"Planes",lines:[
    {who:"A",es:"¿Qué vamos a cocinar mañana?",en:"What are we going to cook tomorrow?",tts:"¿Qué vamos a cocinar mañana?"},
    {who:"B",es:"Vamos a freír unas arepas.",en:"We're going to fry some arepas.",tts:"Vamos a freír unas arepas."},
    {who:"A",es:"Voy a sacar los huevos de la nevera.",en:"I'm going to get the eggs out of the fridge.",tts:"Voy a sacar los huevos de la nevera."}]},
  {title:"Preparar la cocina",tense:"Ayer",lines:[
    {who:"A",es:"¿Qué cocinaste anoche?",en:"What did you cook last night?",tts:"¿Qué cocinaste anoche?"},
    {who:"B",es:"Hice una sopa. Herví las verduras en la olla.",en:"I made a soup. I boiled the vegetables in the pot.",tts:"Hice una sopa. Herví las verduras en la olla."},
    {who:"A",es:"¿Y probaste la salsa?",en:"And did you taste the sauce?",tts:"¿Y probaste la salsa?"},
    {who:"B",es:"Sí, ¡quedó deliciosa!",en:"Yes, it turned out delicious!",tts:"Sí, ¡quedó deliciosa!"}]},
  {title:"Pronombres en acción",tense:"Ahora",lines:[
    {who:"A",es:"¿Me lo puede repetir, por favor?",en:"Can you repeat it for me, please?",tts:"¿Me lo puede repetir, por favor?"},
    {who:"B",es:"Sí, se lo repito despacio.",en:"Yes, I'll repeat it slowly.",tts:"Sí, se lo repito despacio."},
    {who:"A",es:"¿La dirección la tiene?",en:"Do you have the address?",tts:"¿La dirección la tiene?"},
    {who:"B",es:"Sí, la tengo aquí.",en:"Yes, I have it here.",tts:"Sí, la tengo aquí."}]},
  {title:"Pronombres en acción",tense:"Planes",lines:[
    {who:"A",es:"¿Me lo va a mandar hoy?",en:"Are you going to send it to me today?",tts:"¿Me lo va a mandar hoy?"},
    {who:"B",es:"Sí, se lo voy a mandar en la tarde.",en:"Yes, I'm going to send it to you this afternoon.",tts:"Sí, se lo voy a mandar en la tarde."},
    {who:"A",es:"¿La ubicación la tiene?",en:"Do you have the location?",tts:"¿La ubicación la tiene?"},
    {who:"B",es:"No, pero me la puede enviar.",en:"No, but you can send it to me.",tts:"No, pero me la puede enviar."}]},
  {title:"Pronombres en acción",tense:"Ayer",lines:[
    {who:"A",es:"¿Le explicaste el problema?",en:"Did you explain the problem to him/her?",tts:"¿Le explicaste el problema?"},
    {who:"B",es:"Sí, se lo expliqué al técnico.",en:"Yes, I explained it to the technician.",tts:"Sí, se lo expliqué al técnico."},
    {who:"A",es:"¿La factura la guardaste?",en:"Did you save the invoice?",tts:"¿La factura la guardaste?"},
    {who:"B",es:"Sí, la guardé en el archivo.",en:"Yes, I saved it in the file.",tts:"Sí, la guardé en el archivo."}]}
 ];

/* v36: practical conversations.  The helper keeps every line's TTS field
   consistent while still storing both sides and the English meaning. */
const v36Lines=rows=>rows.map(([who,es,en])=>({who,es,en,tts:es}));
const v36Conversation=(title,en,now,plans,was)=>[
  {title,tense:"Ahora",lines:v36Lines(now)},
  ...(plans?[{title,tense:"Planes",lines:v36Lines(plans)}]:[]),
  ...(was?[{title,tense:"Ayer",lines:v36Lines(was)}]:[])
];
const V36_CONVERSATIONS=[
  ...v36Conversation("Uber: confirmar la recogida","Confirming an Uber pickup",[
    ["A","Buenas, ¿usted es mi conductor?","Hi, are you my driver?"],["B","Sí, soy yo. ¿Usted es Seth?","Yes, that's me. Are you Seth?"],["A","Sí. Estoy al frente del hotel.","Yes. I am in front of the hotel."],["B","Ya lo veo. Estoy en un carro gris.","I see you now. I am in a gray car."],["A","Perfecto. Voy para este hotel.","Perfect. I'm going to this hotel."],["B","Listo, súbase. ¿Tiene el equipaje?","Okay, get in. Do you have your luggage?"],["A","Sí, aquí está. Muchas gracias.","Yes, here it is. Thank you very much."]
  ],[
    ["A","Buenas, mañana tengo un viaje al aeropuerto.","Hi, tomorrow I have a trip to the airport."],["B","Claro, puedo recogerlo a las seis.","Sure, I can pick you up at six."],["A","¿Puede confirmar la dirección?","Can you confirm the address?"],["B","Sí, lo recojo frente al hotel.","Yes, I will pick you up in front of the hotel."],["A","Perfecto, le escribo cuando esté listo.","Perfect, I will message you when I am ready."],["B","De una. Nos vemos mañana.","Sounds good. See you tomorrow."]
  ],[
    ["A","Ayer pedí un Uber desde el hotel.","Yesterday I requested an Uber from the hotel."],["B","¿El conductor encontró la dirección?","Did the driver find the address?"],["A","Sí, lo vi al frente del edificio.","Yes, I saw him in front of the building."],["B","¿Llegó a tiempo?","Did you arrive on time?"],["A","Sí, pero había mucho trancón.","Yes, but there was a lot of traffic."],["B","Bueno, lo importante es que llegó bien.","Well, the important thing is that you arrived safely."]
  ]),
  ...v36Conversation("Uber: hablo poquito español","Explaining limited Spanish to a driver",[
    ["A","Buenas, hablo poquito español.","Hi, I speak a little Spanish."],["B","Tranquilo, ¿para dónde va?","No worries, where are you going?"],["A","Voy para este hotel.","I'm going to this hotel."],["B","¿Quiere que usemos la dirección de la aplicación?","Do you want us to use the address in the app?"],["A","Sí, por favor. ¿Puede hablar más despacio?","Yes, please. Can you speak more slowly?"],["B","Claro. No se preocupe.","Sure. Don't worry."],["A","Gracias por tener paciencia.","Thanks for being patient."]
  ]),
  ...v36Conversation("Uber: pedir que repita","Asking the driver to repeat",[
    ["A","Perdón, no entendí.","Sorry, I didn't understand."],["B","Le pregunté si quiere ir por esta avenida.","I asked if you want to go along this avenue."],["A","¿Me puede repetir, por favor?","Can you repeat that, please?"],["B","¿Quiere ir por esta avenida?","Do you want to go along this avenue?"],["A","Sí, está bien. Más despacio, por favor.","Yes, that's fine. More slowly, please."],["B","Listo, vamos despacio.","Okay, we will go slowly."]
  ]),
  ...v36Conversation("Uber: dirección equivocada","Fixing a wrong pickup or building",[
    ["A","Creo que estamos en el edificio equivocado.","I think we are at the wrong building."],["B","¿La dirección dice número veinte?","Does the address say number twenty?"],["A","Sí, pero la entrada está por allá.","Yes, but the entrance is over there."],["B","¿Es el edificio alto de la esquina?","Is it the tall building on the corner?"],["A","Sí. Devuélvase un poquito, por favor.","Yes. Go back a little, please."],["B","Listo, ya estamos en la entrada.","Okay, we are at the entrance now."],["A","Perfecto. Muchas gracias.","Perfect. Thank you very much."]
  ]),
  ...v36Conversation("Hotel: registrarse","Checking into a hotel",[
    ["A","Buenas, tengo una reserva a nombre de Seth.","Hi, I have a reservation under Seth's name."],["B","Buenas. ¿Me puede mostrar el pasaporte?","Hi. Can you show me your passport?"],["A","Claro, aquí tiene.","Of course, here you go."],["B","Su habitación está en el segundo piso.","Your room is on the second floor."],["A","¿A qué hora es el desayuno?","What time is breakfast?"],["B","De seis a diez, en el primer piso.","From six to ten, on the first floor."],["A","Muchas gracias. ¿Dónde está el ascensor?","Thank you very much. Where is the elevator?"]
  ],[
    ["A","Mañana voy a llegar al hotel a las ocho.","Tomorrow I am going to arrive at the hotel at eight."],["B","Perfecto, vamos a tener su habitación lista.","Perfect, we will have your room ready."],["A","¿Puedo dejar el equipaje antes?","Can I leave my luggage earlier?"],["B","Sí, puede dejarlo en recepción.","Yes, you can leave it at reception."],["A","De una. Nos vemos mañana.","Sounds good. See you tomorrow."],["B","Con mucho gusto.","With pleasure."]
  ],[
    ["A","Ayer llegué al hotel y mostré mi pasaporte.","Yesterday I arrived at the hotel and showed my passport."],["B","¿Le dieron la habitación enseguida?","Did they give you the room right away?"],["A","Sí, pero pregunté por el ascensor.","Yes, but I asked about the elevator."],["B","¿Y dónde estaba el desayuno?","And where was breakfast?"],["A","Estaba en el primer piso.","It was on the first floor."],["B","Qué bien. ¿Descansó?","Great. Did you rest?"]
  ]),
  ...v36Conversation("Restaurante: pedir y cambiar","Ordering and changing a restaurant order",[
    ["A","Buenas, quisiera pedir una sopa y un jugo.","Hi, I would like to order a soup and a juice."],["B","Claro. ¿La sopa con arroz o con papa?","Sure. Soup with rice or potato?"],["A","Con papa, por favor. Sin picante.","With potato, please. Without spice."],["B","¿Y para tomar?","And to drink?"],["A","Un jugo de mango, pero sin azúcar.","A mango juice, but without sugar."],["B","Listo, ya le traigo todo.","Okay, I will bring everything right away."],["A","Perdón, ¿puede cambiar el jugo por agua?","Sorry, can you change the juice for water?"]
  ],null,[
    ["A","Ayer pedí una sopa en un restaurante.","Yesterday I ordered a soup at a restaurant."],["B","¿Te gustó?","Did you like it?"],["A","Sí, pero estaba un poco picante.","Yes, but it was a little spicy."],["B","¿Pediste algo para tomar?","Did you order something to drink?"],["A","Sí, pedí agua y después la cuenta.","Yes, I ordered water and then the bill."],["B","¿Pagaste con tarjeta?","Did you pay by card?"]
  ]),
  ...v36Conversation("Farmacia: explicar síntomas","Explaining symptoms at a pharmacy",[
    ["A","Buenas, necesito algo para el dolor de cabeza.","Hi, I need something for a headache."],["B","¿Desde cuándo le duele?","Since when has it hurt?"],["A","Desde esta mañana.","Since this morning."],["B","¿Tiene fiebre o tos?","Do you have a fever or cough?"],["A","No, pero me siento cansado.","No, but I feel tired."],["B","Le recomiendo estas pastillas.","I recommend these pills."],["A","¿Cómo las debo tomar?","How should I take them?"]
  ]),
  ...v36Conversation("Mercado: comprar comida","Buying food at a Colombian market",[
    ["A","Buenas, ¿cuánto cuestan estas arepas?","Hi, how much do these arepas cost?"],["B","Son cinco mil pesos las dos.","They are five thousand pesos for two."],["A","Me regala dos, por favor.","Can I have two, please?"],["B","Claro. ¿Algo más?","Sure. Anything else?"],["A","Sí, necesito tomates y aguacate.","Yes, I need tomatoes and avocado."],["B","Todo cuesta quince mil.","Everything costs fifteen thousand."],["A","¿Puedo pagar con tarjeta?","Can I pay by card?"]
  ]),
  ...v36Conversation("Teléfono: mala señal","Handling a phone call with a bad signal",[
    ["A","¿Aló? ¿Me escuchas?","Hello? Can you hear me?"],["B","Te escucho, pero la señal está mala.","I can hear you, but the signal is bad."],["A","Se está cortando la llamada.","The call is cutting out."],["B","Te llamo más tarde.","I will call you later."],["A","No, mándame un mensaje mejor.","No, send me a message instead."],["B","Listo. Te escribo en un momento.","Okay. I will text you in a moment."]
  ],null,[
    ["A","Ayer llamé, pero no tenía señal.","Yesterday I called, but I had no signal."],["B","¿Se cortó la llamada?","Did the call drop?"],["A","Sí. Después mandé un mensaje.","Yes. Then I sent a message."],["B","¿Te respondieron?","Did they answer you?"],["A","Sí, me respondieron en la noche.","Yes, they answered me at night."],["B","Qué bueno.","That's good."]
  ]),
  ...v36Conversation("Compañeros de trabajo","Meeting coworkers",[
    ["A","Hola, soy nuevo en el equipo.","Hi, I am new on the team."],["B","Mucho gusto. Yo trabajo con el jefe.","Nice to meet you. I work with the boss."],["A","¿En qué proyecto estás trabajando?","What project are you working on?"],["B","Estoy trabajando en el proyecto de ventas.","I am working on the sales project."],["A","Tengo una reunión a las diez.","I have a meeting at ten."],["B","De una. Después tomamos un tinto.","Sounds good. We can have a coffee afterward."]
  ]),
  ...v36Conversation("Planes de fin de semana","Making weekend plans",[
    ["A","¿Qué vas a hacer este fin de semana?","What are you going to do this weekend?"],["B","Voy a visitar a mi familia.","I am going to visit my family."],["A","¿Nos vemos el sábado?","Shall we meet Saturday?"],["B","De una. ¿A qué hora?","Sure. What time?"],["A","A las tres, para tomar un tinto.","At three, to have a coffee."],["B","Listo. Te aviso el lugar.","Okay. I will let you know the place."]
  ],[
    ["A","El próximo sábado voy a visitar a mi familia.","Next Saturday I am going to visit my family."],["B","Entonces podemos vernos el domingo.","Then we can meet Sunday."],["A","Sí, si tengo tiempo te escribo.","Yes, if I have time I will text you."],["B","Perfecto. ¿Quieres ir a un café?","Perfect. Do you want to go to a café?"],["A","Sí, me gustaría conocer uno nuevo.","Yes, I would like to try a new one."],["B","Hágale. Quedamos así.","Let's do it. It's a plan."]
  ]),
  ...v36Conversation("Problema con apartamento o carro","Reporting a home, car, or reservation problem",[
    ["A","Buenas, la ducha no funciona.","Hi, the shower does not work."],["B","¿Desde cuándo tiene el problema?","Since when have you had the problem?"],["A","Desde ayer. También hay una gotera.","Since yesterday. There is also a leak."],["B","Voy a mandar un técnico esta tarde.","I am going to send a technician this afternoon."],["A","Perfecto. ¿A qué hora viene?","Perfect. What time is he coming?"],["B","Llega entre dos y cuatro.","He will arrive between two and four."],["A","Muchas gracias por la ayuda.","Thank you very much for the help."]
  ],null,[
    ["A","Ayer se dañó el carro en la carretera.","Yesterday the car broke down on the road."],["B","¿Qué parte se dañó?","What part broke?"],["A","La llanta estaba baja y el motor se apagó.","The tire was low and the engine turned off."],["B","¿Llamaste al seguro?","Did you call the insurance company?"],["A","Sí, pero tuve que esperar una hora.","Yes, but I had to wait an hour."],["B","Qué problema. ¿Ya está funcionando?","What a problem. Is it working now?"]
  ])
];
CONVERSATIONS.push(...V36_CONVERSATIONS);
const V38_CONVERSATIONS=[
  ...v36Conversation("Palabras para conversar","Using everyday glue words to keep a conversation moving",[
    ["A","¿Qué vas a hacer después del trabajo?","What are you going to do after work?"],
    ["B","Todavía no sé. De pronto voy a pasar por el mercado.","I don't know yet. Maybe I am going to stop by the market."],
    ["A","Bueno, si tienes tiempo, me avisas.","Well, if you have time, let me know."],
    ["B","De una. En cuanto pueda te escribo.","Sure. I will text you as soon as I can."]
  ],[
    ["A","¿Qué piensas hacer mañana?","What are you thinking of doing tomorrow?"],
    ["B","Por ahora no tengo planes.","For now I don't have plans."],
    ["A","Si no llueve, podemos ir a tomar un tinto.","If it doesn't rain, we can go have a coffee."],
    ["B","Más bien nos vemos al rato, ¿te parece?","Instead, let's meet later. What do you think?"]
  ],[
    ["A","¿Qué pasó ayer?","What happened yesterday?"],
    ["B","El problema es que había mucho trancón.","The problem is that there was a lot of traffic."],
    ["A","¿Llegaste tarde?","Did you arrive late?"],
    ["B","Sí, pero de hecho llegué a tiempo.","Yes, but in fact I arrived on time."]
  ])
];
CONVERSATIONS.push(...V38_CONVERSATIONS);
const V39_CONVERSATIONS=[
  ...v36Conversation("Acciones de todos los días","High-frequency action chunks in a natural conversation",[
    ["A","¿Qué quieres hacer después del trabajo?","What do you want to do after work?"],
    ["B","Quiero pasar por el mercado, pero tengo que llegar temprano.","I want to stop by the market, but I have to arrive early."],
    ["A","¿Vas para tu casa después?","Are you headed home afterward?"],
    ["B","Sí, voy para la casa y acabo de comprar la comida.","Yes, I am headed home and I just bought the food."]
  ],[
    ["A","¿Qué estás haciendo?","What are you doing?"],
    ["B","Estoy buscando la dirección. No puedo encontrarla.","I am looking for the address. I can't find it."],
    ["A","¿Te puedo ayudar?","Can I help you?"],
    ["B","Sí, me hace falta la ubicación. Te la mando en un momento.","Yes, I need the location. I will send it to you in a moment."]
  ],[
    ["A","¿Qué pasó ayer?","What happened yesterday?"],
    ["B","Se me olvidó la cita y me tocó llamar para cambiarla.","I forgot the appointment and had to call to change it."],
    ["A","¿Y después qué hiciste?","And what did you do afterward?"],
    ["B","Me quedé en casa porque estaba cansado.","I stayed home because I was tired."]
  ])
];
CONVERSATIONS.push(...V39_CONVERSATIONS);

/* v60: longer, task-based conversations. Each one follows a real-life arc:
   opening → request → clarification → confirmation/closing. */
const v60Lines=rows=>rows.map(([who,es,en])=>({who,es,en,tts:es}));
const v60Dialogue=(title,en,rows,alternates=[])=>({title,en,tense:"Ahora",lines:v60Lines(rows),alternates});
const V60_CONVERSATIONS=[
  v60Dialogue("Comunicación: pedir y aclarar","Asking someone to repeat and give directions",[
    ["A","Perdón, ¿me puede ayudar?","Excuse me, can you help me?"],["B","Claro, dígame.","Of course, tell me."],["A","Hábleme más despacio, por favor.","Speak to me more slowly, please."],["B","Sí, cómo no.","Yes, of course."],["A","¿Me puede repetir la dirección?","Can you repeat the address for me?"],["B","Sí, siga derecho y gire a la derecha.","Yes, go straight and turn right."],["A","Disculpe, ¿es el edificio de allá?","Excuse me, is it that building over there?"],["B","Sí, ese mismo.","Yes, that one."]
  ],[{es:"¿Me puede hablar un poco más despacio, por favor?",en:"Can you speak a little more slowly, please?",tts:"¿Me puede hablar un poco más despacio, por favor?"},{es:"Perdón, ¿me lo puede repetir?",en:"Sorry, can you repeat that for me?",tts:"Perdón, ¿me lo puede repetir?"}]),
  v60Dialogue("Uber: viaje completo","A complete Uber ride from pickup to drop-off",[
    ["A","Hola, ¿usted es el conductor de Uber?","Hi, are you the Uber driver?"],["B","Sí, soy yo. ¿Usted es Seth?","Yes, that's me. Are you Seth?"],["A","Sí. Hablo un poco de español. ¿Puede hablar despacio?","Yes. I speak a little Spanish. Can you speak slowly?"],["B","Claro, no hay problema.","Of course, no problem."],["A","Voy para este edificio, el de la esquina.","I'm going to this building, the one on the corner."],["B","¿El edificio alto que está al frente?","The tall building that's across the way?"],["A","Sí, ese mismo. Avíseme dónde me bajo, por favor.","Yes, that one. Please let me know where I get out."],["B","Listo, llegamos en unos minutos.","Okay, we'll arrive in a few minutes."]
  ],[{es:"Voy para el edificio de la esquina. ¿Me puede avisar cuando lleguemos?",en:"I'm going to the building on the corner. Can you let me know when we arrive?",tts:"Voy para el edificio de la esquina. ¿Me puede avisar cuando lleguemos?"},{es:"No conozco mucho la ciudad; ¿me ayuda con la dirección?",en:"I don't know the city very well; can you help me with the address?",tts:"No conozco mucho la ciudad; ¿me ayuda con la dirección?"}]),
  v60Dialogue("Restaurante: una comida completa","Ordering, changing an order, and asking for the bill",[
    ["A","Buenas, ¿tiene una mesa para dos?","Hi, do you have a table for two?"],["B","Sí, por aquí.","Yes, this way."],["A","Quisiera una sopa y un jugo, por favor.","I would like a soup and a juice, please."],["B","¿La sopa la quiere con arroz o con papa?","Would you like the soup with rice or potato?"],["A","Con papa. Y el jugo sin azúcar, por favor.","With potato. And the juice without sugar, please."],["B","Claro. ¿Algo más?","Of course. Anything else?"],["A","No, gracias. ¿Me trae la cuenta cuando pueda?","No, thank you. Can you bring me the bill when you can?"],["B","De una, ya se la traigo.","Sure, I'll bring it right away."]
  ],[{es:"Me gustaría pedir una sopa y algo para tomar.",en:"I would like to order a soup and something to drink.",tts:"Me gustaría pedir una sopa y algo para tomar."},{es:"¿Me puede traer la cuenta, por favor?",en:"Can you bring me the bill, please?",tts:"¿Me puede traer la cuenta, por favor?"}]),
  v60Dialogue("Mercado: comprar y negociar","Buying food and negotiating a price",[
    ["A","Buenas, ¿cuánto cuesta el kilo de tomates?","Hi, how much does a kilo of tomatoes cost?"],["B","Cuesta ocho mil pesos.","It costs eight thousand pesos."],["A","Está un poco caro. ¿Me lo deja en siete?","It's a little expensive. Can you let me have it for seven?"],["B","Bueno, se lo dejo en siete mil.","Okay, I'll let you have it for seven thousand."],["A","Listo, deme un kilo y dos aguacates.","Great, give me a kilo and two avocados."],["B","¿Algo más?","Anything else?"],["A","No, gracias. ¿Puedo pagar con Nequi?","No, thank you. Can I pay with Nequi?"],["B","Sí, claro.","Yes, of course."]
  ],[{es:"¿Me hace un descuento si compro dos?",en:"Can you give me a discount if I buy two?",tts:"¿Me hace un descuento si compro dos?"},{es:"¿Cuánto le debo por todo?",en:"How much do I owe you for everything?",tts:"¿Cuánto le debo por todo?"}]),
  v60Dialogue("Cocinar y hablar de lo que haces","Talking about what you are doing",[
    ["A","¿Qué estás haciendo?","What are you doing?"],["B","Estoy cocinando la cena.","I'm cooking dinner."],["A","¿Y después qué vas a hacer?","And what are you going to do afterward?"],["B","Voy a salir con unos amigos.","I'm going to go out with some friends."],["A","Yo estaba trabajando cuando me llamaste.","I was working when you called me."],["B","Perdón, no sabía.","Sorry, I didn't know."],["A","No pasa nada. Ahora estoy descansando.","No problem. Now I'm resting."],["B","Qué bien, te lo mereces.","Great, you deserve it."]
  ],[{es:"En este momento estoy preparando la comida.",en:"At this moment I am preparing the food.",tts:"En este momento estoy preparando la comida."},{es:"Acabo de llegar y estoy buscando algo para comer.",en:"I just arrived and I am looking for something to eat.",tts:"Acabo de llegar y estoy buscando algo para comer."}]),
  v60Dialogue("Salir con amigos","Making and adjusting plans with friends",[
    ["A","¿Qué más? ¿Qué vas a hacer esta noche?","What's up? What are you going to do tonight?"],["B","Voy a salir con unos amigos.","I'm going out with some friends."],["A","¿Nos vemos después?","Shall we meet later?"],["B","De una, pero llego un poco tarde.","Sure, but I'll arrive a little late."],["A","No hay problema. Avísame cuando llegues.","No problem. Let me know when you arrive."],["B","Listo, te escribo.","Okay, I'll text you."],["A","¿Quieres ir a comer algo?","Do you want to go eat something?"],["B","Sí, me parece buena idea.","Yes, I think that's a good idea."]
  ],[{es:"¿Te parece si nos vemos más tarde?",en:"How about we meet later?",tts:"¿Te parece si nos vemos más tarde?"},{es:"De pronto llego después de las ocho.",en:"Maybe I'll arrive after eight.",tts:"De pronto llego después de las ocho."}]),
  v60Dialogue("En una fiesta","Meeting people and making conversation at a party",[
    ["A","Hola, ¿cómo conoces a la gente de aquí?","Hi, how do you know the people here?"],["B","Soy amigo de Laura. ¿Y tú?","I'm a friend of Laura. And you?"],["A","También. ¿Quieres algo de tomar?","Me too. Do you want something to drink?"],["B","Sí, gracias. Un jugo está bien.","Yes, thank you. A juice is fine."],["A","La música está muy buena.","The music is really good."],["B","Sí, está chévere.","Yes, it's cool."],["A","Me tengo que ir, pero la pasé muy bien.","I have to go, but I had a great time."],["B","Nos vemos, cuídate.","See you, take care."]
  ],[{es:"¿Ya conocías a alguien antes de venir?",en:"Did you already know anyone before coming?",tts:"¿Ya conocías a alguien antes de venir?"},{es:"Qué gusto conocerte. Nos vemos luego.",en:"Nice to meet you. See you later.",tts:"Qué gusto conocerte. Nos vemos luego."}]),
  v60Dialogue("Ver el partido","Talking about a soccer match",[
    ["A","¿Vas a ver el partido esta noche?","Are you going to watch the game tonight?"],["B","Claro, no me lo pierdo.","Of course, I wouldn't miss it."],["A","¿Quién está jugando?","Who's playing?"],["B","Juega Colombia contra Brasil.","Colombia is playing against Brazil."],["A","Ojalá gane Colombia.","I hope Colombia wins."],["B","Sí, vamos con toda.","Yes, let's give it our all."],["A","Si hacen gol, te escribo.","If they score, I'll text you."],["B","De una, lo vemos juntos.","Sure, we'll watch it together."]
  ],[{es:"¿Cómo va el marcador?",en:"How is the score?",tts:"¿Cómo va el marcador?"},{es:"Ese partido estuvo buenísimo.",en:"That game was really great.",tts:"Ese partido estuvo buenísimo."}]),
  v60Dialogue("Oficina: proyecto y retraso","Explaining progress and a delay at work",[
    ["A","¿Cómo va el proyecto?","How is the project going?"],["B","Va bien, pero estoy un poco atrasado.","It's going well, but I'm a little behind."],["A","¿Necesitas ayuda con el informe?","Do you need help with the report?"],["B","Sí, ¿me puede revisar esta parte?","Yes, can you review this part for me?"],["A","Claro, se la reviso después de la reunión.","Of course, I'll review it after the meeting."],["B","Perfecto. Yo termino los datos hoy.","Perfect. I'll finish the data today."],["A","Entonces mañana lo mandamos al cliente.","Then tomorrow we'll send it to the client."],["B","Listo, me parece bien.","Okay, sounds good to me."]
  ],[{es:"El proyecto está casi listo, pero necesito un día más.",en:"The project is almost ready, but I need one more day.",tts:"El proyecto está casi listo, pero necesito un día más."},{es:"¿Me puede dar una mano con este informe?",en:"Can you give me a hand with this report?",tts:"¿Me puede dar una mano con este informe?"}])
];
CONVERSATIONS.push(...V60_CONVERSATIONS);

FRASES.push(
  {section:"🗣️ Pedir, repetir y aclarar",quizCat:"mandatos",cls:"color:var(--teal);background:rgba(74,168,160,0.1);border:1px solid rgba(74,168,160,0.2)",items:[{es:"Háblame más despacio.",en:"Speak to me more slowly. (informal)"},{es:"Hábleme más despacio, por favor.",en:"Speak to me more slowly, please. (formal)"},{es:"Dígame la dirección.",en:"Tell me the address. (formal)"},{es:"Escúchame un momento.",en:"Listen to me for a moment. (informal)"},{es:"Repítame la pregunta, por favor.",en:"Repeat the question for me, please. (formal)"},{es:"Disculpe, no entendí.",en:"Excuse me, I didn't understand."},{es:"Dime otra vez.",en:"Tell me again. (informal)"},{es:"¿Me puede mostrar?","en":"Can you show me?"}]},
  {section:"🚗 Un viaje completo en Uber",quizCat:"uber-real",cls:"color:var(--blue);background:rgba(96,165,250,0.1);border:1px solid rgba(96,165,250,0.2)",items:[{es:"¿Usted es el conductor de Uber?",en:"Are you the Uber driver?"},{es:"Hablo un poco de español.",en:"I speak a little Spanish."},{es:"¿Puede hablar despacio?",en:"Can you speak slowly?"},{es:"Voy para el edificio de la esquina.",en:"I'm going to the building on the corner."},{es:"El de allá, al frente.",en:"The one over there, across the way."},{es:"Avíseme dónde me bajo.",en:"Let me know where I get out."},{es:"¿Cuánto falta?",en:"How much longer?"},{es:"Ya llegamos.",en:"We've arrived."}]},
  {section:"🍽️ Comer fuera — conversación real",quizCat:"restaurante-real",cls:"color:var(--gold);background:rgba(232,180,74,0.1);border:1px solid rgba(232,180,74,0.2)",items:[{es:"¿Tiene una mesa para dos?",en:"Do you have a table for two?"},{es:"Quisiera pedir…",en:"I would like to order…"},{es:"Con papa, por favor.",en:"With potato, please."},{es:"Sin azúcar.",en:"Without sugar."},{es:"¿Algo más?",en:"Anything else?"},{es:"¿Me cambia esto, por favor?",en:"Can you change this for me, please?"},{es:"¿Me trae la cuenta?",en:"Can you bring me the bill?"},{es:"¿Puedo pagar con tarjeta?",en:"Can I pay by card?"}]},
  {section:"🛍️ Mercado — comprar y negociar",quizCat:"mercado",cls:"color:var(--green);background:rgba(52,211,153,0.1);border:1px solid rgba(52,211,153,0.2)",items:[{es:"¿Cuánto cuesta el kilo?",en:"How much does a kilo cost?"},{es:"Está un poco caro.",en:"It's a little expensive."},{es:"¿Me lo deja en siete?",en:"Can you let me have it for seven?"},{es:"¿Me hace un descuento?",en:"Can you give me a discount?"},{es:"Deme dos, por favor.",en:"Give me two, please."},{es:"¿Cuánto le debo por todo?",en:"How much do I owe you for everything?"},{es:"¿Puedo pagar con Nequi?",en:"Can I pay with Nequi?"},{es:"Listo, muchas gracias.",en:"Great, thank you very much."}]},
  {section:"🔄 Actividades en progreso",quizCat:"gerundios",cls:"color:var(--purple);background:rgba(167,139,250,0.1);border:1px solid rgba(167,139,250,0.2)",items:[{es:"Estoy cocinando.",en:"I am cooking."},{es:"Estoy buscando la dirección.",en:"I am looking for the address."},{es:"Estoy aprendiendo español.",en:"I am learning Spanish."},{es:"Está lloviendo.",en:"It is raining."},{es:"¿Qué estás haciendo?",en:"What are you doing?"},{es:"Estaba trabajando.",en:"I was working."},{es:"Acabo de llegar.",en:"I just arrived."},{es:"Fui de compras.",en:"I went shopping."}]},
  {section:"🤝 Salir con amigos",quizCat:"social",cls:"color:var(--pink);background:rgba(232,93,117,0.1);border:1px solid rgba(232,93,117,0.2)",items:[{es:"¿Qué vas a hacer esta noche?",en:"What are you going to do tonight?"},{es:"Voy a salir con unos amigos.",en:"I'm going out with some friends."},{es:"¿Nos vemos después?",en:"Shall we meet later?"},{es:"De una.",en:"Sure / I'm in. (Colombian)"},{es:"Llego un poco tarde.",en:"I'll arrive a little late."},{es:"Avísame cuando llegues.",en:"Let me know when you arrive."},{es:"¿Quieres ir a comer algo?",en:"Do you want to go eat something?"},{es:"Me parece buena idea.",en:"I think that's a good idea."}]},
  {section:"🎉 En una fiesta",quizCat:"fiesta",cls:"color:var(--pink);background:rgba(232,93,117,0.1);border:1px solid rgba(232,93,117,0.2)",items:[{es:"¿Cómo conoces a la gente de aquí?",en:"How do you know the people here?"},{es:"Soy amigo de…",en:"I'm a friend of…"},{es:"¿Quieres algo de tomar?",en:"Do you want something to drink?"},{es:"Un jugo está bien.",en:"A juice is fine."},{es:"La música está muy buena.",en:"The music is really good."},{es:"Está chévere.",en:"It's cool."},{es:"La pasé muy bien.",en:"I had a great time."},{es:"Me tengo que ir.",en:"I have to go."}]},
  {section:"⚽ Ver el partido",quizCat:"deportes",cls:"color:var(--gold);background:rgba(232,180,74,0.1);border:1px solid rgba(232,180,74,0.2)",items:[{es:"¿Vas a ver el partido?",en:"Are you going to watch the game?"},{es:"No me lo pierdo.",en:"I wouldn't miss it."},{es:"¿Quién está jugando?",en:"Who's playing?"},{es:"¿Cómo va el marcador?",en:"How is the score?"},{es:"Ojalá gane Colombia.",en:"I hope Colombia wins."},{es:"Vamos con toda.",en:"Let's give it our all. (Colombian)"},{es:"Hicieron gol.",en:"They scored."},{es:"Lo vemos juntos.",en:"We'll watch it together."}]},
  {section:"🧑‍💼 Oficina — conversación real",quizCat:"oficina-real",cls:"color:var(--teal);background:rgba(74,168,160,0.1);border:1px solid rgba(74,168,160,0.2)",items:[{es:"¿Cómo va el proyecto?",en:"How is the project going?"},{es:"Estoy un poco atrasado.",en:"I'm a little behind."},{es:"¿Necesitas ayuda?",en:"Do you need help?"},{es:"¿Me puede revisar esta parte?",en:"Can you review this part for me?"},{es:"Se la reviso después.",en:"I'll review it for you afterward."},{es:"Termino los datos hoy.",en:"I'll finish the data today."},{es:"Lo mandamos mañana.",en:"We'll send it tomorrow."},{es:"Me parece bien.",en:"Sounds good to me."}]}
);

 /* Speaking missions: situations first, with more than one natural answer. */
 const CONVERSATION_MISSIONS=[
   {id:"taxi-aeropuerto",title:"Pide un taxi",scenario:"You are outside a hotel in Bogotá. Ask the driver to take you to the airport and ask the price.",prompt:"Di tu respuesta en español:",lesson:"calle",models:[{es:"¿Me lleva al aeropuerto, por favor? ¿Cuánto cuesta?",en:"Can you take me to the airport, please? How much does it cost?",tts:"¿Me lleva al aeropuerto, por favor? ¿Cuánto cuesta?"},{es:"Buenas, necesito ir al aeropuerto. ¿Cuánto me cobra?",en:"Hi, I need to go to the airport. How much will you charge me?",tts:"Buenas, necesito ir al aeropuerto. ¿Cuánto me cobra?"}]},
   {id:"tinto-por-favor",title:"Pide un tinto",scenario:"You are in a Colombian café. Order a black coffee politely and say you want it without sugar.",prompt:"Di tu pedido:",lesson:"colombia",models:[{es:"¿Me regala un tinto, por favor? Sin azúcar.",en:"Can I have a black coffee, please? Without sugar.",tts:"¿Me regala un tinto, por favor? Sin azúcar."},{es:"Quisiera un tinto, por favor, y no le ponga azúcar.",en:"I would like a black coffee, please, and don't add sugar.",tts:"Quisiera un tinto, por favor, y no le ponga azúcar."}]},
   {id:"saludo-parce",title:"Saluda a un amigo",scenario:"You run into a Colombian friend you have not seen recently. Greet them and ask how things are going.",prompt:"Saluda de forma natural:",lesson:"colombia",models:[{es:"¡Hola, parce! ¿Qué más?",en:"Hi, buddy! What's up?",tts:"¡Hola, parce! ¿Qué más?"},{es:"¿Qué más, parce? ¿Cómo te ha ido?",en:"What's up, buddy? How have things been?",tts:"¿Qué más, parce? ¿Cómo te ha ido?"}]},
   {id:"reunion-trabajo",title:"Habla de tu trabajo",scenario:"A new coworker asks what you are doing today. Say that you have a meeting and need to finish a project.",prompt:"Responde en español:",lesson:"trabajo",models:[{es:"Tengo una reunión y necesito terminar un proyecto.",en:"I have a meeting and I need to finish a project.",tts:"Tengo una reunión y necesito terminar un proyecto."},{es:"Estoy trabajando en un proyecto; después tengo una reunión.",en:"I am working on a project; afterward I have a meeting.",tts:"Estoy trabajando en un proyecto; después tengo una reunión."}]},
   {id:"problema-casa",title:"Explica un problema",scenario:"Something at home stopped working. Explain the problem and say you need help.",prompt:"Explica qué pasó:",lesson:"casa",models:[{es:"La ducha no funciona y necesito ayuda.",en:"The shower does not work and I need help.",tts:"La ducha no funciona y necesito ayuda."},{es:"Se dañó la ducha. ¿Me puede ayudar, por favor?",en:"The shower broke. Can you help me, please?",tts:"Se dañó la ducha. ¿Me puede ayudar, por favor?"}]},
   {id:"mercado-comida",title:"Compra comida",scenario:"You are at a market. Say what you need to buy and ask how much it costs.",prompt:"Habla con el vendedor:",lesson:"plata",models:[{es:"Necesito comprar arepas. ¿Cuánto cuestan?",en:"I need to buy arepas. How much do they cost?",tts:"Necesito comprar arepas. ¿Cuánto cuestan?"},{es:"¿Me regala dos arepas? ¿Cuánto le debo?",en:"Can I have two arepas? How much do I owe you?",tts:"¿Me regala dos arepas? ¿Cuánto le debo?"}]},
   {id:"contar-ayer",title:"Cuenta qué pasó",scenario:"A friend asks what you did yesterday. Say where you went and what you wanted to do afterward.",prompt:"Cuenta tu día:",lesson:"gram-pasado-historia",models:[{es:"Ayer fui al mercado y después quería descansar en casa.",en:"Yesterday I went to the market and afterward I wanted to rest at home.",tts:"Ayer fui al mercado y después quería descansar en casa."},{es:"Fui al mercado porque necesitaba comida; luego me quedé en casa.",en:"I went to the market because I needed food; then I stayed home.",tts:"Fui al mercado porque necesitaba comida; luego me quedé en casa."}]},
   {id:"planes-fin-semana",title:"Haz planes",scenario:"Ask a friend what they are going to do this weekend and suggest meeting for coffee.",prompt:"Propón un plan:",lesson:"planes",models:[{es:"¿Qué vas a hacer este fin de semana? ¿Nos vemos para un tinto?",en:"What are you going to do this weekend? Shall we meet for a coffee?",tts:"¿Qué vas a hacer este fin de semana? ¿Nos vemos para un tinto?"},{es:"¿Te parece si nos vemos el sábado para tomar un tinto?",en:"How about we meet Saturday for a coffee?",tts:"¿Te parece si nos vemos el sábado para tomar un tinto?"}]},
   {id:"direcciones-hospital",title:"Pide direcciones",scenario:"You are lost and need to find the hospital. Ask someone politely and repeat the key location.",prompt:"Pide ayuda:",lesson:"calle",models:[{es:"Disculpe, ¿dónde queda el hospital?",en:"Excuse me, where is the hospital?",tts:"Disculpe, ¿dónde queda el hospital?"},{es:"Perdón, estoy perdido. ¿Me regala la dirección del hospital?",en:"Sorry, I am lost. Could you give me the hospital's address?",tts:"Perdón, estoy perdido. ¿Me regala la dirección del hospital?"}]},
   {id:"como-te-sientes",title:"Explica cómo te sientes",scenario:"A friend asks how you feel. Say that you are tired, have a headache, and need to rest.",prompt:"Responde:",lesson:"sentirse",models:[{es:"Estoy cansado y me duele la cabeza. Necesito descansar.",en:"I am tired and my head hurts. I need to rest.",tts:"Estoy cansado y me duele la cabeza. Necesito descansar."},{es:"Me siento mal; tengo sueño y quiero descansar.",en:"I feel bad; I am sleepy and I want to rest.",tts:"Me siento mal; tengo sueño y quiero descansar."}]}
 ];

CONVERSATION_MISSIONS.push(
  {id:"uber-habla-despacio",title:"Pide que hablen despacio",scenario:"Your Uber driver speaks quickly. Explain that you are learning Spanish and ask them to repeat slowly.",prompt:"Responde con calma:",lesson:"uber-ride",models:[{es:"Hablo poquito español. ¿Puede hablar más despacio, por favor?",en:"I speak a little Spanish. Can you speak more slowly, please?",tts:"Hablo poquito español. ¿Puede hablar más despacio, por favor?"},{es:"Perdón, estoy aprendiendo español. ¿Me puede repetir?",en:"Sorry, I am learning Spanish. Can you repeat that?",tts:"Perdón, estoy aprendiendo español. ¿Me puede repetir?"}]},
  {id:"hotel-checkin",title:"Regístrate en el hotel",scenario:"Check in, show your passport, and ask where breakfast is.",prompt:"Haz el registro:",lesson:"hotel-checkin",models:[{es:"Buenas, tengo una reserva a nombre de Seth. ¿A qué hora es el desayuno?",en:"Hi, I have a reservation under Seth's name. What time is breakfast?",tts:"Buenas, tengo una reserva a nombre de Seth. ¿A qué hora es el desayuno?"},{es:"Claro, aquí tiene mi pasaporte. ¿Dónde está el ascensor?",en:"Of course, here is my passport. Where is the elevator?",tts:"Claro, aquí tiene mi pasaporte. ¿Dónde está el ascensor?"}]},
  {id:"farmacia-sintomas",title:"Explica síntomas",scenario:"At a pharmacy, say that you have a headache and ask how to take the medicine.",prompt:"Explica lo que necesitas:",lesson:"farmacia",models:[{es:"Necesito algo para el dolor de cabeza. ¿Cómo lo debo tomar?",en:"I need something for a headache. How should I take it?",tts:"Necesito algo para el dolor de cabeza. ¿Cómo lo debo tomar?"},{es:"Me siento cansado y me duele la cabeza desde esta mañana.",en:"I feel tired and my head has hurt since this morning.",tts:"Me siento cansado y me duele la cabeza desde esta mañana."}]},
  {id:"edificio-direcciones",title:"Encuentra el edificio",scenario:"You are looking for a building. Ask where the entrance is and repeat the directions.",prompt:"Pide y confirma la dirección:",lesson:"direcciones",models:[{es:"¿Me puede indicar? ¿Es el edificio de allá?",en:"Can you point it out? Is it that building over there?",tts:"¿Me puede indicar? ¿Es el edificio de allá?"},{es:"¿Dónde está la entrada? ¿Queda al frente o detrás del edificio?",en:"Where is the entrance? Is it in front of or behind the building?",tts:"¿Dónde está la entrada? ¿Queda al frente o detrás del edificio?"}]}
);
CONVERSATION_MISSIONS.push(
  {id:"acciones-diarias",title:"Habla de tus acciones",scenario:"A friend asks what you are doing and where you are going. Use two or three action chunks to answer naturally.",prompt:"Responde sin traducir palabra por palabra:",lesson:"action-chunks",models:[{es:"Estoy buscando la dirección y voy para el hotel. Te aviso cuando llegue.",en:"I am looking for the address and I am headed to the hotel. I will let you know when I arrive.",tts:"Estoy buscando la dirección y voy para el hotel. Te aviso cuando llegue."},{es:"Quiero pasar por el mercado, pero tengo que llegar a casa temprano.",en:"I want to stop by the market, but I have to get home early.",tts:"Quiero pasar por el mercado, pero tengo que llegar a casa temprano."}]}
);
CONVERSATION_MISSIONS.push(
  {id:"uber-ruta",title:"Corrige la ruta del Uber",scenario:"Your Uber driver seems to be going the wrong way. Explain the problem politely and confirm the destination.",prompt:"Responde con una frase para reparar la situación:",lesson:"uber-ride",models:[{es:"Disculpe, creo que vamos por otro lado. El destino es este hotel.",en:"Excuse me, I think we are going another way. The destination is this hotel.",tts:"Disculpe, creo que vamos por otro lado. El destino es este hotel."},{es:"Perdón, ¿puede revisar la dirección? Creo que esta no es la ruta.",en:"Sorry, can you check the address? I think this is not the route.",tts:"Perdón, ¿puede revisar la dirección? Creo que esta no es la ruta."}]},
  {id:"edificio-entrada",title:"Explica dónde está el edificio",scenario:"Someone asks for directions. Tell them to go straight, identify the building over there, and explain where the entrance is.",prompt:"Da las indicaciones:",lesson:"direcciones",models:[{es:"Siga derecho hasta el fondo. Es el edificio de allá y la entrada queda detrás.",en:"Go straight to the back. It is that building over there, and the entrance is behind it.",tts:"Siga derecho hasta el fondo. Es el edificio de allá y la entrada queda detrás."},{es:"Vaya derecho hasta la esquina; el edificio está al frente y la entrada queda por atrás.",en:"Go straight to the corner; the building is in front, and the entrance is in the back.",tts:"Vaya derecho hasta la esquina; el edificio está al frente y la entrada queda por atrás."}]},
  {id:"cita-cambio",title:"Cambia una cita",scenario:"You cannot attend an appointment tomorrow. Explain why and suggest another time.",prompt:"Llama y cambia la cita:",lesson:"planes",models:[{es:"Mañana no puedo ir porque tengo una reunión. ¿Podemos vernos el viernes?",en:"I cannot go tomorrow because I have a meeting. Can we meet Friday?",tts:"Mañana no puedo ir porque tengo una reunión. ¿Podemos vernos el viernes?"},{es:"Se me cruzó algo mañana. ¿Le parece si cambiamos la cita para la próxima semana?",en:"Something came up tomorrow. Would it be okay if we move the appointment to next week?",tts:"Se me cruzó algo mañana. ¿Le parece si cambiamos la cita para la próxima semana?"}]},
  {id:"si-entonces-plan",title:"Propón un plan con una condición",scenario:"Make a weekend plan with a friend. Say what you will do if the weather is good, and offer a backup plan.",prompt:"Habla de las dos posibilidades:",lesson:"planes",models:[{es:"Si hace buen tiempo, vamos al parque; si no, nos vemos para un tinto.",en:"If the weather is good, we will go to the park; if not, we will meet for a coffee.",tts:"Si hace buen tiempo, vamos al parque; si no, nos vemos para un tinto."},{es:"Si no llueve, podemos caminar. Si llueve, hacemos algo en casa.",en:"If it does not rain, we can walk. If it rains, we will do something at home.",tts:"Si no llueve, podemos caminar. Si llueve, hacemos algo en casa."}]}
);

 /* Short readings: read for meaning first, then shadow each sentence aloud. */
 const READINGS=[
   {id:"lectura-cafe",level:"A1",title:"Un tinto en la mañana",lesson:"colombia",intro:"A simple Colombian café order.",lines:[
     {es:"Por la mañana voy a una cafetería cerca de mi casa.",en:"In the morning I go to a café near my house.",tts:"Por la mañana voy a una cafetería cerca de mi casa."},
     {es:"¿Me regala un tinto, por favor?",en:"Can I have a black coffee, please?",tts:"¿Me regala un tinto, por favor?"},
     {es:"Sí, claro. ¿Lo quiere con azúcar?",en:"Yes, of course. Do you want it with sugar?",tts:"Sí, claro. ¿Lo quiere con azúcar?"},
     {es:"No, gracias. Así está bien.",en:"No, thank you. It is fine like that.",tts:"No, gracias. Así está bien."}
   ],questions:[{q:"¿Qué pide la persona?",choices:["Un tinto","Una cerveza","Un jugo"],answer:"Un tinto"}]},
   {id:"lectura-mercado",level:"A1",title:"En el mercado",lesson:"plata",intro:"Useful words for buying food.",lines:[
     {es:"Hoy necesito comprar mercado para la semana.",en:"Today I need to buy groceries for the week.",tts:"Hoy necesito comprar mercado para la semana."},
     {es:"Compro arepas, huevos, arroz y aguacates.",en:"I buy arepas, eggs, rice, and avocados.",tts:"Compro arepas, huevos, arroz y aguacates."},
     {es:"La señora me dice el precio y yo pago con tarjeta.",en:"The woman tells me the price and I pay by card.",tts:"La señora me dice el precio y yo pago con tarjeta."},
     {es:"Después vuelvo a casa con las bolsas.",en:"Afterward I return home with the bags.",tts:"Después vuelvo a casa con las bolsas."}
   ],questions:[{q:"¿Qué compra la persona?",choices:["Comida","Ropa","Un carro"],answer:"Comida"}]},
   {id:"lectura-taxi",level:"A1",title:"Un taxi en Bogotá",lesson:"calle",intro:"Practice directions and polite requests.",lines:[
     {es:"Salgo del hotel y busco un taxi.",en:"I leave the hotel and look for a taxi.",tts:"Salgo del hotel y busco un taxi."},
     {es:"Buenas, ¿me lleva al aeropuerto, por favor?",en:"Hi, can you take me to the airport, please?",tts:"Buenas, ¿me lleva al aeropuerto, por favor?"},
     {es:"Claro. Siga derecho y luego gire a la izquierda.",en:"Of course. Go straight and then turn left.",tts:"Claro. Siga derecho y luego gire a la izquierda."},
     {es:"Hay un poco de trancón, pero llegamos a tiempo.",en:"There is a little traffic, but we will arrive on time.",tts:"Hay un poco de trancón, pero llegamos a tiempo."}
   ],questions:[{q:"¿A dónde va la persona?",choices:["Al aeropuerto","Al mercado","A la oficina"],answer:"Al aeropuerto"}]},
   {id:"lectura-trabajo",level:"A1",title:"Un día de trabajo",lesson:"trabajo",intro:"Present tense plus everyday speaking patterns.",lines:[
     {es:"Trabajo en una oficina y llego a las ocho.",en:"I work in an office and arrive at eight.",tts:"Trabajo en una oficina y llego a las ocho."},
     {es:"Tengo que terminar un proyecto antes del almuerzo.",en:"I have to finish a project before lunch.",tts:"Tengo que terminar un proyecto antes del almuerzo."},
     {es:"A las diez tengo una reunión con mi jefe.",en:"At ten I have a meeting with my boss.",tts:"A las diez tengo una reunión con mi jefe."},
     {es:"Después de trabajar, voy a descansar en casa.",en:"After working, I am going to rest at home.",tts:"Después de trabajar, voy a descansar en casa."}
   ],questions:[{q:"¿Qué tiene la persona a las diez?",choices:["Una reunión","Un taxi","Una clase"],answer:"Una reunión"}]},
   {id:"lectura-ayer",level:"A2",title:"Lo que hice ayer",lesson:"gram-pasado-historia",intro:"Tell a short story with past-tense verbs.",lines:[
     {es:"Ayer fui al centro porque necesitaba comprar un regalo.",en:"Yesterday I went downtown because I needed to buy a gift.",tts:"Ayer fui al centro porque necesitaba comprar un regalo."},
     {es:"Había mucho trancón, así que llegué un poco tarde.",en:"There was a lot of traffic, so I arrived a little late.",tts:"Había mucho trancón, así que llegué un poco tarde."},
     {es:"Compré el regalo y después tomé un tinto.",en:"I bought the gift and afterward had a black coffee.",tts:"Compré el regalo y después tomé un tinto."},
     {es:"Al final regresé a casa y descansé.",en:"In the end I returned home and rested.",tts:"Al final regresé a casa y descansé."}
   ],questions:[{q:"¿Por qué fue al centro?",choices:["Para comprar un regalo","Para trabajar","Para tomar un taxi"],answer:"Para comprar un regalo"}]},
   {id:"lectura-planes",level:"A2",title:"Planes para el sábado",lesson:"planes",intro:"Use future plans and natural Colombian responses.",lines:[
     {es:"El viernes le escribo a mi amigo para hacer planes.",en:"On Friday I text my friend to make plans.",tts:"El viernes le escribo a mi amigo para hacer planes."},
     {es:"¿Qué vas a hacer el sábado?",en:"What are you going to do Saturday?",tts:"¿Qué vas a hacer el sábado?"},
     {es:"Voy a visitar a mi familia, pero podemos vernos en la tarde.",en:"I am going to visit my family, but we can meet in the afternoon.",tts:"Voy a visitar a mi familia, pero podemos vernos en la tarde."},
     {es:"De una. Te aviso la hora después.",en:"I'm in. I will let you know the time later.",tts:"De una. Te aviso la hora después."}
   ],questions:[{q:"¿Cuándo pueden verse?",choices:["En la tarde","En la mañana","La próxima semana"],answer:"En la tarde"}]}
 ];

READINGS.push(
  {id:"lectura-uber",level:"A1",title:"Una recogida en Uber",lesson:"uber-ride",intro:"Read a short pickup conversation and notice repair phrases.",lines:[
    {es:"Buenas, ¿usted es mi conductor?",en:"Hi, are you my driver?",tts:"Buenas, ¿usted es mi conductor?"},{es:"Sí, soy yo. Estoy en un carro gris.",en:"Yes, that's me. I am in a gray car.",tts:"Sí, soy yo. Estoy en un carro gris."},{es:"Hablo poquito español, pero voy para este hotel.",en:"I speak a little Spanish, but I am going to this hotel.",tts:"Hablo poquito español, pero voy para este hotel."},{es:"¿Puede hablar más despacio, por favor?",en:"Can you speak more slowly, please?",tts:"¿Puede hablar más despacio, por favor?"}
  ],questions:[{q:"¿Adónde va la persona?",choices:["A un hotel","A una farmacia","A una oficina"],answer:"A un hotel"}]},
  {id:"lectura-hotel",level:"A1",title:"Llegar al hotel",lesson:"hotel-checkin",intro:"Practice a simple check-in and location question.",lines:[
    {es:"Tengo una reserva a nombre de Seth.",en:"I have a reservation under Seth's name.",tts:"Tengo una reserva a nombre de Seth."},{es:"Claro, ¿me puede mostrar el pasaporte?",en:"Of course, can you show me your passport?",tts:"Claro, ¿me puede mostrar el pasaporte?"},{es:"Aquí tiene. ¿A qué hora es el desayuno?",en:"Here you go. What time is breakfast?",tts:"Aquí tiene. ¿A qué hora es el desayuno?"},{es:"El desayuno es en el primer piso, al lado del ascensor.",en:"Breakfast is on the first floor, next to the elevator.",tts:"El desayuno es en el primer piso, al lado del ascensor."}
  ],questions:[{q:"¿Dónde está el desayuno?",choices:["En el primer piso","En el carro","Detrás del hospital"],answer:"En el primer piso"}]},
  {id:"lectura-telefono",level:"A2",title:"Una llamada con mala señal",lesson:"daily-repair",intro:"Notice how speakers repair a broken phone call.",lines:[
    {es:"¿Aló? ¿Me escuchas?",en:"Hello? Can you hear me?",tts:"¿Aló? ¿Me escuchas?"},{es:"Te escucho, pero la señal está mala.",en:"I can hear you, but the signal is bad.",tts:"Te escucho, pero la señal está mala."},{es:"Se está cortando la llamada, así que te escribo.",en:"The call is cutting out, so I will text you.",tts:"Se está cortando la llamada, así que te escribo."},{es:"Listo, hablamos más tarde.",en:"Okay, we will talk later.",tts:"Listo, hablamos más tarde."}
  ],questions:[{q:"¿Qué problema tienen?",choices:["Mala señal","No tienen comida","Perdieron el carro"],answer:"Mala señal"}]},
  {id:"lectura-edificio",level:"A1",title:"El edificio de allá",lesson:"direcciones",intro:"Practice front, behind, entrance, and floor directions.",lines:[
    {es:"Disculpe, ¿dónde está la entrada?",en:"Excuse me, where is the entrance?",tts:"Disculpe, ¿dónde está la entrada?"},{es:"Es el edificio de allá, al frente.",en:"It is that building over there, across the way.",tts:"Es el edificio de allá, al frente."},{es:"Siga derecho hasta la esquina y gire a la derecha.",en:"Go straight to the corner and turn right.",tts:"Siga derecho hasta la esquina y gire a la derecha."},{es:"Después suba al segundo piso.",en:"Then go up to the second floor.",tts:"Después suba al segundo piso."}
  ],questions:[{q:"¿A qué piso debe subir?",choices:["Al segundo piso","Al primer piso","Al sótano"],answer:"Al segundo piso"}]}
);
READINGS.push(
  {id:"lectura-historia-contraste",level:"A2",title:"Una tarde con lluvia",lesson:"gram-pasado-contraste",intro:"Notice the difference between the background and the completed events. Read once for meaning, then shadow each line.",lines:[
    {es:"Cuando era niño, vivía cerca de un parque.",en:"When I was a child, I lived near a park.",tts:"Cuando era niño, vivía cerca de un parque."},
    {es:"Ayer fui al mismo parque porque quería caminar.",en:"Yesterday I went to the same park because I wanted to walk.",tts:"Ayer fui al mismo parque porque quería caminar."},
    {es:"Estaba lloviendo cuando llegué, pero no me devolví.",en:"It was raining when I arrived, but I did not turn back.",tts:"Estaba lloviendo cuando llegué, pero no me devolví."},
    {es:"Esperé diez minutos y después regresé a casa.",en:"I waited ten minutes and then returned home.",tts:"Esperé diez minutos y después regresé a casa."}
  ],questions:[{q:"¿Qué estaba pasando cuando llegó?",choices:["Estaba lloviendo","Estaba trabajando","Estaba cocinando"],answer:"Estaba lloviendo"},{q:"¿Qué hizo después?",choices:["Regresó a casa","Compró un carro","Llamó al médico"],answer:"Regresó a casa"}]},
  {id:"lectura-pronombres-ubicacion",level:"A2",title:"La dirección y el mensaje",lesson:"gram-pronombres",intro:"Listen for lo, la, le, and se lo. Try to say each line before hearing it.",lines:[
    {es:"¿Tienes la dirección del edificio?",en:"Do you have the building's address?",tts:"¿Tienes la dirección del edificio?"},
    {es:"Sí, la tengo aquí, pero no sé cómo llegar.",en:"Yes, I have it here, but I do not know how to get there.",tts:"Sí, la tengo aquí, pero no sé cómo llegar."},
    {es:"Mándamela por mensaje y se la muestro al conductor.",en:"Send it to me by message and I will show it to the driver.",tts:"Mándamela por mensaje y se la muestro al conductor."},
    {es:"Listo, ya te la mandé.",en:"Okay, I already sent it to you.",tts:"Listo, ya te la mandé."}
  ],questions:[{q:"¿Qué va a mostrarle al conductor?",choices:["La dirección","La habitación","La comida"],answer:"La dirección"}]}
);

// ── Grammar data ──────────────────────────────────────────────────────────────
const GRAMMAR={
  presente:{intro:"The present tense describes habits, facts, and current actions. 3 verb types: AR, ER, IR.",trick:"The -O ending always means 'I'. Yo habl-O = I speak. Yo com-O = I eat. Yo viv-O = I live. Learn -O and you can talk about yourself instantly!",
    tables:[{title:"AR Verbs — Hablar",sub:"Drop -AR, add: -o, -as, -a, -amos, -an",rows:[{pro:"Yo",verb:"hablo",en:"I speak",tts:"yo hablo"},{pro:"Tú",verb:"hablas",en:"you speak",tts:"tú hablas"},{pro:"Él/Ella/Ud.",verb:"habla",en:"he/she speaks",tts:"él habla"},{pro:"Nosotros",verb:"hablamos",en:"we speak",tts:"nosotros hablamos"},{pro:"Ellos/Uds.",verb:"hablan",en:"they speak",tts:"ellos hablan"}]},{title:"ER Verbs — Comer",sub:"Drop -ER, add: -o, -es, -e, -emos, -en",rows:[{pro:"Yo",verb:"como",en:"I eat",tts:"yo como"},{pro:"Tú",verb:"comes",en:"you eat",tts:"tú comes"},{pro:"Él/Ella/Ud.",verb:"come",en:"he/she eats",tts:"él come"},{pro:"Nosotros",verb:"comemos",en:"we eat",tts:"nosotros comemos"},{pro:"Ellos/Uds.",verb:"comen",en:"they eat",tts:"ellos comen"}]},{title:"IR Verbs — Vivir",sub:"Drop -IR, add: -o, -es, -e, -imos, -en",rows:[{pro:"Yo",verb:"vivo",en:"I live",tts:"yo vivo"},{pro:"Tú",verb:"vives",en:"you live",tts:"tú vives"},{pro:"Él/Ella/Ud.",verb:"vive",en:"he/she lives",tts:"él vive"},{pro:"Nosotros",verb:"vivimos",en:"we live",tts:"nosotros vivimos"},{pro:"Ellos/Uds.",verb:"viven",en:"they live",tts:"ellos viven"}]}],
    examples:[{es:"Yo hablo un poco de español.",en:"I speak a little Spanish.",tts:"Yo hablo un poco de español."},{es:"¿Dónde vives tú?",en:"Where do you live?",tts:"¿Dónde vives tú?"},{es:"Ella come arepa todos los días.",en:"She eats arepa every day.",tts:"Ella come arepa todos los días."}]},
  pasado:{intro:"The simple past (Pretérito Indefinido) is used for completed actions. 'I spoke', 'I ate', 'I went'. Accents on the endings are the key signal.",trick:"Look for the accent at the END of a verb — it signals past tense! hablÉ = I spoke, comIÓ = he ate, fuÉ = I was/went. Spot the tilde = something HAPPENED!",
    tables:[{title:"AR Verbs — Hablar",sub:"Past endings: -é, -aste, -ó, -amos, -aron",rows:[{pro:"Yo",verb:"hablé",en:"I spoke",tts:"yo hablé"},{pro:"Tú",verb:"hablaste",en:"you spoke",tts:"tú hablaste"},{pro:"Él/Ella/Ud.",verb:"habló",en:"he/she spoke",tts:"él habló"},{pro:"Nosotros",verb:"hablamos",en:"we spoke",tts:"nosotros hablamos"},{pro:"Ellos/Uds.",verb:"hablaron",en:"they spoke",tts:"ellos hablaron"}]},{title:"ER/IR Verbs — Comer",sub:"Past endings: -í, -iste, -ió, -imos, -ieron",rows:[{pro:"Yo",verb:"comí",en:"I ate",tts:"yo comí"},{pro:"Tú",verb:"comiste",en:"you ate",tts:"tú comiste"},{pro:"Él/Ella/Ud.",verb:"comió",en:"he/she ate",tts:"él comió"},{pro:"Nosotros",verb:"comimos",en:"we ate",tts:"nosotros comimos"},{pro:"Ellos/Uds.",verb:"comieron",en:"they ate",tts:"ellos comieron"}]},{title:"⚡ Ser & Ir — IDENTICAL past tense!",sub:"Both mean 'was' AND 'went' — context tells you which",rows:[{pro:"Yo",verb:"fui",en:"I was / I went",tts:"yo fui"},{pro:"Tú",verb:"fuiste",en:"you were / went",tts:"tú fuiste"},{pro:"Él/Ella/Ud.",verb:"fue",en:"he was / he went",tts:"él fue"},{pro:"Nosotros",verb:"fuimos",en:"we were / went",tts:"nosotros fuimos"},{pro:"Ellos/Uds.",verb:"fueron",en:"they were / went",tts:"ellos fueron"}]}],
    examples:[{es:"Ayer hablé con mi amigo.",en:"Yesterday I spoke with my friend.",tts:"Ayer hablé con mi amigo."},{es:"¿Qué comiste anoche?",en:"What did you eat last night?",tts:"¿Qué comiste anoche?"},{es:"Fui al mercado esta mañana.",en:"I went to the market this morning.",tts:"Fui al mercado esta mañana."}]},
  futuro:{intro:"Great news — the future is the EASIEST tense! Keep the full infinitive and add endings. Or use the even simpler 'voy a' (going to) form.",trick:"Near future = VOY A + any verb. Exactly like English 'going to'. Voy a comer = I'm going to eat. Start with this — you can use it for months before needing the full future tense!",
    tables:[{title:"Simple Future — Any Verb",sub:"Keep full infinitive + add: -é, -ás, -á, -emos, -án",rows:[{pro:"Yo",verb:"-é  (hablaré)",en:"I will speak",tts:"yo hablaré"},{pro:"Tú",verb:"-ás  (hablarás)",en:"you will speak",tts:"tú hablarás"},{pro:"Él/Ella/Ud.",verb:"-á  (hablará)",en:"he/she will speak",tts:"él hablará"},{pro:"Nosotros",verb:"-emos  (hablaremos)",en:"we will speak",tts:"nosotros hablaremos"},{pro:"Ellos/Uds.",verb:"-án  (hablarán)",en:"they will speak",tts:"ellos hablarán"}]},{title:"Ir a + Infinitive — Near Future",sub:"The easy way: voy/vas/va/vamos/van + a + verb",rows:[{pro:"Yo",verb:"voy a comer",en:"I'm going to eat",tts:"voy a comer"},{pro:"Tú",verb:"vas a comer",en:"you're going to eat",tts:"vas a comer"},{pro:"Él/Ella/Ud.",verb:"va a comer",en:"he's going to eat",tts:"va a comer"},{pro:"Nosotros",verb:"vamos a comer",en:"we're going to eat",tts:"vamos a comer"},{pro:"Ellos/Uds.",verb:"van a comer",en:"they're going to eat",tts:"van a comer"}]}],
    examples:[{es:"Mañana voy a ir al mercado.",en:"Tomorrow I'm going to go to the market.",tts:"Mañana voy a ir al mercado."},{es:"¿Vas a comer arepa?",en:"Are you going to eat arepa?",tts:"¿Vas a comer arepa?"},{es:"Va a llover esta tarde.",en:"It's going to rain this afternoon.",tts:"Va a llover esta tarde."}]},
  "pasado-contraste":{intro:"Spanish uses two past viewpoints: the preterite tells the completed event; the imperfect paints the background, habit, or action in progress.",trick:"Preterite moves the story forward: Ayer fui al mercado. Imperfect sets the scene: Cuando era niño, vivía en Cali.",tables:[{title:"The contrast",sub:"Completed event vs. background or repeated action",rows:[{pro:"Evento",verb:"Ayer fui al mercado.",en:"Yesterday I went to the market.",tts:"Ayer fui al mercado."},{pro:"Contexto",verb:"Cuando era niño, vivía en Cali.",en:"When I was a child, I used to live in Cali.",tts:"Cuando era niño, vivía en Cali."},{pro:"En progreso",verb:"Mientras cocinaba, me llamaste.",en:"While I was cooking, you called me.",tts:"Mientras cocinaba, me llamaste."}]}],examples:[{es:"Ayer fui al mercado, pero estaba cerrado.",en:"Yesterday I went to the market, but it was closed.",tts:"Ayer fui al mercado, pero estaba cerrado."},{es:"Cuando era niño, iba al parque todos los días.",en:"When I was a child, I used to go to the park every day.",tts:"Cuando era niño, iba al parque todos los días."},{es:"Mientras trabajaba, sonó el teléfono.",en:"While I was working, the phone rang.",tts:"Mientras trabajaba, sonó el teléfono."}]},
  subjuntivo:{intro:"The subjunctive is useful after a wish, hope, request, emotion, or recommendation when another person is doing the action.",trick:"Learn it as a speaking chunk: trigger + que + new subject + subjunctive. Quiero que vengas. Espero que estés bien.",tables:[{title:"Useful conversation triggers",sub:"Memorize the whole chunk",rows:[{pro:"Quiero que",verb:"vengas",en:"I want you to come",tts:"Quiero que vengas mañana."},{pro:"Espero que",verb:"estés",en:"I hope you are well",tts:"Espero que estés bien."},{pro:"Es importante que",verb:"hables",en:"It is important that you speak",tts:"Es importante que hables despacio."}]}],examples:[{es:"Quiero que vengas mañana.",en:"I want you to come tomorrow.",tts:"Quiero que vengas mañana."},{es:"Espero que estés bien.",en:"I hope you are well.",tts:"Espero que estés bien."},{es:"Es importante que practiques todos los días.",en:"It is important that you practice every day.",tts:"Es importante que practiques todos los días."}]},
  trucos:[{main:"V = B in Colombian Spanish",sub:"Never stress about V vs B. Vaca = 'baca'. Vo = 'bo'. Identical sounds in Colombia. ✓",icon:"🎯"},{main:"Accents at end = Past tense",sub:"Hablé = I spoke. Comió = he ate. Fue = he was/went. If you see an accent at the END of a verb, something HAPPENED.",icon:"⏮️"},{main:"Voy a = 'Going to'",sub:"The simplest future: Voy a + verb. Voy a comer = I'm going to eat. Start with this for months.",icon:"⏭️"},{main:"Ser vs Estar (both = 'to be')",sub:"Ser = permanent: Soy alto. Estar = temporary: Estoy cansado. Will it change? Yes → Estar. No → Ser.",icon:"⭐"},{main:"Fui = was AND went",sub:"Ser and Ir are IDENTICAL in past tense! Fui = I was (ser) OR I went (ir). Context tells you which.",icon:"🤯"},{main:"-O ending always means 'I'",sub:"Any present verb ending -O = I do it. Hablo = I speak. Como = I eat. Tengo = I have.",icon:"👤"},{main:"H is always silent",sub:"Hola, huevo, hacer, hotel — H is NEVER pronounced in Spanish. Just ignore it.",icon:"🤫"},{main:"The tilde changes meaning",sub:"Sí = Yes. Si = If. Él = He. El = The. Más = More. Mas = But. That little accent changes everything.",icon:"✍️"},{main:"Colombia = no 'vosotros'",sub:"Spain uses 'vosotros' for 'you all'. Colombia just uses 'ustedes' for everyone. One less thing to learn!",icon:"🇨🇴"},{main:"Gerunds end in -ando/-iendo",sub:"Habl-ANDO = speaking. Com-IENDO = eating. Viv-IENDO = living. Use these with estar: Estoy hablando = I am speaking.",icon:"🔄"}],
};

/* v58: the next tense layer, taught as useful speaking patterns first. */
Object.assign(GRAMMAR,{
  perfecto:{label:"Present perfect",intro:"Use he/has/ha + participle for experiences or actions connected to now. It is useful for talking about what you have done during a trip or today.",trick:"Keep the helper verb short: he, has, ha, hemos, han + -ado/-ido. He comido = I have eaten.",tables:[{title:"Haber + participle",sub:"he / has / ha / hemos / han + -ado or -ido",rows:[{pro:"Yo",verb:"he hablado",en:"I have spoken",tts:"yo he hablado"},{pro:"Tú",verb:"has comido",en:"you have eaten",tts:"tú has comido"},{pro:"Él/Ella/Ud.",verb:"ha ido",en:"he/she has gone",tts:"él ha ido"},{pro:"Nosotros",verb:"hemos visto",en:"we have seen",tts:"nosotros hemos visto"},{pro:"Ellos/Uds.",verb:"han llegado",en:"they have arrived",tts:"ellos han llegado"}]}],examples:[{es:"He practicado español esta semana.",en:"I have practiced Spanish this week.",tts:"He practicado español esta semana."},{es:"¿Has probado la arepa?",en:"Have you tried arepa?",tts:"¿Has probado la arepa?"},{es:"Ya hemos llegado al hotel.",en:"We have already arrived at the hotel.",tts:"Ya hemos llegado al hotel."}]},
  condicional:{label:"Conditional",intro:"Use the conditional for polite requests, possibilities, and imagined situations. These forms are especially useful for sounding natural and respectful.",trick:"Keep the infinitive and add: -ía, -ías, -ía, -íamos, -ían. Me gustaría and podría are high-value chunks.",tables:[{title:"Useful conditional forms",sub:"infinitive + -ía endings",rows:[{pro:"Yo",verb:"me gustaría",en:"I would like",tts:"me gustaría"},{pro:"Tú",verb:"podrías",en:"you could",tts:"tú podrías"},{pro:"Él/Ella/Ud.",verb:"debería",en:"he/she should",tts:"él debería"},{pro:"Nosotros",verb:"iríamos",en:"we would go",tts:"nosotros iríamos"},{pro:"Ellos/Uds.",verb:"tendrían",en:"they would have",tts:"ellos tendrían"}]}],examples:[{es:"Me gustaría pedir una mesa.",en:"I would like to order a table.",tts:"Me gustaría pedir una mesa."},{es:"¿Podría repetir, por favor?",en:"Could you repeat, please?",tts:"¿Podría repetir, por favor?"},{es:"Deberíamos salir temprano.",en:"We should leave early.",tts:"Deberíamos salir temprano."}]},
  "pasado-perfecto":{label:"Past perfect",intro:"Use había + participle for something that had already happened before another past event. Learn it after the preterite and imperfect contrast.",trick:"Put the earlier event in the background with había: Cuando llegué, ya había salido.",tables:[{title:"Había + participle",sub:"había / habías / había / habíamos / habían + -ado or -ido",rows:[{pro:"Yo",verb:"había hablado",en:"I had spoken",tts:"yo había hablado"},{pro:"Tú",verb:"habías comido",en:"you had eaten",tts:"tú habías comido"},{pro:"Él/Ella/Ud.",verb:"había salido",en:"he/she had left",tts:"él había salido"},{pro:"Nosotros",verb:"habíamos visto",en:"we had seen",tts:"nosotros habíamos visto"},{pro:"Ellos/Uds.",verb:"habían llegado",en:"they had arrived",tts:"ellos habían llegado"}]}],examples:[{es:"Cuando llegué, ya habían cerrado.",en:"When I arrived, they had already closed.",tts:"Cuando llegué, ya habían cerrado."},{es:"Nunca había usado esa aplicación.",en:"I had never used that app.",tts:"Nunca había usado esa aplicación."},{es:"Ya había comido cuando me llamaste.",en:"I had already eaten when you called me.",tts:"Ya había comido cuando me llamaste."}]},
  "futuro-perfecto":{label:"Future perfect",intro:"Use habré + participle for something that will have happened by a future point. This is advanced; recognize it before trying to produce it quickly.",trick:"Think: by then, I will have… Habré llegado = I will have arrived.",tables:[{title:"Habré + participle",sub:"habré / habrás / habrá / habremos / habrán + -ado or -ido",rows:[{pro:"Yo",verb:"habré llegado",en:"I will have arrived",tts:"yo habré llegado"},{pro:"Tú",verb:"habrás terminado",en:"you will have finished",tts:"tú habrás terminado"},{pro:"Él/Ella/Ud.",verb:"habrá salido",en:"he/she will have left",tts:"él habrá salido"},{pro:"Nosotros",verb:"habremos comido",en:"we will have eaten",tts:"nosotros habremos comido"},{pro:"Ellos/Uds.",verb:"habrán llegado",en:"they will have arrived",tts:"ellos habrán llegado"}]}],examples:[{es:"Para las ocho, habré terminado.",en:"By eight, I will have finished.",tts:"Para las ocho, habré terminado."},{es:"Cuando llegues, ya habremos salido.",en:"When you arrive, we will have already left.",tts:"Cuando llegues, ya habremos salido."},{es:"En un año, habré aprendido mucho.",en:"In a year, I will have learned a lot.",tts:"En un año, habré aprendido mucho."}]}
});

const V58_SPEAKING_GUIDE=[
  {id:"perfecto",title:"Present perfect for recent experience",formula:"he / has / ha + participle",explain:"Use this for experiences or actions connected to now. In daily speech, learn it as a complete chunk instead of memorizing every rule first.",examples:[{es:"He practicado esta semana.",en:"I have practiced this week.",tts:"He practicado esta semana."},{es:"¿Has probado la arepa?",en:"Have you tried arepa?",tts:"¿Has probado la arepa?"}],mistake:"Do not use the English word 'have' by itself. Spanish needs the correct form of haber: he, has, ha, hemos, han.",exercise:"Say one thing you have done today and ask someone ¿Has...?"},
  {id:"condicional",title:"Polite requests and possibilities",formula:"infinitive + -ía",explain:"The conditional helps you ask politely and talk about possibilities. Me gustaría and podría are more useful at first than a full table.",examples:[{es:"Me gustaría pedir una mesa.",en:"I would like to order a table.",tts:"Me gustaría pedir una mesa."},{es:"¿Podría repetir, por favor?",en:"Could you repeat, please?",tts:"¿Podría repetir, por favor?"}],mistake:"Keep the infinitive before the ending: gustaría, podría, debería. Do not remove the whole verb stem.",exercise:"Make one polite request with Me gustaría and one with ¿Podría...?"},
  {id:"pasado-perfecto",title:"Had already happened",formula:"había + participle",explain:"Use this to place an earlier action before another past event. It is useful for telling clearer stories, but it comes after the basic past contrast.",examples:[{es:"Cuando llegué, ya habían cerrado.",en:"When I arrived, they had already closed.",tts:"Cuando llegué, ya habían cerrado."},{es:"Ya había comido cuando me llamaste.",en:"I had already eaten when you called me.",tts:"Ya había comido cuando me llamaste."}],mistake:"Do not use this for every past sentence. Use it only when one past action happened before another.",exercise:"Tell what had already happened before you arrived somewhere."},
  {id:"futuro-perfecto",title:"Will have happened",formula:"habré + participle",explain:"This is an advanced recognition pattern. Learn to understand it first; you can produce it later when the simpler future forms feel automatic.",examples:[{es:"Para las ocho, habré terminado.",en:"By eight, I will have finished.",tts:"Para las ocho, habré terminado."},{es:"En un año, habré aprendido mucho.",en:"In a year, I will have learned a lot.",tts:"En un año, habré aprendido mucho."}],mistake:"Do not confuse habré with the simple future of the main verb. Habré terminado means I will have finished.",exercise:"Recognize one future-perfect sentence and explain what will be completed by then."}
];

// Pronouns data
const PRONOMBRES={
  directo:{title:"Objeto Directo (Direct Object)",sub:"Replaces the thing receiving the action directly",color:"#60a5fa",rows:[
    {w:"lo",meaning:"him / it (m.)",example:"Lo veo. — I see him/it.",tts:"lo veo"},
    {w:"la",meaning:"her / it (f.)",example:"La veo. — I see her/it.",tts:"la veo"},
    {w:"los",meaning:"them (m./mixed)",example:"Los compro. — I'm buying them.",tts:"los compro"},
    {w:"las",meaning:"them (f.)",example:"Las tengo. — I have them.",tts:"las tengo"},
    {w:"me",meaning:"me (first person)",example:"Me llaman. — They call me.",tts:"me llaman"},
    {w:"te",meaning:"you (second person)",example:"Te veo mañana. — I'll see you tomorrow.",tts:"te veo mañana"},
    {w:"nos",meaning:"us",example:"Nos llaman. — They call us.",tts:"nos llaman"},
  ]},
  indirecto:{title:"Objeto Indirecto (Indirect Object)",sub:"Replaces the person TO WHOM something is done",color:"#a78bfa",rows:[
    {w:"le",meaning:"to him / to her / to you (formal)",example:"Le doy el libro. — I give him/her the book.",tts:"le doy el libro"},
    {w:"me",meaning:"to me",example:"Me da el dinero. — He gives me the money.",tts:"me da el dinero"},
    {w:"te",meaning:"to you",example:"Te mando un mensaje. — I'm sending you a message.",tts:"te mando un mensaje"},
    {w:"nos",meaning:"to us",example:"Nos explica todo. — He explains everything to us.",tts:"nos explica todo"},
    {w:"les",meaning:"to them / to you all",example:"Les digo la verdad. — I tell them the truth.",tts:"les digo la verdad"},
  ]},
  trick:"In Colombian Spanish: 'Le' is used for the indirect object (to him/her). 'Lo/La' for the direct object (him/her/it). Unlike Spain, Colombians do NOT use 'le' for the direct object — they always say 'lo veo' (I see him), never 'le veo'.",
  examples:[
    {es:"¿Lo ves? — Sí, lo veo.",en:"Do you see it/him? — Yes, I see it/him.",tts:"¿Lo ves? Sí, lo veo."},
    {es:"Le di el dinero a Juan.",en:"I gave Juan the money. (to Juan = le)",tts:"Le di el dinero a Juan."},
    {es:"Te quiero mucho.",en:"I love you a lot.",tts:"Te quiero mucho."},
    {es:"¿Me puede ayudar?",en:"Can you help me?",tts:"¿Me puede ayudar?"},
    {es:"La compré en el mercado.",en:"I bought it (f.) at the market.",tts:"La compré en el mercado."},
    {es:"Nos llaman mañana.",en:"They're calling us tomorrow.",tts:"Nos llaman mañana."},
  ],
};

// Reflexive verbs
const REFLEXIVOS=[
  {inf:"llamarse",en:"to be called (name)",forms:[{p:"Yo",v:"me llamo",e:"I am called / my name is"},{p:"Tú",v:"te llamas",e:"you are called"},{p:"Él/Ella/Ud.",v:"se llama",e:"he/she is called"},{p:"Nosotros",v:"nos llamamos",e:"we are called"},{p:"Ellos/Uds.",v:"se llaman",e:"they are called"}],example:{es:"Me llamo David. ¿Cómo te llamas?",en:"My name is David. What's your name?"}},
  {inf:"levantarse",en:"to get up / to stand up",forms:[{p:"Yo",v:"me levanto",e:"I get up"},{p:"Tú",v:"te levantas",e:"you get up"},{p:"Él/Ella/Ud.",v:"se levanta",e:"he/she gets up"},{p:"Nosotros",v:"nos levantamos",e:"we get up"},{p:"Ellos/Uds.",v:"se levantan",e:"they get up"}],example:{es:"Me levanto a las seis.",en:"I get up at six o'clock."}},
  {inf:"sentarse",en:"to sit down",forms:[{p:"Yo",v:"me siento",e:"I sit down"},{p:"Tú",v:"te sientas",e:"you sit down"},{p:"Él/Ella/Ud.",v:"se sienta",e:"he/she sits down"},{p:"Nosotros",v:"nos sentamos",e:"we sit down"},{p:"Ellos/Uds.",v:"se sientan",e:"they sit down"}],example:{es:"¿Puedo sentarme aquí?",en:"Can I sit here?"}},
  {inf:"irse",en:"to leave / to go away",forms:[{p:"Yo",v:"me voy",e:"I'm leaving"},{p:"Tú",v:"te vas",e:"you're leaving"},{p:"Él/Ella/Ud.",v:"se va",e:"he/she is leaving"},{p:"Nosotros",v:"nos vamos",e:"we're leaving"},{p:"Ellos/Uds.",v:"se van",e:"they're leaving"}],example:{es:"¡Me voy! Hasta mañana.",en:"I'm leaving! See you tomorrow."}},
  {inf:"sentirse",en:"to feel (emotion/physical)",forms:[{p:"Yo",v:"me siento",e:"I feel"},{p:"Tú",v:"te sientes",e:"you feel"},{p:"Él/Ella/Ud.",v:"se siente",e:"he/she feels"},{p:"Nosotros",v:"nos sentimos",e:"we feel"},{p:"Ellos/Uds.",v:"se sienten",e:"they feel"}],example:{es:"Me siento muy bien hoy.",en:"I feel very well today."}},
  {inf:"despertarse",en:"to wake up",forms:[{p:"Yo",v:"me despierto",e:"I wake up"},{p:"Tú",v:"te despiertas",e:"you wake up"},{p:"Él/Ella/Ud.",v:"se despierta",e:"he/she wakes up"},{p:"Nosotros",v:"nos despertamos",e:"we wake up"},{p:"Ellos/Uds.",v:"se despiertan",e:"they wake up"}],example:{es:"Me despierto temprano en Colombia.",en:"I wake up early in Colombia."}},
];


/* v36: simple explanations for turning words into sentences.  These are
   rendered in Gramática and their examples are added to the quiz pool. */
const SPEAKING_GUIDE=[
  {id:"estructura",title:"Subject + verb + object",formula:"Subject + verb + object",explain:"Spanish can use the same basic order as English, but the subject is often optional.",examples:[{es:"Yo necesito ayuda.",en:"I need help.",tts:"Yo necesito ayuda."},{es:"Necesito ayuda.",en:"I need help. (the subject is understood)",tts:"Necesito ayuda."}],mistake:"Do not force Yo into every sentence; the verb ending often already tells us who is speaking.",exercise:"Say three sentences beginning with Necesito, Quiero, and Puedo."},
  {id:"sujeto-omitido",title:"Why Spanish omits the subject",formula:"Hablo = I speak · Hablas = you speak",explain:"Verb endings carry information. Native speakers add yo, tú, or él when they want emphasis or clarity.",examples:[{es:"Vivo en Bogotá.",en:"I live in Bogotá.",tts:"Vivo en Bogotá."},{es:"Yo vivo en Bogotá, pero ella vive en Cali.",en:"I live in Bogotá, but she lives in Cali.",tts:"Yo vivo en Bogotá, pero ella vive en Cali."}],mistake:"English needs the subject more often; Spanish does not.",exercise:"Answer ¿Dónde vives? with Vivo en... instead of Yo vivo..."},
  {id:"presente",title:"Present-tense endings",formula:"AR: -o, -as, -a · ER/IR: -o, -es, -e",explain:"Remove -ar, -er, or -ir and add the ending that matches the person. Start with the useful yo -o ending.",examples:[{es:"Hablo un poco de español.",en:"I speak a little Spanish.",tts:"Hablo un poco de español."},{es:"¿Qué haces hoy?",en:"What are you doing today?",tts:"¿Qué haces hoy?"}],mistake:"The infinitive is not the sentence: quiero hablar, but yo hablo.",exercise:"Say what you do today with Trabajo, Vivo, Tengo, and Quiero."},
  {id:"futuro",title:"Near future with voy a",formula:"Voy / vas / va / vamos / van + a + infinitive",explain:"This is the easiest everyday future. Keep the second verb in its infinitive form.",examples:[{es:"Voy a practicar esta noche.",en:"I am going to practice tonight.",tts:"Voy a practicar esta noche."},{es:"¿Qué vas a hacer mañana?",en:"What are you going to do tomorrow?",tts:"¿Qué vas a hacer mañana?"}],mistake:"Do not conjugate the second verb: voy a hablar, not voy a hablo.",exercise:"Say three plans beginning with Voy a..."},
  {id:"pasado",title:"Completed past actions",formula:"Ayer + completed verb",explain:"Use the past to tell what happened. Common first-person endings are -é for AR verbs and -í for ER/IR verbs; memorize high-frequency irregulars like fui, hice, and tuve.",examples:[{es:"Ayer fui al mercado.",en:"Yesterday I went to the market.",tts:"Ayer fui al mercado."},{es:"Comí una arepa y tomé un tinto.",en:"I ate an arepa and had a coffee.",tts:"Comí una arepa y tomé un tinto."}],mistake:"Fui means I went or I was; the rest of the sentence gives the context.",exercise:"Tell one short story with Ayer fui..., después..., y al final..."},
  {id:"negativas-preguntas",title:"Negatives and questions",formula:"No + verb · question words + sentence",explain:"Put no directly before the conjugated verb. Questions can keep normal word order; your voice and question marks do the work.",examples:[{es:"No entiendo.",en:"I don't understand.",tts:"No entiendo."},{es:"¿Dónde queda la farmacia?",en:"Where is the pharmacy?",tts:"¿Dónde queda la farmacia?"}],mistake:"Do not add do/does: ¿Hablas español? means Do you speak Spanish?",exercise:"Turn Entiendo un poco into a negative and then ask ¿Entiendes?"},
  {id:"acuerdo",title:"Gender and number agreement",formula:"el/la + noun · adjective matches noun",explain:"Nouns and adjectives often show masculine/feminine and singular/plural. Learn the article with the noun.",examples:[{es:"La dirección correcta.",en:"The correct address.",tts:"La dirección correcta."},{es:"Los edificios altos.",en:"The tall buildings.",tts:"Los edificios altos."}],mistake:"The adjective is not always masculine; follow the noun.",exercise:"Say el edificio alto and la entrada correcta."},
  {id:"ser-estar",title:"Ser vs. estar",formula:"Ser = identity · estar = state/location",explain:"Use ser for identity, origin, and description; use estar for temporary states and location.",examples:[{es:"Soy de Estados Unidos.",en:"I am from the United States.",tts:"Soy de Estados Unidos."},{es:"Estoy cansado y estoy en el hotel.",en:"I am tired and I am at the hotel.",tts:"Estoy cansado y estoy en el hotel."}],mistake:"Location normally uses estar: El hotel está al frente.",exercise:"Say where you are and how you feel with Estoy..."},
  {id:"hay",title:"Hay vs. está / están",formula:"Hay = there is/are · está/están = is/are located",explain:"Use hay to introduce that something exists. Use está or están for the location of a known thing.",examples:[{es:"Hay una farmacia cerca.",en:"There is a pharmacy nearby.",tts:"Hay una farmacia cerca."},{es:"La farmacia está al frente.",en:"The pharmacy is across the way.",tts:"La farmacia está al frente."}],mistake:"Hay does not change for singular or plural.",exercise:"Say There is a hotel and The hotel is behind the building."},
  {id:"gustar",title:"Gustar sentence structure",formula:"Me gusta + singular · Me gustan + plural",explain:"The thing you like is grammatically the subject. Me means to me; gusta agrees with the thing, not with you.",examples:[{es:"Me gusta la música.",en:"I like music.",tts:"Me gusta la música."},{es:"Me gustan las arepas.",en:"I like arepas.",tts:"Me gustan las arepas."}],mistake:"Do not say Yo gusto la música for I like music.",exercise:"Say one thing you like and two things you like."},
  {id:"pronombres",title:"lo, la, le, se lo",formula:"lo/la = thing · le = to someone · se lo = it to someone",explain:"Object pronouns make speech shorter and more natural. Put them before a conjugated verb; with an infinitive they can attach to the end.",examples:[{es:"Lo tengo aquí.",en:"I have it here. (masculine)",tts:"Lo tengo aquí."},{es:"Se lo voy a mandar.",en:"I am going to send it to him/her.",tts:"Se lo voy a mandar."},{es:"Voy a verlo.",en:"I am going to see it.",tts:"Voy a verlo."}],mistake:"The combination le lo changes to se lo: never le lo.",exercise:"Replace el documento in Tengo el documento with lo."},
  {id:"conectores",title:"Connectors make speech flow",formula:"Idea 1 + connector + idea 2",explain:"Use connectors to join short sentences into a natural thought instead of stopping after every phrase.",examples:[{es:"Quería salir, pero tuve que trabajar.",en:"I wanted to go out, but I had to work.",tts:"Quería salir, pero tuve que trabajar."},{es:"Había trancón, así que llegué tarde.",en:"There was traffic, so I arrived late.",tts:"Había trancón, así que llegué tarde."},{es:"Si puedo, te aviso.",en:"If I can, I will let you know.",tts:"Si puedo, te aviso."}],mistake:"si means if; sí means yes. porque means because; ¿por qué? means why.",exercise:"Join two ideas with pero, porque, entonces, and así que."},
  {id:"por-para",title:"Por vs. para",formula:"para = purpose/destination · por = reason/route/exchange",explain:"Use para when you mean for a purpose, a recipient, or a destination. Use por for a reason, a route, an amount of time, or an exchange.",examples:[{es:"Voy para el hotel.",en:"I'm headed to the hotel.",tts:"Voy para el hotel."},{es:"Estudio español para hablar con la gente.",en:"I study Spanish in order to speak with people.",tts:"Estudio español para hablar con la gente."},{es:"Gracias por la ayuda.",en:"Thanks for the help.",tts:"Gracias por la ayuda."}],mistake:"Do not translate every English 'for' the same way. Ask: purpose/destination (para) or reason/route/exchange (por)?",exercise:"Say one destination with para and one reason with por."},
  {id:"ir-venir",title:"Ir, venir, llevar, traer",formula:"ir = go · venir = come · llevar = take/bring there · traer = bring here",explain:"The direction is from the speaker's point of view. Use venir/traer when something moves toward the place or person you are talking about; use ir/llevar when it moves away.",examples:[{es:"Voy para tu casa.",en:"I'm going to your house.",tts:"Voy para tu casa."},{es:"¿Vienes a la reunión?",en:"Are you coming to the meeting?",tts:"¿Vienes a la reunión?"},{es:"Te llevo el documento.",en:"I'll take/bring the document to you there.",tts:"Te llevo el documento."},{es:"Tráeme un tinto, por favor.",en:"Bring me a black coffee, please.",tts:"Tráeme un tinto, por favor."}],mistake:"Choose the verb based on direction, not only on the English word 'bring' or 'take'.",exercise:"Say where you are going, what you are taking, and what someone should bring you."},
  {id:"se-me",title:"Se me... for things that happened to you",formula:"Se me + verb + thing",explain:"This very common pattern presents an event as something that happened to you, often accidentally or unexpectedly. It sounds natural in phrases like Se me olvidó.",examples:[{es:"Se me olvidó la dirección.",en:"I forgot the address.",tts:"Se me olvidó la dirección."},{es:"Se me dañó el celular.",en:"My cell phone broke on me.",tts:"Se me dañó el celular."},{es:"Se me quedó la billetera en el carro.",en:"I left my wallet in the car.",tts:"Se me quedó la billetera en el carro."}],mistake:"Do not force a literal 'I forgot' structure. In conversation, Se me olvidó... is a useful natural chunk.",exercise:"Say three problems beginning with Se me..."},
  {id:"quedar",title:"Quedar for location and plans",formula:"¿Dónde queda...? · Nos vemos / quedamos...",explain:"Use quedar to ask where a place is and to talk about arranging a meeting. It is one of the most useful verbs for getting around and making plans.",examples:[{es:"¿Dónde queda la farmacia?",en:"Where is the pharmacy located?",tts:"¿Dónde queda la farmacia?"},{es:"¿A qué hora quedamos?",en:"What time shall we meet?",tts:"¿A qué hora quedamos?"},{es:"Nos vemos a las siete.",en:"See you at seven.",tts:"Nos vemos a las siete."}],mistake:"For a known object's current location, use está; for asking where a place is located, ¿Dónde queda...? is very natural.",exercise:"Ask where the hotel is and arrange a time to meet."}
];
SPEAKING_GUIDE.push(
  {id:"pasado-contraste",title:"Preterite vs. imperfect",formula:"event = preterite · background/habit = imperfect",explain:"Use the preterite for a completed event that moves the story forward. Use the imperfect for what was happening, what used to happen, or the setting.",examples:[{es:"Ayer fui al mercado.",en:"Yesterday I went to the market.",tts:"Ayer fui al mercado."},{es:"Cuando era niño, vivía en Cali.",en:"When I was a child, I used to live in Cali.",tts:"Cuando era niño, vivía en Cali."},{es:"Mientras trabajaba, sonó el teléfono.",en:"While I was working, the phone rang.",tts:"Mientras trabajaba, sonó el teléfono."}],mistake:"Do not choose only by translating was. Ask whether you are describing the background (era/estaba/iba) or a completed event (fui/sonó).",exercise:"Tell a two-sentence story: set the scene with estaba or era, then say what happened with fui or llegó."},
  {id:"subjuntivo",title:"Wishes and recommendations",formula:"trigger + que + new subject + subjunctive",explain:"Use this high-value pattern after quiero que, espero que, es importante que, and similar expressions when another person is doing the action.",examples:[{es:"Quiero que vengas mañana.",en:"I want you to come tomorrow.",tts:"Quiero que vengas mañana."},{es:"Espero que estés bien.",en:"I hope you are well.",tts:"Espero que estés bien."},{es:"Es importante que hables despacio.",en:"It is important that you speak slowly.",tts:"Es importante que hables despacio."}],mistake:"If the subject stays the same, use the infinitive: Quiero hablar. If the subject changes, use que + subjunctive: Quiero que hables.",exercise:"Say one wish with Quiero que..., one hope with Espero que..., and one recommendation with Es importante que..."}
);
SPEAKING_GUIDE.push(...V58_SPEAKING_GUIDE);

/* v60: high-frequency production patterns. Teach the useful chunk first;
   explain the grammar only after the learner has said it. */
SPEAKING_GUIDE.push(
  {id:"gerundios",title:"Actions in progress",formula:"estar + gerundio",explain:"Use estar + -ando/-iendo for an action happening now or in progress. English -ing does not always use this form: Fui de compras means I went shopping, not I went being shopping.",examples:[{es:"Estoy cocinando la cena.",en:"I am cooking dinner.",tts:"Estoy cocinando la cena."},{es:"Estoy buscando la dirección.",en:"I am looking for the address.",tts:"Estoy buscando la dirección."},{es:"Estaba trabajando cuando llamaste.",en:"I was working when you called.",tts:"Estaba trabajando cuando llamaste."}],mistake:"Do not use estar + gerundio for every English -ing idea. Use fui de compras, me gusta cocinar, or voy a tomar depending on the meaning.",exercise:"Say what you are doing now, what you were doing earlier, and one activity you went to do."},
  {id:"mandatos",title:"Useful commands and repair",formula:"habla / hable · dime / dígame",explain:"Commands let you ask for a practical action quickly. Use the informal form with a close friend and the formal usted form with a driver, employee, stranger, or older person.",examples:[{es:"Háblame más despacio.",en:"Speak to me more slowly. (informal)",tts:"Háblame más despacio."},{es:"Hábleme más despacio, por favor.",en:"Speak to me more slowly, please. (formal)",tts:"Hábleme más despacio, por favor."},{es:"Discúlpeme, ¿me puede repetir?",en:"Excuse me, can you repeat that for me? (formal)",tts:"Discúlpeme, ¿me puede repetir?"}],mistake:"Do not say discúlpe or discúplte. Say disculpa with a friend, disculpe to one person formally, and discúlpeme when you mean excuse me / excuse me for interrupting.",exercise:"Ask a friend to listen, then ask a driver to repeat the address more slowly."}
);

/* ═══════════════════════════════════════════════════════════════════════════
   Lesson Player Content (v15) — speaking-first
   goal: the sentence you'll be able to SAY at the end
   words: key chunks (tap to hear) · phrases: production cards (EN shown → you say it in Spanish, tap to check)
   ═══════════════════════════════════════════════════════════════════════════ */
const LESSON_CONTENT={
  presentate:{goal:{es:"Hola, ¿cómo estás? Me llamo Seth, soy de Estados Unidos y vivo en Colombia.",en:"Hi, how are you? My name is Seth, I'm from the U.S. and I live in Colombia."},
    words:[{es:"¿Cómo estás?",en:"How are you?"},{es:"Estoy bien, gracias.",en:"I'm fine, thank you."},{es:"Me llamo...",en:"My name is..."},{es:"Soy de...",en:"I'm from..."},{es:"Vivo en...",en:"I live in..."},{es:"Mucho gusto",en:"Nice to meet you"},{es:"¿Cómo te llamas?",en:"What's your name?"},{es:"¿De dónde eres?",en:"Where are you from?"},{es:"No entendí.",en:"I didn't understand."}],
    phrases:[{en:"How are you?",es:"¿Cómo estás?"},{en:"I'm fine, thank you.",es:"Estoy bien, gracias."},{en:"My name is Ana.",es:"Me llamo Ana."},{en:"I'm from the United States.",es:"Soy de Estados Unidos."},{en:"I live in Bogotá.",es:"Vivo en Bogotá."},{en:"Nice to meet you!",es:"¡Mucho gusto!"},{en:"I didn't understand. Can you repeat, please?",es:"No entendí. ¿Puede repetir, por favor?"}]},
  plata:{goal:{es:"¿Cuánto cuesta? — Son veinte mil pesos.",en:"How much is it? — It's twenty thousand pesos."},
    words:[{es:"La plata",en:"Money (Colombian!)"},{es:"¿Cuánto cuesta?",en:"How much does it cost?"},{es:"Mil pesos",en:"A thousand pesos"},{es:"El cambio",en:"Change"},{es:"En efectivo",en:"In cash"},{es:"Caro / Barato",en:"Expensive / Cheap"}],
    phrases:[{en:"How much does it cost?",es:"¿Cuánto cuesta?"},{en:"It's ten thousand pesos.",es:"Son diez mil pesos."},{en:"Do you have change?",es:"¿Tiene cambio?"},{en:"It's very expensive!",es:"¡Está muy caro!"}]},
  trabajo:{goal:{es:"Trabajo como ingeniero y tengo una reunión hoy.",en:"I work as an engineer and I have a meeting today."},
    words:[{es:"El trabajo",en:"Work / Job"},{es:"La reunión",en:"Meeting"},{es:"El cliente",en:"Client"},{es:"El jefe",en:"Boss"},{es:"El correo",en:"Email"},{es:"La oficina",en:"Office"}],
    phrases:[{en:"What do you do for work?",es:"¿En qué trabajas?"},{en:"I work as an engineer.",es:"Trabajo como ingeniero."},{en:"I have a meeting today.",es:"Tengo una reunión hoy."},{en:"I like my job.",es:"Me gusta mi trabajo."}]},
  casa:{goal:{es:"La toalla está en la habitación, sobre la cama.",en:"The towel is in the bedroom, on the bed."},
    words:[{es:"La cama",en:"Bed"},{es:"La almohada",en:"Pillow"},{es:"La cobija",en:"Blanket (Colombian!)"},{es:"La ducha",en:"Shower"},{es:"La toalla",en:"Towel"},{es:"El clóset",en:"Closet"}],
    phrases:[{en:"Where is the towel?",es:"¿Dónde está la toalla?"},{en:"It's on the bed.",es:"Está sobre la cama."},{en:"I need a pillow.",es:"Necesito una almohada."},{en:"The soap is in the shower.",es:"El jabón está en la ducha."}]},
  calle:{goal:{es:"Siga derecho y gire a la derecha en el semáforo.",en:"Go straight and turn right at the traffic light."},
    words:[{es:"La derecha",en:"Right"},{es:"La izquierda",en:"Left"},{es:"La esquina",en:"Corner"},{es:"El semáforo",en:"Traffic light"},{es:"Queda cerca",en:"It's nearby"},{es:"Queda lejos",en:"It's far"}],
    phrases:[{en:"Where is the bank?",es:"¿Dónde queda el banco?"},{en:"Go straight.",es:"Siga derecho."},{en:"Turn left at the corner.",es:"Gire a la izquierda en la esquina."},{en:"Is it nearby?",es:"¿Queda cerca?"}]},
  cocina:{goal:{es:"Voy a cortar las verduras y tú calientas la olla.",en:"I'll cut the vegetables and you heat the pot."},
    words:[{es:"El cuchillo",en:"Knife"},{es:"La olla",en:"Pot"},{es:"La sartén",en:"Pan"},{es:"Cortar",en:"To cut"},{es:"Hervir",en:"To boil"},{es:"La nevera",en:"Fridge (Colombian!)"}],
    phrases:[{en:"Where is the knife?",es:"¿Dónde está el cuchillo?"},{en:"I'm going to cut the onion.",es:"Voy a cortar la cebolla."},{en:"The pot is on the stove.",es:"La olla está en la estufa."},{en:"It's delicious!",es:"¡Está delicioso!"}]},
  gustos:{goal:{es:"Me gusta cocinar y pasar tiempo con mi familia.",en:"I like cooking and spending time with my family."},
    words:[{es:"Me gusta...",en:"I like..."},{es:"Me encanta...",en:"I love..."},{es:"La familia",en:"Family"},{es:"Los hermanos",en:"Siblings"},{es:"Mi favorito/a",en:"My favorite"},{es:"Odio...",en:"I hate..."}],
    phrases:[{en:"I like music.",es:"Me gusta la música."},{en:"I love traveling.",es:"Me encanta viajar."},{en:"Do you have siblings?",es:"¿Tienes hermanos?"},{en:"I love them a lot.",es:"Los quiero mucho."}]},
  planes:{goal:{es:"¿Nos vemos mañana? — ¡De una! Te escribo.",en:"Shall we meet tomorrow? — I'm in! I'll text you."},
    words:[{es:"Mañana",en:"Tomorrow"},{es:"El celular",en:"Cell phone (Colombian!)"},{es:"El mensaje",en:"Message"},{es:"La llamada",en:"Call"},{es:"¿Aló?",en:"Hello? (phone, Colombian!)"},{es:"De pronto",en:"Maybe (Colombian!)"}],
    phrases:[{en:"Shall we meet tomorrow?",es:"¿Nos vemos mañana?"},{en:"I'll call you later.",es:"Te llamo más tarde."},{en:"Send me the location.",es:"Mándame la ubicación."},{en:"I'm in!",es:"¡De una!"}]},
  sentirse:{goal:{es:"Me duele la cabeza y tengo sueño.",en:"My head hurts and I'm sleepy."},
    words:[{es:"Cansado/a",en:"Tired"},{es:"Feliz",en:"Happy"},{es:"Tengo hambre",en:"I'm hungry"},{es:"Tengo sueño",en:"I'm sleepy"},{es:"Me duele...",en:"...hurts"},{es:"Enfermo/a",en:"Sick"}],
    phrases:[{en:"How do you feel?",es:"¿Cómo te sientes?"},{en:"I'm hungry.",es:"Tengo hambre."},{en:"My head hurts.",es:"Me duele la cabeza."},{en:"I need to rest.",es:"Necesito descansar."}]},
  colombia:{goal:{es:"¿Qué más, parce? — Todo bien, ¡qué bacano verte!",en:"What's up, buddy? — All good, so cool to see you!"},
    words:[{es:"Parce",en:"Buddy (Colombian!)"},{es:"Chévere",en:"Cool"},{es:"Bacano",en:"Awesome (Colombian!)"},{es:"El tinto",en:"Black coffee (Colombian!)"},{es:"La plata",en:"Money (Colombian!)"},{es:"¿Qué más?",en:"What's up? (Colombian!)"}],
    phrases:[{en:"What's up, buddy?",es:"¿Qué más, parce?"},{en:"How cool!",es:"¡Qué bacano!"},{en:"Can I have a coffee?",es:"¿Me regala un tinto?"},{en:"OK, got it.",es:"Listo."}]},
  "gram-presente":{goal:{es:"Hablo español todos los días y vivo en Colombia.",en:"I speak Spanish every day and I live in Colombia."},
    words:[{es:"Hablo",en:"I speak"},{es:"Vivo",en:"I live"},{es:"Tengo",en:"I have"},{es:"Soy",en:"I am (identity)"},{es:"Estoy",en:"I am (state/location)"},{es:"Me gusta",en:"I like"}],
    phrases:[{en:"I speak a little Spanish.",es:"Hablo un poco de español."},{en:"I live in Colombia.",es:"Vivo en Colombia."},{en:"I have a question.",es:"Tengo una pregunta."},{en:"I like Colombian food.",es:"Me gusta la comida colombiana."}]},
  "gram-futuro":{goal:{es:"Mañana voy a practicar español y voy a hablar con un colombiano.",en:"Tomorrow I am going to practice Spanish and talk with a Colombian."},
    words:[{es:"Voy a...",en:"I am going to..."},{es:"Vas a...",en:"You are going to..."},{es:"Vamos a...",en:"We are going to..."},{es:"Mañana",en:"Tomorrow"},{es:"Después",en:"Later / afterward"},{es:"Te voy a llamar",en:"I am going to call you"}],
    phrases:[{en:"I am going to study tonight.",es:"Voy a estudiar esta noche."},{en:"What are you going to do tomorrow?",es:"¿Qué vas a hacer mañana?"},{en:"We are going to go out after work.",es:"Vamos a salir después del trabajo."},{en:"I am going to call you later.",es:"Te voy a llamar más tarde."}]},
  "gram-pasado":{goal:{es:"Ayer fui al mercado y compré comida.",en:"Yesterday I went to the market and bought food."},
    words:[{es:"Ayer",en:"Yesterday"},{es:"Fui",en:"I went / I was"},{es:"Hice",en:"I did / made"},{es:"Tuve",en:"I had"},{es:"Comí",en:"I ate"},{es:"Hablé",en:"I spoke"}],
    phrases:[{en:"Yesterday I went to the market.",es:"Ayer fui al mercado."},{en:"I ate an arepa.",es:"Comí una arepa."},{en:"I spoke with my friend.",es:"Hablé con mi amigo."},{en:"What did you do yesterday?",es:"¿Qué hiciste ayer?"}]},
  "gram-pronombres":{goal:{es:"¿Me lo puede repetir? — Sí, se lo repito despacio.",en:"Can you repeat it for me? — Yes, I will repeat it slowly."},
    words:[{es:"lo",en:"him / it (masculine)"},{es:"la",en:"her / it (feminine)"},{es:"le",en:"to him / to her"},{es:"me lo",en:"it to me (masculine)"},{es:"se lo",en:"it to him/her"},{es:"me la",en:"it to me (feminine)"},{es:"se la",en:"it to him/her (feminine)"},{es:"lo necesito",en:"I need it (masculine)"}],
    phrases:[{en:"Do you have the address? — Yes, I have it here.",es:"¿Tiene la dirección? — Sí, la tengo aquí."},{en:"Can you help me? — Yes, I will help you.",es:"¿Me puede ayudar? — Sí, le ayudo."},{en:"Can you repeat it for me? — Yes, I will repeat it slowly.",es:"¿Me lo puede repetir? — Sí, se lo repito despacio."},{en:"Can you send it to me? — Yes, I will send it.",es:"¿Me la puede mandar? — Sí, se la mando."},{en:"Do you have the document? — Yes, I have it.",es:"¿Tiene el documento? — Sí, lo tengo."},{en:"Did you send her the location? — Yes, I sent it to her.",es:"¿Le mandaste la ubicación? — Sí, se la mandé."}]},
 };

 /* Conversation foundations and Colombian slang are separate lesson content so
    the existing lesson player can reuse the same speaking-first steps. */
 Object.assign(LESSON_CONTENT,{
   "gram-pasado-historia":{goal:{es:"Fui al mercado, pero después estaba en casa.",en:"I went to the market, but afterward I was at home."},
     words:[{es:"Fui a...",en:"I went to..."},{es:"Estuve en...",en:"I was / stayed in..."},{es:"Estaba en...",en:"I was in / at..."},{es:"Era...",en:"I was... (identity / description)"},{es:"Iba a...",en:"I was going to..."},{es:"Tenía que...",en:"I had to..."}],
     phrases:[{en:"I went to the market.",es:"Fui al mercado."},{en:"I was at the office.",es:"Estaba en la oficina."},{en:"I was going to cook.",es:"Iba a cocinar."},{en:"I had to work.",es:"Tuve que trabajar."}]},
   "gram-necesidades":{goal:{es:"Quería salir, pero tuve que trabajar porque estaba ocupado.",en:"I wanted to go out, but I had to work because I was busy."},
     words:[{es:"Quería...",en:"I wanted..."},{es:"Necesitaba...",en:"I needed..."},{es:"Podía...",en:"I could..."},{es:"No podía...",en:"I couldn't..."},{es:"Tuve que...",en:"I had to..."},{es:"Porque...",en:"Because..."}],
     phrases:[{en:"I wanted to rest.",es:"Quería descansar."},{en:"I needed help.",es:"Necesitaba ayuda."},{en:"I couldn't go.",es:"No podía ir."},{en:"I had to work late.",es:"Tuve que trabajar hasta tarde."}]},
   "gram-conectores":{goal:{es:"Fui al mercado, pero estaba cerrado, entonces regresé.",en:"I went to the market, but it was closed, so I went back."},
     words:[{es:"Pero...",en:"But..."},{es:"Porque...",en:"Because..."},{es:"Entonces...",en:"So / then..."},{es:"Después...",en:"Afterward..."},{es:"También...",en:"Also..."},{es:"La verdad...",en:"The truth is..."}],
     phrases:[{en:"I was tired, but I went.",es:"Estaba cansado, pero fui."},{en:"I stayed home because it was raining.",es:"Me quedé en casa porque estaba lloviendo."},{en:"I finished work, so I went home.",es:"Terminé el trabajo, entonces me fui a casa."},{en:"I also wanted to call you.",es:"También quería llamarte."}]},
   "gram-groserias":{goal:{es:"Entiendo las groserías, pero sé cuándo no decirlas.",en:"I understand swear words, but I know when not to say them."},
     words:[{es:"¡No joda!",en:"No way! / Come on! (informal)"},{es:"Juepucha",en:"Darn! (milder euphemism)"},{es:"Gonorrea",en:"Very strong insult / intensifier"},{es:"Pirobo",en:"Strong insult: jerk / scumbag"},{es:"Marica",en:"Highly context-sensitive: dude / insult"},{es:"Hijueputa",en:"Very strong insult / exclamation"}],
     phrases:[{en:"Darn, I'm late!",es:"¡Juepucha, se me hizo tarde!"},{en:"No way!",es:"¡No joda!"},{en:"What horrible traffic! (very strong)",es:"¡Qué gonorrea de tráfico!"},{en:"I understand it, but I would not say it to a stranger.",es:"Lo entiendo, pero no se lo diría a un desconocido."}]}
 });

/* v36 lesson metadata gives each lesson a clear reason to exist and links it
   to the exact conversation, reading, mission, and grammar guide it uses. */
Object.assign(LESSON_CONTENT,{
  "survival-communication":{goal:{es:"No entendí. ¿Puede repetir más despacio, por favor?",en:"I didn't understand. Can you repeat more slowly, please?"},words:[{es:"No entendí.",en:"I didn't understand."},{es:"¿Puede repetir?",en:"Can you repeat?"},{es:"Más despacio.",en:"More slowly."},{es:"¿Qué quiere decir?",en:"What does that mean?"},{es:"Un momento.",en:"One moment."},{es:"¿Así está bien?",en:"Is it okay like this?"}],phrases:[{en:"I speak a little Spanish.",es:"Hablo poquito español."},{en:"Can you repeat, please?",es:"¿Puede repetir, por favor?"},{en:"Sorry, I am learning Spanish.",es:"Perdón, estoy aprendiendo español."}]},
  "uber-ride":{goal:{es:"Buenas, ¿usted es mi conductor? Hablo poquito español.",en:"Hi, are you my driver? I speak a little Spanish."},words:[{es:"el conductor",en:"driver"},{es:"la recogida",en:"pickup"},{es:"la dirección",en:"address"},{es:"el hotel",en:"hotel"},{es:"el trancón",en:"traffic jam (Colombian)"},{es:"súbase",en:"get in"}],phrases:[{en:"Are you my driver?",es:"¿Usted es mi conductor?"},{en:"I am going to this hotel.",es:"Voy para este hotel."},{en:"Can you speak more slowly?",es:"¿Puede hablar más despacio?"}]},
  "hotel-checkin":{goal:{es:"Tengo una reserva a nombre de Seth. ¿Dónde está el ascensor?",en:"I have a reservation under Seth's name. Where is the elevator?"},words:[{es:"la reserva",en:"reservation"},{es:"a nombre de...",en:"under the name of..."},{es:"el pasaporte",en:"passport"},{es:"la recepción",en:"front desk"},{es:"el ascensor",en:"elevator"},{es:"el desayuno",en:"breakfast"}],phrases:[{en:"I have a reservation.",es:"Tengo una reserva."},{en:"Can you show me the elevator?",es:"¿Me puede mostrar el ascensor?"},{en:"What time is breakfast?",es:"¿A qué hora es el desayuno?"}]},
  "farmacia":{goal:{es:"Me duele la cabeza desde esta mañana. ¿Cómo lo debo tomar?",en:"My head has hurt since this morning. How should I take it?"},words:[{es:"la farmacia",en:"pharmacy"},{es:"el dolor de cabeza",en:"headache"},{es:"la pastilla",en:"pill"},{es:"la fiebre",en:"fever"},{es:"la tos",en:"cough"},{es:"desde esta mañana",en:"since this morning"}],phrases:[{en:"I need something for a headache.",es:"Necesito algo para el dolor de cabeza."},{en:"How should I take it?",es:"¿Cómo lo debo tomar?"},{en:"I feel tired.",es:"Me siento cansado."}]},
  "direcciones":{goal:{es:"Siga derecho hasta la esquina y gire a la derecha.",en:"Go straight to the corner and turn right."},words:[{es:"hasta el fondo",en:"to the back / end"},{es:"al frente",en:"in front / across"},{es:"detrás de",en:"behind"},{es:"la entrada",en:"entrance"},{es:"el edificio",en:"building"},{es:"el segundo piso",en:"second floor"}],phrases:[{en:"Where is the entrance?",es:"¿Dónde está la entrada?"},{en:"It is that building over there.",es:"Es el edificio de allá."},{en:"Go up to the second floor.",es:"Suba al segundo piso."}]},
  "daily-repair":{goal:{es:"No entendí. La señal está mala, así que te escribo.",en:"I didn't understand. The signal is bad, so I will text you."},words:[{es:"¿Me escuchas?",en:"Can you hear me?"},{es:"la señal está mala",en:"the signal is bad"},{es:"se está cortando",en:"it is cutting out"},{es:"te escribo",en:"I will text you"},{es:"más tarde",en:"later"},{es:"un mensaje",en:"a message"}],phrases:[{en:"Can you hear me?",es:"¿Me escuchas?"},{en:"The call is cutting out.",es:"Se está cortando la llamada."},{en:"I will text you later.",es:"Te escribo más tarde."}]},
  "sentence-structure":{goal:{es:"Quiero aprender, así que practico un poco todos los días.",en:"I want to learn, so I practice a little every day."},words:[{es:"Quiero...",en:"I want..."},{es:"así que...",en:"so / therefore..."},{es:"porque...",en:"because..."},{es:"primero...",en:"first..."},{es:"después...",en:"afterward..."},{es:"al final...",en:"in the end..."}],phrases:[{en:"I need to practice because I want to speak.",es:"Necesito practicar porque quiero hablar."},{en:"First I listen, then I repeat.",es:"Primero escucho, después repito."},{en:"I was tired, but I practiced.",es:"Estaba cansado, pero practiqué."}]},
  "connectors-v36":{goal:{es:"Si puedo, te aviso; si no, no pasa nada.",en:"If I can, I will let you know; if not, it's okay."},words:[{es:"si",en:"if"},{es:"sí",en:"yes"},{es:"pero",en:"but"},{es:"porque",en:"because"},{es:"por qué",en:"why"},{es:"entonces",en:"so / then"},{es:"aunque",en:"although"},{es:"todavía no",en:"not yet"}],phrases:[{en:"I want to go, but I have to work.",es:"Quiero ir, pero tengo que trabajar."},{en:"Why are you late?",es:"¿Por qué llegas tarde?"},{en:"There is traffic, so I will arrive late.",es:"Hay trancón, entonces voy a llegar tarde."}]},
  "function-words":{goal:{es:"Todavía no sé; si puedo, te aviso en cuanto pueda.",en:"I don't know yet; if I can, I will let you know as soon as I can."},words:[{es:"Todavía no",en:"Not yet"},{es:"De pronto",en:"Maybe (Colombian)"},{es:"En realidad",en:"Actually"},{es:"Lo que pasa es que",en:"The thing is"},{es:"Por ahora",en:"For now"},{es:"Al rato",en:"Later (Colombian)"}],phrases:[{en:"I don't know yet.",es:"Todavía no sé."},{en:"Maybe I will call you later.",es:"De pronto te llamo al rato."},{en:"The thing is, I have to work.",es:"Lo que pasa es que tengo que trabajar."},{en:"I will let you know as soon as I can.",es:"Te aviso en cuanto pueda."}]},
  "action-chunks":{goal:{es:"Quiero ir para el hotel, pero tengo que pasar por el mercado.",en:"I want to go to the hotel, but I have to stop by the market."},words:[{es:"Quiero...",en:"I want to..."},{es:"Necesito...",en:"I need to..."},{es:"Tengo que...",en:"I have to..."},{es:"Voy para...",en:"I'm headed to..."},{es:"Estoy buscando...",en:"I'm looking for..."},{es:"Se me olvidó...",en:"I forgot..."},{es:"Me toca...",en:"I have to... / It's my turn..."}],phrases:[{en:"I want to go home.",es:"Quiero ir para la casa."},{en:"I need to find the address.",es:"Necesito encontrar la dirección."},{en:"I need to call my friend.",es:"Necesito llamar a mi amigo."},{en:"I have to call my friend.",es:"Tengo que llamar a mi amigo."},{en:"I'm going to call my friend.",es:"Voy a llamar a mi amigo."},{en:"I have to stop by the market.",es:"Tengo que pasar por el mercado."},{en:"I am looking for the hotel.",es:"Estoy buscando el hotel."},{en:"I forgot the location.",es:"Se me olvidó la ubicación."},{en:"I am on my way.",es:"Voy llegando."}]},
  "social-colombia-v36":{goal:{es:"¿Qué más? Todo bien. ¡Qué nota verte, parce!",en:"What's up? All good. How cool to see you, buddy!"},words:[{es:"¿Cómo te ha ido?",en:"How have things been?"},{es:"Hágale",en:"Go ahead / let's do it"},{es:"Qué pena",en:"Sorry / what a shame"},{es:"Qué nota",en:"How cool"},{es:"Bacano",en:"Awesome"},{es:"Parce",en:"Buddy"}],phrases:[{en:"How have things been?",es:"¿Cómo te ha ido?"},{en:"Don't worry.",es:"No se preocupe."},{en:"Let's do it.",es:"¡Hágale!"}]}
  ,"conversation-challenge":{goal:{es:"Puedo responder, pedir aclaración y mantener una conversación corta.",en:"I can respond, ask for clarification, and keep a short conversation going."},words:[{es:"No entendí.",en:"I didn't understand."},{es:"¿Puede repetir?",en:"Can you repeat?"},{es:"Voy a...",en:"I am going to..."},{es:"Ayer fui...",en:"Yesterday I went..."},{es:"Después...",en:"Afterward..."},{es:"¿Qué más?",en:"What's up?"}],phrases:[{en:"I speak a little Spanish, but I am practicing.",es:"Hablo poquito español, pero estoy practicando."},{en:"I am going to answer in Spanish.",es:"Voy a responder en español."},{en:"I did not understand, but I will try again.",es:"No entendí, pero voy a intentarlo otra vez."}]}
});
Object.assign(LESSON_CONTENT,{
  "gram-pasado-contraste":{goal:{es:"Ayer fui al mercado mientras mi hermano estaba en casa.",en:"Yesterday I went to the market while my brother was at home."},words:[{es:"Ayer fui...",en:"Yesterday I went..."},{es:"Era...",en:"I was... (identity / description)"},{es:"Estaba...",en:"I was... (state / location)"},{es:"Iba...",en:"I used to go / was going"},{es:"Mientras...",en:"While..."},{es:"De repente...",en:"Suddenly..."}],phrases:[{en:"Yesterday I went to the market.",es:"Ayer fui al mercado."},{en:"When I was a child, I used to live in Cali.",es:"Cuando era niño, vivía en Cali."},{en:"While I was cooking, you called me.",es:"Mientras cocinaba, me llamaste."},{en:"The phone rang, so I stopped working.",es:"Sonó el teléfono, entonces dejé de trabajar."}]},
  "gram-subjuntivo":{goal:{es:"Quiero que vengas y espero que estés bien.",en:"I want you to come, and I hope you are well."},words:[{es:"Quiero que...",en:"I want you to..."},{es:"Espero que...",en:"I hope that..."},{es:"Es importante que...",en:"It is important that..."},{es:"Vengas",en:"You come (subjunctive)"},{es:"Estés",en:"You are (subjunctive)"},{es:"Hables",en:"You speak (subjunctive)"}],phrases:[{en:"I want you to come tomorrow.",es:"Quiero que vengas mañana."},{en:"I hope you are well.",es:"Espero que estés bien."},{en:"It is important that you speak slowly.",es:"Es importante que hables despacio."},{en:"I want to practice so that I can speak.",es:"Quiero practicar para poder hablar."}]}
  ,"gram-perfecto":{goal:{es:"He practicado español esta semana y ya he probado la arepa.",en:"I have practiced Spanish this week and I have already tried arepa."},words:[{es:"He hecho...",en:"I have done..."},{es:"Has probado...",en:"You have tried..."},{es:"Ya he visto...",en:"I have already seen..."},{es:"Hemos llegado...",en:"We have arrived..."},{es:"Todavía no he...",en:"I have not yet..."},{es:"Nunca he...",en:"I have never..."}],phrases:[{en:"I have practiced this week.",es:"He practicado esta semana."},{en:"Have you tried the arepa?",es:"¿Has probado la arepa?"},{en:"We have already arrived.",es:"Ya hemos llegado."}]}
  ,"gram-condicional":{goal:{es:"Me gustaría pedir una mesa. ¿Podría repetir, por favor?",en:"I would like to order a table. Could you repeat, please?"},words:[{es:"Me gustaría...",en:"I would like..."},{es:"¿Podría...?",en:"Could you...?"},{es:"Podríamos...",en:"We could..."},{es:"Debería...",en:"I/you/he should..."},{es:"Sería...",en:"It would be..."},{es:"Quisiera...",en:"I would like... (polite)"}],phrases:[{en:"I would like to order a table.",es:"Me gustaría pedir una mesa."},{en:"Could you repeat, please?",es:"¿Podría repetir, por favor?"},{en:"We should leave early.",es:"Deberíamos salir temprano."}]}
  ,"gram-pasado-perfecto":{goal:{es:"Cuando llegué, ya habían cerrado la tienda.",en:"When I arrived, they had already closed the store."},words:[{es:"Ya había...",en:"I had already..."},{es:"Habías visto...",en:"You had seen..."},{es:"Había salido...",en:"He/she had left..."},{es:"Habíamos comido...",en:"We had eaten..."},{es:"Antes de que...",en:"Before..."},{es:"Cuando llegué...",en:"When I arrived..."}],phrases:[{en:"When I arrived, they had already closed.",es:"Cuando llegué, ya habían cerrado."},{en:"I had already eaten when you called.",es:"Ya había comido cuando me llamaste."},{en:"I had never used that app.",es:"Nunca había usado esa aplicación."}]}
  ,"gram-futuro-perfecto":{goal:{es:"Para las ocho, habré terminado.",en:"By eight, I will have finished."},words:[{es:"Habré terminado...",en:"I will have finished..."},{es:"Habrás llegado...",en:"You will have arrived..."},{es:"Habrá salido...",en:"He/she will have left..."},{es:"Habremos comido...",en:"We will have eaten..."},{es:"Para las ocho...",en:"By eight..."},{es:"Cuando llegues...",en:"When you arrive..."}],phrases:[{en:"By eight, I will have finished.",es:"Para las ocho, habré terminado."},{en:"When you arrive, we will have already left.",es:"Cuando llegues, ya habremos salido."},{en:"In a year, I will have learned a lot.",es:"En un año, habré aprendido mucho."}]}
});
/* v60 lesson content: each new lesson is short enough to finish, but moves
   from recognition to guided production and then real conversation. */
Object.assign(LESSON_CONTENT,{
  "commands-repair":{goal:{es:"Disculpe, hábleme más despacio y repítame la dirección, por favor.",en:"Excuse me, speak to me more slowly and repeat the address for me, please."},words:[{es:"Disculpe",en:"Excuse me (formal)"},{es:"Hábleme",en:"Speak to me (formal)"},{es:"Dígame",en:"Tell me (formal)"},{es:"Escúchame",en:"Listen to me (informal)"},{es:"Repítame",en:"Repeat for me (formal)"},{es:"Más despacio",en:"More slowly"}],phrases:[{en:"Speak to me more slowly, please.",es:"Hábleme más despacio, por favor."},{en:"Tell me the address.",es:"Dígame la dirección."},{en:"Excuse me, I didn't understand.",es:"Disculpe, no entendí."},{en:"Can you repeat that for me?",es:"¿Me lo puede repetir?"}]},
  "uber-completo":{goal:{es:"Hablo un poco de español. Voy para el edificio de la esquina.",en:"I speak a little Spanish. I am going to the building on the corner."},words:[{es:"el conductor",en:"driver"},{es:"la esquina",en:"corner"},{es:"al frente",en:"across the way"},{es:"hablo un poco",en:"I speak a little"},{es:"avísame",en:"let me know (informal)"},{es:"dónde me bajo",en:"where I get out"}],phrases:[{en:"Are you the Uber driver?",es:"¿Usted es el conductor de Uber?"},{en:"Can you speak slowly?",es:"¿Puede hablar despacio?"},{en:"I am going to the building on the corner.",es:"Voy para el edificio de la esquina."},{en:"Please let me know when we arrive.",es:"Avíseme cuando lleguemos, por favor."}]},
  "restaurante-real":{goal:{es:"Quisiera una sopa con papa y un jugo sin azúcar, por favor.",en:"I would like a soup with potato and a juice without sugar, please."},words:[{es:"una mesa para dos",en:"a table for two"},{es:"quisiera",en:"I would like"},{es:"con papa",en:"with potato"},{es:"sin azúcar",en:"without sugar"},{es:"algo más",en:"anything else"},{es:"la cuenta",en:"the bill"}],phrases:[{en:"Do you have a table for two?",es:"¿Tiene una mesa para dos?"},{en:"I would like to order a soup.",es:"Quisiera pedir una sopa."},{en:"Without sugar, please.",es:"Sin azúcar, por favor."},{en:"Can you bring me the bill?",es:"¿Me trae la cuenta?"}]},
  "mercado-negociar":{goal:{es:"Está un poco caro. ¿Me lo deja en siete mil?",en:"It's a little expensive. Can you let me have it for seven thousand?"},words:[{es:"el kilo",en:"kilo"},{es:"está caro",en:"it is expensive"},{es:"me lo deja",en:"can you let me have it"},{es:"un descuento",en:"a discount"},{es:"deme",en:"give me (formal)"},{es:"por todo",en:"for everything"}],phrases:[{en:"How much does a kilo cost?",es:"¿Cuánto cuesta el kilo?"},{en:"It's a little expensive.",es:"Está un poco caro."},{en:"Can you give me a discount?",es:"¿Me hace un descuento?"},{en:"How much do I owe you for everything?",es:"¿Cuánto le debo por todo?"}]},
  "gerundios-actividades":{goal:{es:"Ahora estoy cocinando, pero después voy a salir.",en:"Right now I am cooking, but afterward I am going to go out."},words:[{es:"estoy cocinando",en:"I am cooking"},{es:"estoy buscando",en:"I am looking for"},{es:"estoy aprendiendo",en:"I am learning"},{es:"estaba trabajando",en:"I was working"},{es:"fui de compras",en:"I went shopping"},{es:"acabo de llegar",en:"I just arrived"}],phrases:[{en:"What are you doing?",es:"¿Qué estás haciendo?"},{en:"I am cooking dinner.",es:"Estoy cocinando la cena."},{en:"I was working when you called.",es:"Estaba trabajando cuando me llamaste."},{en:"I went shopping yesterday.",es:"Ayer fui de compras."}]},
  "social-salida":{goal:{es:"De una, nos vemos después. Te aviso cuando llegue.",en:"Sure, see you later. I will let you know when I arrive."},words:[{es:"¿Qué más?",en:"What's up?"},{es:"esta noche",en:"tonight"},{es:"salir con amigos",en:"go out with friends"},{es:"de una",en:"sure / I'm in"},{es:"llego tarde",en:"I arrive late"},{es:"avísame",en:"let me know"}],phrases:[{en:"What are you going to do tonight?",es:"¿Qué vas a hacer esta noche?"},{en:"I am going out with some friends.",es:"Voy a salir con unos amigos."},{en:"Shall we meet later?",es:"¿Nos vemos después?"},{en:"I think that's a good idea.",es:"Me parece buena idea."}]},
  "fiesta-gathering":{goal:{es:"La música está muy buena. La pasé muy bien.",en:"The music is really good. I had a great time."},words:[{es:"la gente",en:"the people"},{es:"conocer",en:"to know / meet"},{es:"algo de tomar",en:"something to drink"},{es:"está chévere",en:"it's cool"},{es:"la pasé bien",en:"I had a good time"},{es:"me tengo que ir",en:"I have to go"}],phrases:[{en:"How do you know the people here?",es:"¿Cómo conoces a la gente de aquí?"},{en:"Do you want something to drink?",es:"¿Quieres algo de tomar?"},{en:"The music is really good.",es:"La música está muy buena."},{en:"Nice to meet you. See you later.",es:"Qué gusto conocerte. Nos vemos luego."}]},
  "deportes-partido":{goal:{es:"Ojalá gane Colombia. Lo vemos juntos.",en:"I hope Colombia wins. We will watch it together."},words:[{es:"el partido",en:"the game"},{es:"no me lo pierdo",en:"I wouldn't miss it"},{es:"el marcador",en:"the score"},{es:"jugar contra",en:"to play against"},{es:"ojalá gane",en:"I hope it wins"},{es:"hicieron gol",en:"they scored"}],phrases:[{en:"Are you going to watch the game?",es:"¿Vas a ver el partido?"},{en:"Who's playing?",es:"¿Quién está jugando?"},{en:"How is the score?",es:"¿Cómo va el marcador?"},{en:"I hope Colombia wins.",es:"Ojalá gane Colombia."}]},
  "oficina-real":{goal:{es:"El proyecto va bien, pero estoy un poco atrasado.",en:"The project is going well, but I am a little behind."},words:[{es:"el proyecto",en:"the project"},{es:"atrasado",en:"behind / delayed"},{es:"el informe",en:"the report"},{es:"revisar",en:"to review"},{es:"después de la reunión",en:"after the meeting"},{es:"mandar al cliente",en:"send to the client"}],phrases:[{en:"How is the project going?",es:"¿Cómo va el proyecto?"},{en:"I am a little behind.",es:"Estoy un poco atrasado."},{en:"Can you review this part for me?",es:"¿Me puede revisar esta parte?"},{en:"Tomorrow we will send it to the client.",es:"Entonces mañana lo mandamos al cliente."}]}
});

const LESSON_META={
  presentate:{stage:"Start Here",difficulty:"Easy",prereq:"None",guideIds:["estructura"],readingId:"lectura-cafe",missionId:"saludo-parce"},
  plata:{stage:"Start Here",difficulty:"Easy",prereq:"Preséntate",guideIds:["estructura"],readingId:"lectura-mercado",missionId:"mercado-comida"},
  "survival-communication":{stage:"Start Here",difficulty:"Easy",prereq:"Preséntate",dialogue:"Uber: hablo poquito español",vocab:"gustos",quizCat:"reparar",quizMode:"mixed",guideIds:["negativas-preguntas"],missionId:"uber-habla-despacio"},
  "uber-ride":{stage:"Travel and Survival",difficulty:"Easy",prereq:"Comunicación para aclarar",dialogue:"Uber: confirmar la recogida",vocab:"direcciones",quizCat:"uber",quizMode:"conversation",readingId:"lectura-uber",missionId:"taxi-aeropuerto"},
  "hotel-checkin":{stage:"Travel and Survival",difficulty:"Easy",prereq:"Uber y transporte",dialogue:"Hotel: registrarse",vocab:"lugares",quizCat:"hotel",quizMode:"conversation",readingId:"lectura-hotel",missionId:"hotel-checkin"},
  "farmacia":{stage:"Travel and Survival",difficulty:"Moderate",prereq:"Hotel",dialogue:"Farmacia: explicar síntomas",vocab:"emociones",quizCat:"farmacia",quizMode:"conversation",missionId:"farmacia-sintomas"},
  calle:{stage:"Travel and Survival",difficulty:"Easy",prereq:"Números y plata",guideIds:["hay"],readingId:"lectura-edificio",missionId:"edificio-direcciones"},
  "daily-repair":{stage:"Daily Life",difficulty:"Moderate",prereq:"Travel and Survival",dialogue:"Teléfono: mala señal",vocab:"tecnologia",quizCat:"reparar",quizMode:"conversation",readingId:"lectura-telefono"},
  "sentence-structure":{stage:"Build Sentences",difficulty:"Moderate",prereq:"Start Here",dialogue:"Compañeros de trabajo",vocab:"acciones",quizCat:"estructura",quizMode:"mixed",guideIds:["estructura","sujeto-omitido","presente"]},
  "connectors-v36":{stage:"Build Sentences",difficulty:"Moderate",prereq:"Sentence structure",dialogue:"Planes de fin de semana",vocab:"gustos",quizCat:"conectores",quizMode:"mixed",guideIds:["conectores"],missionId:"planes-fin-semana"},
  "function-words":{stage:"Build Sentences",difficulty:"Moderate",prereq:"Connectors",dialogue:"Palabras para conversar",vocab:"gustos",quizCat:"conectores",quizMode:"mixed",guideIds:["conectores"],missionId:"planes-fin-semana"},
  "action-chunks":{stage:"Build Sentences",difficulty:"Easy",prereq:"Start Here",dialogue:"Acciones de todos los días",vocab:"acciones",quizCat:"acciones",quizMode:"conversation",guideIds:["estructura","presente"],missionId:"acciones-diarias"},
  "social-colombia-v36":{stage:"Speak More Naturally",difficulty:"Moderate",prereq:"Build Sentences",dialogue:"Compañeros de trabajo",vocab:"colombianismos",quizCat:"expresiones",quizMode:"conversation",guideIds:["conectores"],missionId:"saludo-parce"},
  "conversation-challenge":{stage:"Conversation Challenge",difficulty:"Challenge",prereq:"Speak More Naturally",dialogue:"Uber: confirmar la recogida",vocab:"gustos",quizCat:"all",quizMode:"conversation",readingId:"lectura-uber",missionId:"uber-habla-despacio",guideIds:["conectores","pronombres"]},
  "gram-presente":{stage:"Build Sentences",difficulty:"Moderate",prereq:"Start Here",guideIds:["presente","sujeto-omitido"]},
  "gram-futuro":{stage:"Build Sentences",difficulty:"Easy",prereq:"Presente",guideIds:["futuro"]},
  "gram-pasado":{stage:"Build Sentences",difficulty:"Moderate",prereq:"Presente",guideIds:["pasado"]},
  "gram-pasado-contraste":{stage:"Build Sentences",difficulty:"Moderate",prereq:"Pasado",guideIds:["pasado-contraste"],quizCat:"frases",quizMode:"blank",quizFocus:"past"},
  "gram-subjuntivo":{stage:"Build Sentences",difficulty:"Challenge",prereq:"Pasado",guideIds:["subjuntivo"],quizCat:"subjuntivo",quizMode:"blank",quizFocus:"subjuntivo"},
  "gram-pasado-historia":{stage:"Build Sentences",difficulty:"Moderate",prereq:"Pasado",guideIds:["pasado","conectores"]},
  "gram-necesidades":{stage:"Build Sentences",difficulty:"Moderate",prereq:"Pasado",guideIds:["negativas-preguntas"]},
  "gram-conectores":{stage:"Build Sentences",difficulty:"Moderate",prereq:"Sentence structure",guideIds:["conectores"]},
  "gram-pronombres":{stage:"Build Sentences",difficulty:"Challenge",prereq:"Sentence structure",guideIds:["pronombres"]},
  "gram-groserias":{stage:"Speak More Naturally",difficulty:"Challenge",prereq:"Everyday expressions",guideIds:["conectores"]}
};

Object.assign(LESSON_META,{
  "gram-perfecto":{stage:"Build Sentences",difficulty:"Moderate",prereq:"Pasado",guideIds:["perfecto"],quizCat:"frases",quizMode:"blank",quizFocus:"perfecto"},
  "gram-condicional":{stage:"Build Sentences",difficulty:"Moderate",prereq:"Presente",guideIds:["condicional"],quizCat:"frases",quizMode:"blank",quizFocus:"condicional"},
  "gram-pasado-perfecto":{stage:"Build Sentences",difficulty:"Challenge",prereq:"Pasado: evento vs. contexto",guideIds:["pasado-perfecto"],quizCat:"frases",quizMode:"blank",quizFocus:"pasado-perfecto"},
  "gram-futuro-perfecto":{stage:"Build Sentences",difficulty:"Challenge",prereq:"Planes futuros",guideIds:["futuro-perfecto"],quizCat:"frases",quizMode:"blank",quizFocus:"futuro-perfecto"}
});
Object.assign(LESSON_META,{
  "commands-repair":{stage:"Travel and Survival",difficulty:"Easy",prereq:"Hazte entender",dialogue:"Comunicación: pedir y aclarar",vocab:"direcciones",quizCat:"mandatos",quizMode:"conversation",guideIds:["mandatos"]},
  "uber-completo":{stage:"Travel and Survival",difficulty:"Easy",prereq:"Uber en español",dialogue:"Uber: viaje completo",vocab:"direcciones",quizCat:"uber-real",quizMode:"conversation",guideIds:["negativas-preguntas"]},
  "restaurante-real":{stage:"Travel and Survival",difficulty:"Easy",prereq:"Números y plata",dialogue:"Restaurante: una comida completa",vocab:"comida",quizCat:"restaurante-real",quizMode:"conversation",guideIds:["condicional"]},
  "mercado-negociar":{stage:"Travel and Survival",difficulty:"Moderate",prereq:"Números y plata",dialogue:"Mercado: comprar y negociar",vocab:"comida",quizCat:"mercado",quizMode:"conversation",guideIds:["condicional"]},
  "gerundios-actividades":{stage:"Build Sentences",difficulty:"Easy",prereq:"Acciones de todos los días",dialogue:"Cocinar y hablar de lo que haces",vocab:"acciones",quizCat:"gerundios",quizMode:"blank",quizFocus:"gerundios",guideIds:["gerundios"]},
  "social-salida":{stage:"Speak More Naturally",difficulty:"Easy",prereq:"Planes y teléfono",dialogue:"Salir con amigos",vocab:"gustos",quizCat:"social",quizMode:"conversation",guideIds:["futuro"]},
  "fiesta-gathering":{stage:"Speak More Naturally",difficulty:"Moderate",prereq:"Habla más colombiano",dialogue:"En una fiesta",vocab:"colombianismos",quizCat:"fiesta",quizMode:"conversation",guideIds:["conectores"]},
  "deportes-partido":{stage:"Speak More Naturally",difficulty:"Moderate",prereq:"Planes y teléfono",dialogue:"Ver el partido",vocab:"tv",quizCat:"deportes",quizMode:"conversation",guideIds:["futuro"]},
  "oficina-real":{stage:"Daily Life",difficulty:"Moderate",prereq:"Tu trabajo",dialogue:"Oficina: proyecto y retraso",vocab:"oficina",quizCat:"oficina-real",quizMode:"conversation",guideIds:["conectores","pronombres"]}
});

/* v56: speaking frames keep high-frequency sentence patterns separate from
   app logic. The trainer uses these as short, repeatable production drills. */
const SPEAKING_FRAMES=[
  {id:"quiero",title:"Say what you want",formula:"Quiero + infinitive",en:"I want to…",guide:"presente",prompts:[
    {en:"I want to go home.",es:"Quiero ir para la casa."},
    {en:"I want to practice Spanish.",es:"Quiero practicar español."},
    {en:"I want to order a coffee.",es:"Quiero pedir un café."}
  ]},
  {id:"tengo-que",title:"Say what you have to do",formula:"Tengo que + infinitive",en:"I have to…",guide:"presente",prompts:[
    {en:"I have to work today.",es:"Tengo que trabajar hoy."},
    {en:"I have to find the address.",es:"Tengo que encontrar la dirección."},
    {en:"I have to call my friend.",es:"Tengo que llamar a mi amigo."}
  ]},
  {id:"voy-a",title:"Talk about your next plan",formula:"Voy a + infinitive",en:"I am going to…",guide:"futuro",prompts:[
    {en:"I am going to call you later.",es:"Voy a llamarte más tarde."},
    {en:"I am going to take a taxi.",es:"Voy a tomar un taxi."},
    {en:"I am going to practice tonight.",es:"Voy a practicar esta noche."}
  ]},
  {id:"acabo-de",title:"Say what just happened",formula:"Acabo de + infinitive",en:"I just…",guide:"presente",prompts:[
    {en:"I just arrived.",es:"Acabo de llegar."},
    {en:"I just ate.",es:"Acabo de comer."},
    {en:"I just sent the location.",es:"Acabo de mandar la ubicación."}
  ]},
  {id:"se-me",title:"Explain an accidental problem",formula:"Se me + verb + thing",en:"Something happened to me…",guide:"se-me",prompts:[
    {en:"I forgot the address.",es:"Se me olvidó la dirección."},
    {en:"My phone broke on me.",es:"Se me dañó el celular."},
    {en:"I left my wallet in the car.",es:"Se me quedó la billetera en el carro."}
  ]},
  {id:"me-gustaria",title:"Make a polite request",formula:"Me gustaría + infinitive",en:"I would like to…",guide:"estructura",prompts:[
    {en:"I would like to ask a question.",es:"Me gustaría hacer una pregunta."},
    {en:"I would like to change the order.",es:"Me gustaría cambiar el pedido."},
    {en:"I would like to practice with you.",es:"Me gustaría practicar contigo."}
  ]},
  {id:"pronombres",title:"Use object pronouns naturally",formula:"lo / la / le → se lo / se la",en:"it / to him or her",guide:"pronombres",prompts:[
    {en:"I have it here.",es:"Lo tengo aquí."},
    {en:"I sent her the location.",es:"Se la mandé por mensaje."},
    {en:"I am going to send it to him.",es:"Se lo voy a mandar."}
  ]},
  {id:"connectors",title:"Connect two ideas",formula:"idea + pero / porque / entonces",en:"but / because / so",guide:"conectores",prompts:[
    {en:"I want to go, but I have to work.",es:"Quiero ir, pero tengo que trabajar."},
    {en:"I practice because I want to speak.",es:"Practico porque quiero hablar."},
    {en:"There is traffic, so I will arrive late.",es:"Hay trancón, entonces voy a llegar tarde."}
  ]}
];

/* v59: high-frequency chunks for real conversation, not isolated vocabulary. */
SPEAKING_FRAMES.push(
  {id:"ya-todavia",title:"Say what is already done",formula:"ya + verb / todavía no",en:"already / not yet",guide:"presente",prompts:[
    {en:"I already ate.",es:"Ya comí."},{en:"I have not arrived yet.",es:"Todavía no he llegado."},{en:"I already sent the location.",es:"Ya mandé la ubicación."}
  ]},
  {id:"lo-que-pasa",title:"Explain the real situation",formula:"Lo que pasa es que…",en:"The thing is…",guide:"conectores",prompts:[
    {en:"The thing is, I am still learning.",es:"Lo que pasa es que todavía estoy aprendiendo."},{en:"The thing is, I do not have the address.",es:"Lo que pasa es que no tengo la dirección."},{en:"The thing is, I have to work tomorrow.",es:"Lo que pasa es que tengo que trabajar mañana."}
  ]},
  {id:"no-se-si",title:"Sound natural when you are unsure",formula:"No sé si + sentence",en:"I do not know if…",guide:"conectores",prompts:[
    {en:"I do not know if the office is open.",es:"No sé si la oficina está abierta."},{en:"I do not know if he received the message.",es:"No sé si recibió el mensaje."},{en:"I do not know if I can go tomorrow.",es:"No sé si puedo ir mañana."}
  ]},
  {id:"si-entonces",title:"Talk about two possibilities",formula:"Si + present, …",en:"If…, then…",guide:"conectores",prompts:[
    {en:"If it rains, I will stay home.",es:"Si llueve, me quedo en casa."},{en:"If you want, we can practice later.",es:"Si quieres, podemos practicar más tarde."},{en:"If the driver arrives, I will call you.",es:"Si llega el conductor, te llamo."}
  ]},
  {id:"me-toca",title:"Say what you have to handle",formula:"Me toca + infinitive",en:"I have to / it is my turn to…",guide:"presente",prompts:[
    {en:"I have to work tomorrow.",es:"Me toca trabajar mañana."},{en:"I have to call the office.",es:"Me toca llamar a la oficina."},{en:"It is my turn to pay.",es:"Me toca pagar."}
  ]}
);

/* v61: essential production frames for a true beginner. These are deliberately
   short, reusable chunks; the learner swaps the final idea instead of
   memorizing isolated vocabulary. */
SPEAKING_FRAMES.push(
  {id:"necesito",title:"Say what you need",formula:"Necesito + noun / infinitive",en:"I need…",guide:"presente",prompts:[
    {en:"I need help.",es:"Necesito ayuda."},{en:"I need to find the bathroom.",es:"Necesito encontrar el baño."},{en:"I need to call my friend.",es:"Necesito llamar a mi amigo."}
  ]},
  {id:"puedo",title:"Ask what you can do",formula:"¿Puedo + infinitive?",en:"Can I…?",guide:"presente",prompts:[
    {en:"Can I pay by card?",es:"¿Puedo pagar con tarjeta?"},{en:"Can I sit here?",es:"¿Puedo sentarme aquí?"},{en:"Can I ask a question?",es:"¿Puedo hacer una pregunta?"}
  ]},
  {id:"estoy",title:"Say where you are and how you feel",formula:"Estoy + state / location",en:"I am…",guide:"ser-estar",prompts:[
    {en:"I am at the hotel.",es:"Estoy en el hotel."},{en:"I am tired, but I am okay.",es:"Estoy cansado, pero estoy bien."},{en:"I am ready.",es:"Estoy listo."}
  ]},
  {id:"fui",title:"Tell what you did",formula:"Ayer fui / hice / tuve…",en:"Yesterday I…",guide:"pasado",prompts:[
    {en:"Yesterday I went to the market.",es:"Ayer fui al mercado."},{en:"Yesterday I worked all day.",es:"Ayer trabajé todo el día."},{en:"Yesterday I had a meeting.",es:"Ayer tuve una reunión."}
  ]},
  {id:"quiero-que",title:"Express a wish about another person",formula:"Quiero que + subjunctive",en:"I want you to…",guide:"subjuntivo",prompts:[
    {en:"I want you to speak slowly.",es:"Quiero que hables despacio."},{en:"I want you to come tomorrow.",es:"Quiero que vengas mañana."},{en:"I want you to tell me the truth.",es:"Quiero que me digas la verdad."}
  ]},
  {id:"me-pasa",title:"Explain what is happening",formula:"Me pasa que… / El problema es que…",en:"What is happening is…",guide:"conectores",prompts:[
    {en:"The problem is that I do not understand.",es:"El problema es que no entiendo."},{en:"What is happening is that the app is not working.",es:"Me pasa que la aplicación no funciona."},{en:"The problem is that I am running late.",es:"El problema es que voy tarde."}
  ]}
);

/* v60 quiz additions. Conversation questions test the response a learner
   would actually choose; fill blanks use a single, context-locked answer. */
const V60_CONVERSATION_QUIZ=[
  {kind:"reply",focus:"present",cat:"mandatos",es:"Hábleme más despacio, por favor.",en:"Of course, no problem.",tts:"Hábleme más despacio, por favor.",choices:["Of course, no problem.","I went shopping yesterday.","It costs seven thousand.","The game is tonight."]},
  {kind:"reply",focus:"present",cat:"uber-real",es:"¿Dónde me bajo, por favor?",en:"At the building on the corner.",tts:"¿Dónde me bajo, por favor?",choices:["At the building on the corner.","Without sugar, please.","I am a little behind.","I hope Colombia wins."]},
  {kind:"reply",focus:"present",cat:"restaurante-real",es:"¿Algo más?",en:"No, thank you. Bring me the bill when you can.",tts:"¿Algo más?",choices:["No, thank you. Bring me the bill when you can.","The driver is over there.","I am going out tonight.","They scored a goal."]},
  {kind:"reply",focus:"present",cat:"mercado",es:"Está un poco caro. ¿Me lo deja en siete?",en:"Okay, I will let you have it for seven thousand.",tts:"Está un poco caro. ¿Me lo deja en siete?",choices:["Okay, I will let you have it for seven thousand.","Yes, the report is ready.","I am cooking dinner.","See you at the party."]},
  {kind:"meaning",focus:"gerundios",cat:"gerundios",es:"Estoy buscando la dirección.",en:"I am looking for the address.",tts:"Estoy buscando la dirección.",choices:["I am looking for the address.","I found the address yesterday.","I will send the address tomorrow.","I forgot the address."]},
  {kind:"reply",focus:"future",cat:"social",es:"¿Nos vemos después?",en:"Sure, but I will arrive a little late.",tts:"¿Nos vemos después?",choices:["Sure, but I will arrive a little late.","No, I did not understand.","It is behind the building.","The soup has potato."]},
  {kind:"reply",focus:"present",cat:"fiesta",es:"¿Quieres algo de tomar?",en:"Yes, thank you. A juice is fine.",tts:"¿Quieres algo de tomar?",choices:["Yes, thank you. A juice is fine.","I need the report.","Go straight to the corner.","I am a little behind."]},
  {kind:"reply",focus:"future",cat:"deportes",es:"¿Vas a ver el partido esta noche?",en:"Of course, I wouldn't miss it.",tts:"¿Vas a ver el partido esta noche?",choices:["Of course, I wouldn't miss it.","I need to change the order.","The entrance is behind it.","I went to the market."]},
  {kind:"reply",focus:"present",cat:"oficina-real",es:"¿Necesitas ayuda con el informe?",en:"Yes, can you review this part for me?",tts:"¿Necesitas ayuda con el informe?",choices:["Yes, can you review this part for me?","No, the music is good.","I am going to the corner.","Give me a kilo."]},
  {kind:"reply",focus:"present",cat:"mandatos",es:"Disculpe, no entendí.",en:"No problem. I will repeat it.",tts:"Disculpe, no entendí.",choices:["No problem. I will repeat it.","The game is tomorrow.","I would like a table.","I am behind schedule."]},
  {kind:"meaning",focus:"present",cat:"gerundios",es:"Estaba trabajando cuando me llamaste.",en:"I was working when you called.",tts:"Estaba trabajando cuando me llamaste.",choices:["I was working when you called.","I will work after I call.","I just finished working.","I went shopping for work."]},
  {kind:"reply",focus:"pronombres",cat:"oficina-real",es:"¿Qué hacemos con el proyecto?",en:"We will send it to the client tomorrow.",tts:"¿Qué hacemos con el proyecto?",choices:["We will send it to the client tomorrow.","I am looking for the driver.","It is a little expensive.","I hope Colombia wins."]}
];
const V60_FILL_BLANK_QUIZ=[
  {kind:"blank",focus:"gerundios",cat:"gerundios",es:"Ahora ___ la cena.",en:"estoy cocinando",tts:"Ahora estoy cocinando la cena.",trans:"Right now I am cooking dinner.",choices:["estoy cocinando","cociné","voy a cocinar","cocinar"]},
  {kind:"blank",focus:"gerundios",cat:"gerundios",es:"¿Qué ___ haciendo?",en:"estás",tts:"¿Qué estás haciendo?",trans:"What are you doing?",choices:["estás","eres","fuiste","vas"]},
  {kind:"blank",focus:"gerundios",cat:"gerundios",es:"Mientras ___, me llamaste.",en:"trabajaba",tts:"Mientras trabajaba, me llamaste.",trans:"While I was working, you called me.",choices:["trabajaba","trabajé","trabajo","trabajaré"]},
  {kind:"blank",focus:"past",cat:"gerundios",es:"Ayer fui de ___.",en:"compras",tts:"Ayer fui de compras.",trans:"Yesterday I went shopping.",choices:["compras","cocinar","trabajo","salir"]},
  {kind:"blank",focus:"present",cat:"mandatos",es:"___ más despacio, por favor.",en:"Hábleme",tts:"Hábleme más despacio, por favor.",trans:"Speak to me more slowly, please.",choices:["Hábleme","Hablame","Háblate","Hablar"]},
  {kind:"blank",focus:"present",cat:"mandatos",es:"___ la pregunta, por favor.",en:"Repítame",tts:"Repítame la pregunta, por favor.",trans:"Repeat the question for me, please.",choices:["Repítame","Repíteme","Repetir","Repítate"]},
  {kind:"blank",focus:"present",cat:"mandatos",es:"___, no entendí.",en:"Disculpe",tts:"Disculpe, no entendí.",trans:"Excuse me, I did not understand.",choices:["Disculpe","Discúlpame","Disculpa a él","Disculpen"]},
  {kind:"blank",focus:"present",cat:"direcciones",es:"___ derecho hasta la esquina.",en:"Siga",tts:"Siga derecho hasta la esquina.",trans:"Go straight to the corner.",choices:["Siga","Sigue","Seguir","Sigan"]},
  {kind:"blank",focus:"present",cat:"restaurante-real",es:"Quisiera ___ una sopa.",en:"pedir",tts:"Quisiera pedir una sopa.",trans:"I would like to order a soup.",choices:["pedir","pido","pedí","pidiendo"]},
  {kind:"blank",focus:"present",cat:"mercado",es:"¿Cuánto ___ el kilo?",en:"cuesta",tts:"¿Cuánto cuesta el kilo?",trans:"How much does the kilo cost?",choices:["cuesta","costó","costando","costar"]},
  {kind:"blank",focus:"present",cat:"mercado",es:"¿Me ___ un descuento?",en:"hace",tts:"¿Me hace un descuento?",trans:"Can you give me a discount?",choices:["hace","hizo","haciendo","hacer"]},
  {kind:"blank",focus:"future",cat:"social",es:"Voy a ___ con unos amigos.",en:"salir",tts:"Voy a salir con unos amigos.",trans:"I am going out with some friends.",choices:["salir","salgo","salí","saliendo"]},
  {kind:"blank",focus:"future",cat:"social",es:"Avísame cuando ___.",en:"llegues",tts:"Avísame cuando llegues.",trans:"Let me know when you arrive.",choices:["llegues","llegas","llegaste","llegar"]},
  {kind:"blank",focus:"subjuntivo",cat:"deportes",es:"Ojalá ___ Colombia.",en:"gane",tts:"Ojalá gane Colombia.",trans:"I hope Colombia wins.",choices:["gane","gana","ganó","ganar"]},
  {kind:"blank",focus:"present",cat:"oficina-real",es:"Estoy un poco ___.",en:"atrasado",tts:"Estoy un poco atrasado.",trans:"I am a little behind.",choices:["atrasado","atrasar","atrasando","atrasé"]},
  {kind:"blank",focus:"pronombres",cat:"pronombres",es:"¿Tienes la dirección? Sí, ___ tengo aquí.",en:"la",tts:"¿Tienes la dirección? Sí, la tengo aquí.",trans:"Do you have the address? Yes, I have it here.",choices:["la","lo","le","las"]},
  {kind:"blank",focus:"pronombres",cat:"pronombres",es:"El proyecto es importante; mañana ___ mandamos al cliente.",en:"lo",tts:"El proyecto es importante; mañana lo mandamos al cliente.",trans:"The project is important; tomorrow we will send it to the client.",choices:["lo","la","le","los"]},
  {kind:"blank",focus:"present",cat:"fiesta",es:"La música ___ muy buena.",en:"está",tts:"La música está muy buena.",trans:"The music is really good.",choices:["está","es","fue","sea"]}
];

/* ═══════════════════════════════════════════════════════════════════════════
   v71 Conversational Roadmap Upgrade:
   1. Colombian Polite Softeners, Diminutives, Time-Buyers (Muletillas), & Usted/Tú/Vos
   2. Complete guideIds for all lessons (no generic fallbacks)
   3. 5-Rung Sentence Expansion Ladders (Escalera de Oraciones)
   4. Interactive 3-Column Slot-Swap Matrices (Constructor de Frases)
   ═══════════════════════════════════════════════════════════════════════════ */
SPEAKING_GUIDE.push(
  {id:"cortesia-colombiana",title:"Colombian polite softeners",formula:"¿Me regala…? · ¿Será que…? · Qué pena con usted",explain:"In Colombia, direct requests like Quiero… or Deme… can sound abrupt with strangers. Soften requests with Qué pena con usted, ¿Me regala…?, or ¿Será que me puede…?",examples:[{es:"Qué pena con usted, ¿me regala un tintico?",en:"Sorry to bother you, can I have a black coffee?",tts:"Qué pena con usted, ¿me regala un tintico?"},{es:"¿Será que me puede ayudar con esta dirección?",en:"Could you possibly help me with this address?",tts:"¿Será que me puede ayudar con esta dirección?"},{es:"Veci, ¿me hace un favor?",en:"Neighbor/friend (shopkeeper), can you do me a favor?",tts:"Veci, ¿me hace un favor?"}],mistake:"Do not translate 'I want a coffee' as Yo quiero un café at a counter. Use ¿Me regala un tinto, por favor? or Quisiera…",exercise:"Ask for a coffee, the bill, and directions using ¿Me regala…? and ¿Será que…?"},
  {id:"diminutivos",title:"Diminutives (-ito / -ico) for warmth",formula:"tinto → tintico · ahora → ahorita · momento → momentico",explain:"Colombians use -ito/-ita (and -ico/-ica after T, like tintico or momentico) to sound warm, polite, and relaxed—not just to describe small size.",examples:[{es:"Espéreme un momentico, por favor.",en:"Wait for me just a moment, please.",tts:"Espéreme un momentico, por favor."},{es:"Ahorita te llamo; estoy cerquita.",en:"I'll call you right now/shortly; I'm very close.",tts:"Ahorita te llamo; estoy cerquita."},{es:"¿Me habla más despacito, por favor?",en:"Can you speak a little more slowly to me, please?",tts:"¿Me habla más despacito, por favor?"}],mistake:"When a word ends in -to/-ta, Colombians switch to -tico/-tica: momentico, tintico, ratico (never momentito in Colombia).",exercise:"Soften un momento, ahora, despacio, and cerca using Colombian diminutives."},
  {id:"muletillas",title:"Time-buyers while you think (Muletillas)",formula:"Pues… · A ver… · Es que… · Digamos que…",explain:"Native speakers use small filler chunks to hold the floor while organizing their next sentence. Using these prevents awkward silence while you think.",examples:[{es:"Pues, a ver… creo que vamos para el centro.",en:"Well, let's see… I think we are going downtown.",tts:"Pues, a ver… creo que vamos para el centro."},{es:"Es que todavía estoy aprendiendo español.",en:"It's just that I am still learning Spanish.",tts:"Es que todavía estoy aprendiendo español."},{es:"Digamos que necesito un poco más de práctica.",en:"Let's say I need a little more practice.",tts:"Digamos que necesito un poco más de práctica."}],mistake:"Instead of saying English 'uh / um' or freezing, start your answer with Pues, a ver… or Lo que pasa es que…",exercise:"Start three answers out loud with Pues, a ver…, Es que…, and O sea…"},
  {id:"usted-tu-vos",title:"Usted, tú, sumercé, and vos in Colombia",formula:"usted = respect & daily Bogotá · tú = friendly · ustedes = plural you",explain:"Colombian pronoun choice is warm and regional. Usted is standard with drivers, shopkeepers, doctors, and often even friends in Bogotá. Ustedes is always used for plural 'you all'.",examples:[{es:"Disculpe, ¿usted me puede indicar la entrada?",en:"Excuse me, can you show me the entrance? (formal)",tts:"Disculpe, ¿usted me puede indicar la entrada?"},{es:"¿Tú vas a salir esta noche o te quedas?",en:"Are you going out tonight or staying in? (friendly)",tts:"¿Tú vas a salir esta noche o te quedas?"},{es:"¿Ustedes a qué hora abren mañana?",en:"What time do you all open tomorrow?",tts:"¿Ustedes a qué hora abren mañana?"}],mistake:"Remember that él, ella, and usted all share the exact same verb form (habla, tiene, va), and ellos/ustedes share the -n form (hablan, tienen, van).",exercise:"Ask the same question first to a friend with tú, then to a driver with usted."}
);

FRASES.push(
  {section:"🙏 Cortesía colombiana — polite requests",quizCat:"cortesia",cls:"color:var(--gold);background:rgba(232,180,74,0.1);border:1px solid rgba(232,180,74,0.2)",items:[
    {es:"Qué pena con usted.",en:"Sorry to bother you / Excuse me.",register:"Colombian · polite"},
    {es:"¿Me regala un tintico, por favor?",en:"Can I have a black coffee, please?",register:"Colombian · everyday"},
    {es:"¿Será que me puede ayudar?",en:"Could you possibly help me?",register:"Colombian · polite"},
    {es:"¿Será que tiene cambio?",en:"Would you happen to have change?",register:"Colombian · polite"},
    {es:"Veci, ¿cuánto le debo?",en:"Neighbor/shopkeeper, how much do I owe you?",register:"Colombian · everyday"},
    {es:"¿Me hace un favor?",en:"Can you do me a favor?",register:"Everyday"},
    {es:"Con mucho gusto.",en:"With pleasure / Happy to help.",register:"Colombian · polite"},
    {es:"A la orden.",en:"At your service / You're welcome.",register:"Colombian · everyday"},
    {es:"Dios le pague.",en:"Thank you very much (warm traditional).",register:"Colombian · warm"}
  ]},
  {section:"☕ Diminutivos y muletillas — sound local",quizCat:"muletillas",cls:"color:var(--teal);background:rgba(74,168,160,0.1);border:1px solid rgba(74,168,160,0.2)",items:[
    {es:"Espéreme un momentico.",en:"Wait for me just a moment.",register:"Colombian · everyday"},
    {es:"Ahorita vengo.",en:"I'll be right back / coming shortly.",register:"Colombian · everyday"},
    {es:"Queda aquí cerquita.",en:"It's right nearby.",register:"Colombian · everyday"},
    {es:"Hábleme más despacito, por favor.",en:"Speak to me a little more slowly, please.",register:"Colombian · polite"},
    {es:"Nos vemos en un ratico.",en:"See you in a little while.",register:"Colombian · everyday"},
    {es:"Pues, a ver…",en:"Well, let's see… (buying time)",register:"Everyday"},
    {es:"Es que todavía estoy aprendiendo.",en:"It's just that I'm still learning.",register:"Everyday"},
    {es:"Digamos que sí.",en:"Let's say yes / more or less.",register:"Everyday"},
    {es:"¿Sí me entiende?",en:"Do you see what I mean?",register:"Colombian · everyday"}
  ]}
);

CONVERSATIONS.push(
  v60Dialogue("Cortesía en una tienda","Polite Colombian ordering with ¿Me regala…?, ¿Será que…?, and Veci",[
    ["A","Buenas, veci. Qué pena con usted, ¿me regala un tintico?","Hi, neighbor. Sorry to bother you, can I have a black coffee?"],
    ["B","Claro, con mucho gusto. ¿Lo quiere con azúcar?","Of course, with pleasure. Do you want it with sugar?"],
    ["A","Sin azúcar, por favor. ¿Y será que tiene una arepa con queso?","Without sugar, please. And would you happen to have an arepa with cheese?"],
    ["B","Sí, claro, ya le sale calentica.","Yes, of course, it's coming right out warm."],
    ["A","Perfecto. ¿Cuánto le debo por todo?","Perfect. How much do I owe you for everything?"],
    ["B","Son seis mil pesos. A la orden.","It's six thousand pesos. At your service."]
  ],[{es:"Qué pena, ¿será que puedo pagar con Nequi o en efectivo?",en:"Excuse me, could I pay with Nequi or in cash?",tts:"Qué pena, ¿será que puedo pagar con Nequi o en efectivo?"},{es:"Muchas gracias, muy amable.",en:"Thank you very much, very kind of you.",tts:"Muchas gracias, muy amable."}]),
  v60Dialogue("Ganar tiempo al hablar","Using muletillas and diminutives to keep a conversation flowing",[
    ["A","Hola, ¿ya conoces bien el barrio?","Hi, do you know the neighborhood well yet?"],
    ["B","Pues, a ver… apenas llevo unos días aquí, pero me gusta mucho.","Well, let's see… I've only been here a few days, but I like it a lot."],
    ["A","¿Y dónde queda tu hotel?","And where is your hotel located?"],
    ["B","Queda aquí cerquita, a dos cuadras del parque.","It's right nearby, two blocks from the park."],
    ["A","¿Vamos por un tintico ahorita?","Shall we go for a coffee right now?"],
    ["B","De una, espéreme un momentico y salimos.","I'm in, wait for me just a moment and we'll head out."]
  ],[{es:"Lo que pasa es que todavía hablo despacito, pero ahí voy.",en:"The thing is I still speak slowly, but I'm getting there.",tts:"Lo que pasa es que todavía hablo despacito, pero ahí voy."},{es:"Nos vemos en un ratico en la esquina.",en:"See you in a little while on the corner.",tts:"Nos vemos en un ratico en la esquina."}])
);

Object.assign(LESSON_CONTENT,{
  "cortesia-colombiana":{
    goal:{es:"Qué pena con usted, ¿me regala un tintico y me dice cuánto le debo?",en:"Sorry to bother you, can I have a black coffee and can you tell me how much I owe you?"},
    words:[{es:"Qué pena con usted",en:"Sorry to bother you"},{es:"¿Me regala…?",en:"Can I have…? (Colombian)"},{es:"¿Será que…?",en:"Could it be that…? (polite opener)"},{es:"Veci",en:"Friendly shopkeeper address"},{es:"Con mucho gusto",en:"With pleasure"},{es:"A la orden",en:"At your service"}],
    phrases:[{en:"Sorry to bother you, can you help me?",es:"Qué pena con usted, ¿me puede ayudar?"},{en:"Can I have a black coffee, please?",es:"¿Me regala un tintico, por favor?"},{en:"Would you happen to have change?",es:"¿Será que tiene cambio?"},{en:"How much do I owe you for everything?",es:"¿Cuánto le debo por todo?"}]
  },
  "muletillas-diminutivos":{
    goal:{es:"Pues, a ver… espéreme un momentico porque ya estoy cerquita.",en:"Well, let's see… wait for me just a moment because I am already very close."},
    words:[{es:"un momentico",en:"just a moment"},{es:"ahorita",en:"right now / shortly"},{es:"cerquita",en:"very close"},{es:"despacito",en:"nice and slowly"},{es:"Pues, a ver…",en:"Well, let's see…"},{es:"Es que…",en:"It's just that…"}],
    phrases:[{en:"Wait for me just a moment, please.",es:"Espéreme un momentico, por favor."},{en:"It's right nearby, across the way.",es:"Queda aquí cerquita, al frente."},{en:"Well, let's see… it's just that I'm still learning.",es:"Pues, a ver… es que todavía estoy aprendiendo."},{en:"I'll call you in a little while.",es:"Te llamo en un ratico."}]
  }
});

Object.assign(LESSON_META,{
  trabajo:{stage:"Daily Life",difficulty:"Easy",prereq:"Preséntate",guideIds:["presente","por-para"],readingId:"lectura-trabajo",missionId:"reunion-trabajo"},
  casa:{stage:"Start Here",difficulty:"Easy",prereq:"Preséntate",guideIds:["ser-estar","hay"],missionId:"problema-casa"},
  cocina:{stage:"Travel and Survival",difficulty:"Easy",prereq:"Tu casa",guideIds:["futuro","ir-venir"]},
  gustos:{stage:"Start Here",difficulty:"Easy",prereq:"Preséntate",guideIds:["gustar","acuerdo"]},
  planes:{stage:"Daily Life",difficulty:"Easy",prereq:"Gustos y familia",guideIds:["quedar","futuro"],readingId:"lectura-planes",missionId:"planes-fin-semana"},
  sentirse:{stage:"Daily Life",difficulty:"Easy",prereq:"Tu casa",guideIds:["ser-estar","estructura"],missionId:"como-te-sientes"},
  colombia:{stage:"Speak More Naturally",difficulty:"Easy",prereq:"Start Here",guideIds:["cortesia-colombiana","diminutivos"],readingId:"lectura-cafe",missionId:"tinto-por-favor"},
  "uber-ride":{stage:"Travel and Survival",difficulty:"Easy",prereq:"Comunicación para aclarar",dialogue:"Uber: confirmar la recogida",vocab:"direcciones",quizCat:"uber",quizMode:"conversation",guideIds:["usted-tu-vos","por-para"],readingId:"lectura-uber",missionId:"taxi-aeropuerto"},
  "hotel-checkin":{stage:"Travel and Survival",difficulty:"Easy",prereq:"Uber y transporte",dialogue:"Hotel: registrarse",vocab:"lugares",quizCat:"hotel",quizMode:"conversation",guideIds:["hay","cortesia-colombiana"],readingId:"lectura-hotel",missionId:"hotel-checkin"},
  farmacia:{stage:"Travel and Survival",difficulty:"Moderate",prereq:"Hotel",dialogue:"Farmacia: explicar síntomas",vocab:"emociones",quizCat:"farmacia",quizMode:"conversation",guideIds:["ser-estar","negativas-preguntas"],missionId:"farmacia-sintomas"},
  "daily-repair":{stage:"Daily Life",difficulty:"Moderate",prereq:"Travel and Survival",dialogue:"Teléfono: mala señal",vocab:"tecnologia",quizCat:"reparar",quizMode:"conversation",guideIds:["conectores","se-me"],readingId:"lectura-telefono"},
  direcciones:{stage:"Travel and Survival",difficulty:"Easy",prereq:"En la calle",dialogue:"Uber: dirección equivocada",vocab:"direcciones",quizCat:"direcciones",quizMode:"conversation",guideIds:["hay","quedar"],readingId:"lectura-edificio",missionId:"edificio-direcciones"},
  "cortesia-colombiana":{stage:"Start Here",difficulty:"Easy",prereq:"Preséntate",dialogue:"Cortesía en una tienda",vocab:"colombianismos",quizCat:"cortesia",quizMode:"conversation",guideIds:["cortesia-colombiana","usted-tu-vos"],readingId:"lectura-cafe",missionId:"tinto-por-favor"},
  "muletillas-diminutivos":{stage:"Speak More Naturally",difficulty:"Easy",prereq:"Colombianismos",dialogue:"Ganar tiempo al hablar",vocab:"colombianismos",quizCat:"muletillas",quizMode:"conversation",guideIds:["diminutivos","muletillas"],readingId:"lectura-cafe",missionId:"saludo-parce"}
});

SPEAKING_FRAMES.push(
  {id:"sera-que",title:"Soften a request the Colombian way",formula:"¿Será que + can / have…?",en:"Could it be that / Would you happen to…?",guide:"cortesia-colombiana",prompts:[
    {en:"Could you possibly help me?",es:"¿Será que me puede ayudar?"},
    {en:"Would you happen to have change?",es:"¿Será que tiene cambio?"},
    {en:"Could we meet a little later?",es:"¿Será que nos vemos más tarde?"}
  ]},
  {id:"me-regala",title:"Order or ask politely in Colombia",formula:"¿Me regala + thing, por favor?",en:"Can I have…, please?",guide:"cortesia-colombiana",prompts:[
    {en:"Can I have a black coffee, please?",es:"¿Me regala un tintico, por favor?"},
    {en:"Can you give me the address, please?",es:"¿Me regala la dirección, por favor?"},
    {en:"Can I have the bill, please?",es:"¿Me regala la cuenta, por favor?"}
  ]},
  {id:"pues-es-que",title:"Buy time while you think",formula:"Pues, a ver… es que + sentence",en:"Well, let's see… it's just that…",guide:"muletillas",prompts:[
    {en:"Well, let's see… it's just that I am still learning.",es:"Pues, a ver… es que todavía estoy aprendiendo."},
    {en:"It's just that I forgot the address.",es:"Es que se me olvidó la dirección."},
    {en:"Well, let's see… I think it's over there.",es:"Pues, a ver… creo que queda por allá."}
  ]}
);

const V71_QUIZ=[
  {kind:"reply",focus:"present",cat:"cortesia",es:"Buenas, veci. ¿Me regala un tintico, por favor?",en:"Claro, con mucho gusto. ¿Con azúcar?",tts:"Buenas, veci. ¿Me regala un tintico, por favor?",choices:["Claro, con mucho gusto. ¿Con azúcar?","La llanta está baja.","Ayer trabajé en la oficina.","Juega Colombia esta noche."]},
  {kind:"meaning",focus:"present",cat:"cortesia",es:"¿Será que me puede ayudar con esta dirección?",en:"Could you possibly help me with this address?",tts:"¿Será que me puede ayudar con esta dirección?",choices:["Could you possibly help me with this address?","Did you already send the address?","I forgot the address yesterday.","Go straight to the corner."]},
  {kind:"reply",focus:"present",cat:"muletillas",es:"¿Vamos por un tintico ahorita?",en:"De una, espéreme un momentico y salimos.",tts:"¿Vamos por un tintico ahorita?",choices:["De una, espéreme un momentico y salimos.","No, la impresora no funciona.","Ayer fui al mercado.","El semáforo está en rojo."]},
  {kind:"meaning",focus:"present",cat:"muletillas",es:"Queda aquí cerquita, a dos cuadras.",en:"It's right nearby, two blocks away.",tts:"Queda aquí cerquita, a dos cuadras.",choices:["It's right nearby, two blocks away.","It is very far from the airport.","I lived there last year.","The entrance is on the second floor."]}
];
V60_CONVERSATION_QUIZ.push(...V71_QUIZ);

/* ── 5-Rung Sentence Expansion Ladders (Escalera de Oraciones) ─────────────
   Teaches learners how to start with a 2-word anchor chunk and snap pieces
   together into a complete conversational sentence, plus 3 slot-swaps. */
const SENTENCE_LADDERS={
  presentate:{
    title:"Build your introduction step by step",
    rungs:[
      {tag:"1. Anchor stem",es:"Me llamo…",en:"My name is…"},
      {tag:"2. + Origin",es:"Me llamo Seth y soy de Estados Unidos.",en:"My name is Seth and I'm from the United States."},
      {tag:"3. + Where you live",es:"Me llamo Seth, soy de Estados Unidos y vivo en Colombia.",en:"My name is Seth, I'm from the U.S. and I live in Colombia."},
      {tag:"4. + Conversational softener",es:"Hola, mucho gusto. Me llamo Seth, soy de Estados Unidos y estoy aprendiendo español.",en:"Hi, nice to meet you. My name is Seth, I'm from the U.S. and I'm learning Spanish."}
    ],
    swaps:[
      {label:"Swap city",es:"Vivo en Medellín, cerca del parque.",en:"I live in Medellín, near the park."},
      {label:"Ask back",es:"Mucho gusto, ¿y tú de dónde eres?",en:"Nice to meet you, and where are you from?"},
      {label:"Slow down",es:"Hablo un poquito de español; ¿me habla más despacito?",en:"I speak a little Spanish; can you speak more slowly to me?"}
    ]
  },
  "cortesia-colombiana":{
    title:"Grow a polite Colombian request",
    rungs:[
      {tag:"1. Anchor stem",es:"¿Me regala…?",en:"Can I have…?"},
      {tag:"2. + Warm diminutive",es:"¿Me regala un tintico, por favor?",en:"Can I have a black coffee, please?"},
      {tag:"3. + Polite opener",es:"Buenas, veci. Qué pena con usted, ¿me regala un tintico?",en:"Hi, neighbor. Sorry to bother you, can I have a black coffee?"},
      {tag:"4. + Second polite question",es:"Qué pena con usted, ¿me regala un tintico y será que tiene cambio?",en:"Sorry to bother you, can I have a black coffee and would you happen to have change?"}
    ],
    swaps:[
      {label:"Swap for water",es:"Qué pena con usted, ¿me regala un vaso de agua?",en:"Sorry to bother you, can I have a glass of water?"},
      {label:"Swap for the bill",es:"Veci, ¿me regala la cuenta cuando pueda?",en:"Neighbor, can I have the bill when you can?"},
      {label:"Swap for directions",es:"Qué pena con usted, ¿será que me puede indicar la entrada?",en:"Sorry to bother you, could you possibly show me the entrance?"}
    ]
  },
  plata:{
    title:"Ask prices and negotiate naturally",
    rungs:[
      {tag:"1. Anchor stem",es:"¿Cuánto cuesta?",en:"How much does it cost?"},
      {tag:"2. + Specific item",es:"¿Cuánto cuestan estas arepas?",en:"How much do these arepas cost?"},
      {tag:"3. + Quantity request",es:"¿Cuánto cuestan estas arepas? Me regala dos, por favor.",en:"How much do these arepas cost? Can I have two, please."},
      {tag:"4. + Payment question",es:"Me regala dos arepas, por favor. ¿Será que puedo pagar con tarjeta?",en:"Can I have two arepas, please. Could I pay by card?"}
    ],
    swaps:[
      {label:"Pay cash",es:"Pago en efectivo; ¿tiene cambio de cincuenta mil?",en:"I'll pay in cash; do you have change for fifty thousand?"},
      {label:"Ask total",es:"Listo, ¿cuánto le debo por todo?",en:"Great, how much do I owe you for everything?"},
      {label:"Ask discount",es:"Está un poquito caro; ¿me hace un descuento?",en:"It's a little expensive; can you give me a discount?"}
    ]
  },
  "survival-communication":{
    title:"Repair a fast conversation without freezing",
    rungs:[
      {tag:"1. Anchor stem",es:"No entendí.",en:"I didn't understand."},
      {tag:"2. + Polite request",es:"Disculpe, no entendí bien.",en:"Excuse me, I didn't quite understand."},
      {tag:"3. + Ask to slow down",es:"Disculpe, no entendí bien. ¿Me puede hablar más despacito?",en:"Excuse me, I didn't quite understand. Can you speak more slowly to me?"},
      {tag:"4. + Explain why",es:"Disculpe, ¿me lo puede repetir más despacito? Es que todavía estoy aprendiendo español.",en:"Excuse me, can you repeat it more slowly for me? It's just that I'm still learning Spanish."}
    ],
    swaps:[
      {label:"Buy time",es:"Espéreme un momentico, déjeme pensar.",en:"Wait for me just a moment, let me think."},
      {label:"Ask meaning",es:"Perdón, ¿qué quiere decir esa palabra?",en:"Sorry, what does that word mean?"},
      {label:"Check yourself",es:"¿Así está bien o cómo se dice?",en:"Is it okay like this, or how do you say it?"}
    ]
  },
  "uber-ride":{
    title:"Confirm your Uber pickup and destination",
    rungs:[
      {tag:"1. Anchor stem",es:"Voy para…",en:"I'm headed to…"},
      {tag:"2. + Destination",es:"Voy para este hotel.",en:"I'm headed to this hotel."},
      {tag:"3. + Pickup location",es:"Buenas, estoy al frente y voy para este hotel.",en:"Hi, I'm out front and I'm headed to this hotel."},
      {tag:"4. + Polite instruction",es:"Buenas, estoy al frente del edificio. Voy para este hotel; ¿me avisa cuando lleguemos?",en:"Hi, I'm in front of the building. I'm going to this hotel; can you let me know when we arrive?"}
    ],
    swaps:[
      {label:"Drop-off",es:"¿Me puede dejar aquí en la esquina, por favor?",en:"Can you drop me off here on the corner, please?"},
      {label:"Check traffic",es:"¿Hay mucho trancón por esta avenida?",en:"Is there a lot of traffic on this avenue?"},
      {label:"Wrong entrance",es:"Creo que la entrada queda por allá; ¿se devuelve un poquito?",en:"I think the entrance is over there; can you go back a little?"}
    ]
  },
  "action-chunks":{
    title:"Snap action stems onto infinitives",
    rungs:[
      {tag:"1. Anchor stem",es:"Tengo que…",en:"I have to…"},
      {tag:"2. + Infinitive + object",es:"Tengo que pasar por el mercado.",en:"I have to stop by the market."},
      {tag:"3. + Second clause",es:"Quiero ir para la casa, pero tengo que pasar por el mercado.",en:"I want to go home, but I have to stop by the market."},
      {tag:"4. + Time + follow-up",es:"Quiero ir para la casa, pero primero tengo que pasar por el mercado; te aviso ahorita.",en:"I want to go home, but first I have to stop by the market; I'll let you know shortly."}
    ],
    swaps:[
      {label:"Use Necesito",es:"Necesito encontrar la dirección antes de salir.",en:"I need to find the address before leaving."},
      {label:"Use Me toca",es:"Hoy me toca trabajar hasta tarde en la oficina.",en:"Today I have to work late at the office."},
      {label:"Use Acabo de",es:"Acabo de llegar al hotel y voy a descansar.",en:"I just arrived at the hotel and I'm going to rest."}
    ]
  }
};

/* ── 3-Column Interactive Slot-Swap Matrices (Constructor de Frases) ────────
   Lets learners physically tap 1 opener + 1 core action + 1 connector/reason
   to assemble dozens of real Colombian sentences and speak them out loud. */
const SLOT_SWAP_MATRICES=[
  {
    id:"survival-polite",
    title:"🇨🇴 Polite Requests & Survival",
    sub:"Combine a Colombian opener + what you need + why",
    col1Title:"1. Opener / Stem",
    col2Title:"2. Action / Need",
    col3Title:"3. Context / Reason",
    col1:[
      {es:"Qué pena con usted, necesito",en:"Sorry to bother you, I need"},
      {es:"Disculpe, ¿será que puedo",en:"Excuse me, could I possibly"},
      {es:"Buenas, veci, quisiera",en:"Hi neighbor, I would like"},
      {es:"Perdón, tengo que",en:"Sorry, I have to"}
    ],
    col2:[
      {es:"pedir un Uber para el hotel",en:"to order an Uber to the hotel"},
      {es:"confirmar esta dirección",en:"to confirm this address"},
      {es:"pagar la cuenta con tarjeta",en:"to pay the bill by card"},
      {es:"cambiar la reserva para mañana",en:"to change the reservation for tomorrow"}
    ],
    col3:[
      {es:"porque voy un poquito tarde.",en:"because I'm running a little late."},
      {es:"pero todavía no tengo buena señal.",en:"but I still don't have good signal."},
      {es:"antes de que empiece el trancón.",en:"before the traffic jam starts."},
      {es:"si me hace el favor.",en:"if you'd do me the favor."}
    ]
  },
  {
    id:"daily-plans",
    title:"📆 Plans, Work & Daily Flow",
    sub:"Talk about what you're doing now and next",
    col1Title:"1. Time + Stem",
    col2Title:"2. Core Action",
    col3Title:"3. Connector + Follow-up",
    col1:[
      {es:"Ahorita voy a",en:"Right now I'm going to"},
      {es:"Después del trabajo quiero",en:"After work I want"},
      {es:"Hoy me toca",en:"Today I have to"},
      {es:"En este momento estoy tratando de",en:"Right now I'm trying to"}
    ],
    col2:[
      {es:"pasar por el mercado",en:"to stop by the market"},
      {es:"terminar el informe de la oficina",en:"to finish the office report"},
      {es:"tomar un tintico con unos amigos",en:"to have a coffee with some friends"},
      {es:"buscar la entrada del edificio",en:"to look for the building entrance"}
    ],
    col3:[
      {es:"y te aviso en cuanto llegue.",en:"and I'll let you know as soon as I arrive."},
      {es:"pero primero tengo una reunión.",en:"but first I have a meeting."},
      {es:"porque mañana salgo temprano.",en:"because tomorrow I leave early."},
      {es:"así que nos vemos en un ratico.",en:"so I'll see you in a little while."}
    ]
  },
  {
    id:"past-stories",
    title:"⏮️ Telling What Happened (Past)",
    sub:"Combine a past event with background context",
    col1Title:"1. Past Anchor",
    col2Title:"2. What Happened",
    col3Title:"3. Background / Result",
    col1:[
      {es:"Ayer fui a",en:"Yesterday I went to"},
      {es:"Anoche tuve que",en:"Last night I had to"},
      {es:"Esta mañana iba a",en:"This morning I was going to"},
      {es:"Hace un ratico acabé de",en:"A little while ago I finished"}
    ],
    col2:[
      {es:"hacer una vuelta en el centro",en:"run an errand downtown"},
      {es:"llamar al técnico del apartamento",en:"call the apartment technician"},
      {es:"comprar comida para la cena",en:"buy food for dinner"},
      {es:"hablar con mi compañero de trabajo",en:"talk with my coworker"}
    ],
    col3:[
      {es:"porque estaba lloviendo muy fuerte.",en:"because it was raining very hard."},
      {es:"pero había mucho trancón en la avenida.",en:"but there was a lot of traffic on the avenue."},
      {es:"entonces llegué a la casa un poco cansado.",en:"so I arrived home a little tired."},
      {es:"mientras esperaba el carro.",en:"while I was waiting for the car."}
    ]
  }
];

